# Talking Heads Video Player

A powerful, self-contained JavaScript video player with 15 intelligent autostart modes, advanced positioning, analytics tracking, and comprehensive admin controls.

## 📦 Installation

### Standard Installation (Non-WordPress)

1. Extract the ZIP file
2. Upload the entire `talkingheads/` folder to your web server
3. Include the player script on your pages:

```html
<script src="talkingheads/player.js"></script>
```

**For multiple videos:**
- Use `player2.js`, `player3.js`, etc. for additional video players
- Each player file supports independent configuration
- Access the admin panel at `talkingheads/admin.php` to manage all players

### WordPress Installation

1. Log in to your WordPress admin panel
2. Go to **Plugins → Add New → Upload Plugin**
3. Upload the `talkingheads-wordpress-plugin.zip` file
4. Activate the plugin
5. Use the shortcode on any page or post:

```html
[talkinghead video="video1"]
```

For multiple videos, use different video identifiers:
```html
[talkinghead video="video2"]
[talkinghead video="video3"]
```

## ✨ Features

### 15 Intelligent Autostart Modes

The player offers 15 different autostart modes to suit various use cases:

**Basic Modes:**
- `yes` - Auto-play immediately
- `mute` - Auto-play muted
- `loop` - Auto-play in loop
- `poster` - Show poster until interaction

**Session-Based Modes:**
- `once` - Play once per browser session
- `picSession` - Show poster, play once per session
- `muteSession` - Auto-play muted, once per session

**Persistent Modes (localStorage):**
- `onceLocal` - Play once ever (persistent)
- `picLocal` - Show poster, play once ever
- `muteLocal` - Auto-play muted, once ever

**Interactive Modes:**
- `hover` - Play on mouse hover
- `scroll` - Play when user scrolls to threshold
- `delay` - Play after a time delay

**Advanced Modes:**
- `slide` - Slide in animation before play
- `gostopgo` - Play, pause on interaction, resume on exit

### Advanced Positioning

- **Position Presets:** `top-left`, `top-center`, `top-right`, `center`, `bottom-left`, `bottom-center`, `bottom-right`
- **Custom Positioning:** Pixel or percentage-based positioning for all edges
- **Responsive:** Automatically adjusts to different screen sizes
- **Offset Controls:** Fine-tune horizontal and vertical centering with offset values

### Analytics & Tracking

- **View Counts:** Total views, session views, and unique visitor tracking
- **Completion Tracking:** Monitor how many viewers watch videos to completion
- **Watch Time Statistics:** Track total watch time and average watch duration
- **Persistent Storage:** Stats saved to JSON files for reliable long-term tracking
- **Session Tracking:** Distinguish between session and permanent view counts

### Player Controls

- **Control Visibility:** Three modes - `always`, `hover`, or `hide`
- **Glassmorphism Design:** Beautiful, modern UI with frosted glass effects
- **Customizable Colors:** Full color customization via admin panel
- **Responsive Controls:** Adapts to video container size

### Exit Behaviors

- **No Exit:** Video completes normally
- **Redirect:** Redirect to a URL after video completes
- **Email Capture:** Collect email addresses when video completes
- **Customizable Delay:** Set delay before redirect/email capture triggers

## 🎛️ Using the Admin Panel

Access the admin panel at `talkingheads/admin.php` to configure all player settings.

### Main Sections

1. **Video Settings**
   - Video name and file selection
   - Poster image configuration
   - Autostart mode selection
   - Exit behavior configuration
   - Controls mode settings

2. **Position Settings**
   - Choose from preset positions or custom positioning
   - Adjust left, right, top, bottom values
   - Fine-tune with horizontal and vertical offsets
   - Preview position changes in real-time

3. **Visual Settings**
   - Customize player color theme
   - Adjust video dimensions (width/height)
   - Set z-index for layering

4. **Analytics Dashboard**
   - View total views, session views, unique visitors
   - Monitor completion rates
   - Track watch time statistics
   - Clear stats when needed

5. **Advanced Settings**
   - Time stop settings
   - Scroll threshold for scroll-based autostart
   - Redirect URL and delay
   - Email capture configuration
   - Contact form settings

### Saving Changes

- All settings are saved via AJAX (no page refresh required)
- Changes take effect immediately
- Settings are stored in `player.js` (or `player2.js`, `player3.js`, etc.)
- Multiple players can be configured independently

### Multiple Videos Setup

1. Upload multiple video files (`.webm` format) to the `talkingheads/` folder
2. In admin panel, use "Update Video Count" to set the number of videos
3. The system will generate `player2.js`, `player3.js`, etc. automatically
4. Configure each player file independently in the admin panel
5. Use URL matching or manual selection to assign videos to specific players

## 📁 File Structure

```
talkingheads/
├── player.js              # Main player file (or player2.js, player3.js, etc.)
├── admin.php              # Admin panel interface
├── admin-functions.php    # Admin backend functions
├── modules/               # Player modules
│   ├── config-manager.js  # Configuration management
│   ├── storage-manager.js # Data storage and analytics
│   └── position-manager.js # Positioning logic
├── js/                    # Admin panel JavaScript
│   ├── admin-config.js
│   ├── admin-analytics.js
│   ├── admin-forms.js
│   ├── admin-player-behavior.js
│   ├── admin-videos.js
│   └── admin-common.js
├── stats/                 # Analytics JSON files
│   └── {videoName}-stats.json
├── *.webm                 # Video files
├── *.png                  # Poster images
└── contact-form-settings.json
```

## 🔧 Configuration Options

All configuration is done through `VIDEO_CONFIG` object in `player.js`:

- `videoName` - Name of the video file (without extension)
- `autostart` - One of the 15 autostart modes
- `position` - `fixed` or `absolute` positioning
- `left`, `right`, `top`, `bottom` - Position values
- `horizontalOffset`, `verticalOffset` - Centering offsets
- `width`, `height` - Video dimensions (default: 320x320)
- `color` - Primary color theme (hex format)
- `controlsMode` - `always`, `hover`, or `hide`
- `exitOnComplete` - `no`, `redirect`, or `email`
- `timeStop` - Stop video at specific time (seconds)
- `scrollThreshold` - Scroll percentage for scroll-based autostart

## 📊 Analytics

Stats are tracked in JSON files in the `stats/` folder:
- View counts (total, session, unique)
- Completion tracking
- Watch time statistics

Access analytics in the admin panel's Analytics Dashboard section.

## 🆘 Support

For assistance, visit: https://www.websitetalkingheads.com/support/

## 📄 License

Copyright © Website Talking Heads. All rights reserved.
