/**
 * Admin Contact Forms Module
 * Handles contact form customization and settings
 */
const AdminContactForm = {
    contactFormFields: [
        { id: 'name', label: 'Name', type: 'text', required: true, placeholder: 'Your name' },
        { id: 'email', label: 'Email', type: 'email', required: true, placeholder: 'your@email.com' },
        { id: 'message', label: 'Message', type: 'textarea', required: true, placeholder: 'Your message...' }
    ],
    
    /**
     * Initialize contact form settings
     */
    initializeSettings() {
        this.loadSettings();
        this.renderFormFields();
    },
    
    /**
     * Load contact form settings from localStorage
     */
    loadSettings() {
        const settings = JSON.parse(localStorage.getItem('contactFormSettings') || '{}');
        
        // Load form fields
        if (settings.fields) {
            this.contactFormFields = settings.fields;
        }
        
        // Load SMTP settings
        if (settings.smtp) {
            document.getElementById('smtpHost').value = settings.smtp.host || '';
            document.getElementById('smtpPort').value = settings.smtp.port || '';
            document.getElementById('smtpUsername').value = settings.smtp.username || '';
            document.getElementById('smtpPassword').value = settings.smtp.password || '';
            document.getElementById('smtpFromEmail').value = settings.smtp.fromEmail || '';
        }
        
        // Load messages
        if (settings.messages) {
            document.getElementById('successMessage').value = settings.messages.success || 'Thank you! Your message has been sent successfully.';
            document.getElementById('errorMessage').value = settings.messages.error || 'Sorry, there was an error sending your message. Please try again.';
        }
        
        // Load styling
        if (settings.styling) {
            document.getElementById('formTitle').value = settings.styling.title || 'Get in Touch';
            const bgColor = settings.styling.backgroundColor || '#0073FF';
            document.getElementById('formBackgroundColor').value = bgColor;
            document.getElementById('formBackgroundColorText').value = bgColor;
        }
    },
    
    /**
     * Render form fields in the UI
     */
    renderFormFields() {
        const container = document.getElementById('formFieldsList');
        container.innerHTML = '';
        
        this.contactFormFields.forEach((field, index) => {
            const fieldDiv = document.createElement('div');
            fieldDiv.className = 'form-field-item';
            fieldDiv.style.cssText = `
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 6px;
                background: white;
                border: 1px solid #ddd;
                border-radius: 4px;
                margin-bottom: 4px;
            `;
            
            fieldDiv.innerHTML = `
                <input type="text" value="${field.label}" placeholder="Field Label" style="flex: 1; padding: 3px; border: 1px solid #ccc; border-radius: 3px; font-size: 11px;" onchange="updateFieldLabel(${index}, this.value)">
                <select style="padding: 3px; border: 1px solid #ccc; border-radius: 3px; font-size: 11px;" onchange="updateFieldType(${index}, this.value)">
                    <option value="text" ${field.type === 'text' ? 'selected' : ''}>Text</option>
                    <option value="email" ${field.type === 'email' ? 'selected' : ''}>Email</option>
                    <option value="textarea" ${field.type === 'textarea' ? 'selected' : ''}>Textarea</option>
                    <option value="tel" ${field.type === 'tel' ? 'selected' : ''}>Phone</option>
                </select>
                <input type="text" value="${field.placeholder || ''}" placeholder="Placeholder" style="flex: 1; padding: 3px; border: 1px solid #ccc; border-radius: 3px; font-size: 11px;" onchange="updateFieldPlaceholder(${index}, this.value)">
                <label style="font-size: 10px; margin: 0;">
                    <input type="checkbox" ${field.required ? 'checked' : ''} onchange="updateFieldRequired(${index}, this.checked)"> Required
                </label>
                <button type="button" onclick="removeFormField(${index})" style="padding: 2px 6px; background: #dc3545; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 10px;">×</button>
            `;
            
            container.appendChild(fieldDiv);
        });
    },
    
    /**
     * Add a new form field
     */
    addFormField() {
        const newField = {
            id: 'field_' + Date.now(),
            label: 'New Field',
            type: 'text',
            required: false,
            placeholder: ''
        };
        
        this.contactFormFields.push(newField);
        this.renderFormFields();
    },
    
    /**
     * Remove a form field by index
     */
    removeFormField(index) {
        if (this.contactFormFields.length > 1) {
            this.contactFormFields.splice(index, 1);
            this.renderFormFields();
        }
    },
    
    /**
     * Update field label
     */
    updateFieldLabel(index, value) {
        this.contactFormFields[index].label = value;
    },
    
    /**
     * Update field type
     */
    updateFieldType(index, value) {
        this.contactFormFields[index].type = value;
    },
    
    /**
     * Update field placeholder
     */
    updateFieldPlaceholder(index, value) {
        this.contactFormFields[index].placeholder = value;
    },
    
    /**
     * Update field required status
     */
    updateFieldRequired(index, value) {
        this.contactFormFields[index].required = value;
    },
    
    /**
     * Save contact form settings
     */
    async saveSettings() {
        const settings = {
            fields: this.contactFormFields,
            smtp: {
                host: document.getElementById('smtpHost').value,
                port: document.getElementById('smtpPort').value,
                username: document.getElementById('smtpUsername').value,
                password: document.getElementById('smtpPassword').value,
                fromEmail: document.getElementById('smtpFromEmail').value
            },
            messages: {
                success: document.getElementById('successMessage').value,
                error: document.getElementById('errorMessage').value
            },
            styling: {
                title: document.getElementById('formTitle').value,
                backgroundColor: document.getElementById('formBackgroundColor').value
            }
        };
        
        try {
            // Save to localStorage
            localStorage.setItem('contactFormSettings', JSON.stringify(settings));
            
            // Also save to server
            const response = await fetch('save-contact-form-settings.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(settings)
            });
            
            if (response.ok) {
                this.showStatus('Contact form settings saved successfully!', 'success');
            } else {
                this.showStatus('Settings saved locally, but server save failed', 'warning');
            }
        } catch (error) {
            console.error('Error saving contact form settings:', error);
            this.showStatus('Settings saved locally only', 'warning');
        }
    },
    
    /**
     * Show status message
     */
    showStatus(message, type) {
        let statusDiv = document.getElementById('contactFormStatus');
        if (!statusDiv) {
            statusDiv = document.createElement('div');
            statusDiv.id = 'contactFormStatus';
            statusDiv.style.cssText = `
                position: fixed;
                top: 60px;
                right: 20px;
                padding: 12px 20px;
                border-radius: 6px;
                color: white;
                font-weight: 500;
                z-index: 10000;
                transition: all 0.3s ease;
            `;
            document.body.appendChild(statusDiv);
        }
        
        statusDiv.textContent = message;
        statusDiv.style.backgroundColor = type === 'success' ? '#28a745' : type === 'warning' ? '#ffc107' : '#dc3545';
        statusDiv.style.display = 'block';
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }
};

// Global wrapper functions for backward compatibility with inline onclick handlers
function initializeContactFormSettings() {
    AdminContactForm.initializeSettings();
}

function loadContactFormSettings() {
    AdminContactForm.initializeSettings();
}

function renderFormFields() {
    AdminContactForm.renderFormFields();
}

function addFormField() {
    AdminContactForm.addFormField();
}

function removeFormField(index) {
    AdminContactForm.removeFormField(index);
}

function updateFieldLabel(index, value) {
    AdminContactForm.updateFieldLabel(index, value);
}

function updateFieldType(index, value) {
    AdminContactForm.updateFieldType(index, value);
}

function updateFieldPlaceholder(index, value) {
    AdminContactForm.updateFieldPlaceholder(index, value);
}

function updateFieldRequired(index, value) {
    AdminContactForm.updateFieldRequired(index, value);
}

function saveContactFormSettings() {
    AdminContactForm.saveSettings();
}

function showContactFormStatus(message, type) {
    AdminContactForm.showStatus(message, type);
}
