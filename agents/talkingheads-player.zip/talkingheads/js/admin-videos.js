/**
 * Admin Video Management Module
 * Handles all video upload, display, and management functionality
 */
const AdminVideos = {
    /**
     * Initialize video upload form handler
     */
    initializeUploadForm() {
        document.getElementById('videoUploadForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData();
            const videoFile = document.getElementById('videoFile').files[0];
            const thumbnailFile = document.getElementById('thumbnailFile').files[0];
            const description = document.getElementById('videoDescription').value;
            
            if (!videoFile) {
                this.showUploadStatus('Please select a video file.', 'error');
                return;
            }
            
            // Extract video name from filename (remove .webm extension)
            const videoName = videoFile.name.replace('.webm', '');
            
            formData.append('videoFile', videoFile);
            if (thumbnailFile) formData.append('thumbnailFile', thumbnailFile);
            formData.append('videoName', videoName);
            formData.append('description', description);
            
            this.showUploadStatus('Uploading...', 'info');
            
            try {
                const response = await fetch('upload-video.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    this.showUploadStatus('✅ Video uploaded successfully!', 'success');
                    
                    if (result.dimensions) {
                        this.showUploadStatus('✅ Video uploaded successfully! Dimensions detected: ' + 
                            result.dimensions.width + '×' + result.dimensions.height, 'success');
                    }
                    
                    document.getElementById('videoUploadForm').reset();
                    this.loadVideoList();
                } else {
                    this.showUploadStatus('❌ Upload failed: ' + result.message, 'error');
                }
            } catch (error) {
                this.showUploadStatus('❌ Upload error: ' + error.message, 'error');
            }
        });
    },
    
    /**
     * Show upload status message
     */
    showUploadStatus(message, type) {
        const statusDiv = document.getElementById('uploadStatus');
        statusDiv.innerHTML = message;
        statusDiv.className = type === 'error' ? 'text-danger' : type === 'success' ? 'text-success' : 'text-info';
    },
    
    /**
     * Load and display list of videos
     */
    async loadVideoList() {
        try {
            let response, result;
            
            // Check if we're in WordPress context
            if (typeof thpAjax !== 'undefined' && thpAjax.ajaxurl) {
                // Use WordPress AJAX
                const formData = new FormData();
                formData.append('action', 'thp_get_video_list');
                formData.append('nonce', thpAjax.nonce);
                
                response = await fetch(thpAjax.ajaxurl, {
                    method: 'POST',
                    body: formData
                });
                
                const wpResult = await response.json();
                // WordPress returns {success: true, data: {...}} format
                if (wpResult.success) {
                    result = { success: true, videos: wpResult.data.videos, count: wpResult.data.count };
                } else {
                    result = { success: false, message: wpResult.data?.message || 'Unknown error' };
                }
            } else {
                // Use direct PHP file
                response = await fetch('get-video-list.php');
                result = await response.json();
            }
            
            if (result.success) {
                this.displayVideoList(result.videos);
            } else {
                document.getElementById('videoList').innerHTML = 
                    '<p class="text-danger">Error loading video list: ' + (result.message || 'Unknown error') + '</p>';
            }
        } catch (error) {
            document.getElementById('videoList').innerHTML = 
                '<p class="text-danger">Error loading video list: ' + error.message + '</p>';
        }
    },
    
    /**
     * Display video list in the UI
     */
    displayVideoList(videos) {
        const videoListDiv = document.getElementById('videoList');
        
        if (videos.length === 0) {
            videoListDiv.innerHTML = '<p class="text-muted">No videos found.</p>';
            return;
        }
        
        let html = '<div class="row g-2">';
        
        videos.forEach(video => {
            html += `
                <div class="col-md-6 col-lg-4">
                    <div class="card" style="margin-bottom: 15px;">
                        <div class="card-body">
                            <h6 class="card-title">${video.name}</h6>
                            <p class="card-text">
                                <small class="text-muted">
                                    Size: ${this.formatFileSize(video.size)}<br>
                                    ${video.dimensions ? `Dimensions: ${video.dimensions.width}×${video.dimensions.height}<br>` : ''}
                                    Modified: ${new Date(video.modified).toLocaleDateString()}
                                </small>
                            </p>
                            <div class="btn-group" role="group">
                                <button class="btn btn-sm btn-outline-primary" onclick="viewVideoDetails('${video.name}')">👁️ View</button>
                                <button class="btn btn-sm btn-outline-danger" onclick="deleteVideo('${video.name}')">🗑️ Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        videoListDiv.innerHTML = html;
    },
    
    /**
     * Format file size in bytes to human-readable format
     */
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },
    
    /**
     * View video details
     */
    viewVideoDetails(videoName) {
        alert(`Video Details:\nName: ${videoName}\n\nThis would show detailed metadata in a modal or expanded view.`);
    },
    
    /**
     * Load video dimensions when video is selected
     */
    async loadVideoDimensions(videoName) {
        try {
            const response = await fetch('get-video-list.php');
            const result = await response.json();
            
            if (result.success) {
                const video = result.videos.find(v => v.name === videoName);
                if (video && video.dimensions) {
                    console.log('📐 Auto-detected dimensions for', videoName, ':', 
                        video.dimensions.width + '×' + video.dimensions.height);
                }
            }
        } catch (error) {
            console.log('Could not load dimensions for', videoName, ':', error.message);
        }
    },
    
    /**
     * Delete a video
     */
    async deleteVideo(videoName) {
        if (!confirm(`Are you sure you want to delete "${videoName}"?\n\nThis action cannot be undone.`)) {
            return;
        }
        
        try {
            const response = await fetch('delete-video.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ videoName: videoName })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✅ Video deleted successfully!');
                this.loadVideoList();
            } else {
                alert('❌ Delete failed: ' + result.message);
            }
        } catch (error) {
            alert('❌ Delete error: ' + error.message);
        }
    },
    
    /**
     * Create JSON files for new videos
     */
    createJsonForNewVideos() {
        if (!confirm('This will create JSON stats files for any videos that don\'t have them yet. Continue?')) {
            return;
        }

        const button = event.target;
        const originalText = button.textContent;
        button.textContent = '⏳ Creating...';
        button.disabled = true;

        fetch('create-json-files.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ action: 'create_missing_json' })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(`✅ Success! Created JSON files for ${data.created_count} videos:\n${data.created_files.join('\n')}`);
                if (typeof refreshAnalytics === 'function') {
                    refreshAnalytics();
                }
            } else {
                alert(`❌ Error: ${data.message}`);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('❌ Error creating JSON files: ' + error.message);
        })
        .finally(() => {
            button.textContent = originalText;
            button.disabled = false;
        });
    },
    
    /**
     * Check storage status and update UI
     */
    async checkStorageStatus() {
        const videoName = document.getElementById('videoSelect').value;
        console.log('🔍 Checking storage status for video:', videoName);
        
        try {
            const response = await fetch(`stats/${videoName}-stats.json`);
            if (response.ok) {
                const data = await response.json();
                
                if (data.stats && data.lastUpdated) {
                    document.getElementById('jsonFileStatus').textContent = '✅ Exists & Valid';
                    document.getElementById('lastUpdated').textContent = new Date(data.lastUpdated).toLocaleString();
                    document.getElementById('storageMethod').textContent = 'JSON File (Primary)';
                    console.log('✅ JSON file status: Valid and up to date');
                } else {
                    document.getElementById('jsonFileStatus').textContent = '⚠️ Invalid Structure';
                    document.getElementById('lastUpdated').textContent = '-';
                    document.getElementById('storageMethod').textContent = 'No Data Available';
                    console.warn('⚠️ JSON file has invalid structure');
                }
            } else if (response.status === 404) {
                document.getElementById('jsonFileStatus').textContent = '❌ Not Found';
                document.getElementById('lastUpdated').textContent = '-';
                document.getElementById('storageMethod').textContent = 'No Data Available';
                console.log('📁 JSON file not found');
            } else {
                document.getElementById('jsonFileStatus').textContent = '❌ Error (' + response.status + ')';
                document.getElementById('lastUpdated').textContent = '-';
                document.getElementById('storageMethod').textContent = 'No Data Available';
                console.warn('⚠️ JSON file check failed with status:', response.status);
            }
        } catch (error) {
            document.getElementById('jsonFileStatus').textContent = '❌ Network Error';
            document.getElementById('lastUpdated').textContent = '-';
            document.getElementById('storageMethod').textContent = 'No Data Available';
            console.error('❌ Storage status check failed:', error);
        }
    },
    
    /**
     * Switch video function (for tabs or dropdown)
     */
    switchVideo(videoName) {
        const videoSelect = document.getElementById('videoSelect');
        if (videoSelect.tagName === 'SELECT') {
            videoSelect.value = videoName;
        } else {
            videoSelect.value = videoName;
        }
        
        const tabs = document.querySelectorAll('.video-tab');
        tabs.forEach(tab => {
            if (tab.dataset.video === videoName) {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });
        
        // DO NOT auto-load settings when switching videos - it overwrites the user's selection
        // User should explicitly choose which video settings to load
        loadAnalytics();
        this.checkStorageStatus();
        this.loadVideoDimensions(videoName);
    },
    
    /**
     * Read video count from player.js
     */
    readVideoCount() {
        fetch('player.js')
            .then(response => response.text())
            .then(content => {
                const match = content.match(/const\s+SITE_VIDEO_COUNT\s*=\s*(\d+)/);
                if (match) {
                    document.getElementById('currentVideoCount').textContent = match[1];
                } else {
                    document.getElementById('currentVideoCount').textContent = 'Not set';
                }
            })
            .catch(error => {
                console.error('Error reading video count:', error);
                document.getElementById('currentVideoCount').textContent = 'Error';
            });
    },
    
    /**
     * Update video count in player.js
     */
    updateVideoCount(detectedCount) {
        const currentCount = document.getElementById('currentVideoCount').textContent;
        
        if (!confirm(`Update SITE_VIDEO_COUNT in player.js?\n\nDetected videos: ${detectedCount}\nCurrent setting: ${currentCount}\n\nThis will update player.js to match the detected video count.`)) {
            return;
        }
        
        // Check if we're in WordPress context
        if (typeof thpAjax !== 'undefined' && thpAjax.ajaxurl) {
            // Use WordPress AJAX
            const formData = new FormData();
            formData.append('action', 'thp_update_video_count');
            formData.append('nonce', thpAjax.nonce);
            formData.append('count', detectedCount);
            
            fetch(thpAjax.ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // WordPress returns {success: true, data: {...}} format
                if (data.success) {
                    alert(`✅ Video count updated to ${detectedCount}!\n\nThe player.js file has been updated.`);
                    this.readVideoCount();
                    location.reload();
                } else {
                    alert('❌ Error: ' + (data.data?.message || 'Unknown error'));
                }
            })
            .catch(error => {
                alert('❌ Error updating video count: ' + error.message);
            });
        } else {
            // Use direct PHP file
            fetch('update_video_count.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ videoCount: detectedCount })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(`✅ Video count updated to ${detectedCount}!\n\nThe player.js file has been updated.`);
                    this.readVideoCount();
                    location.reload();
                } else {
                    alert('❌ Error: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(error => {
                alert('❌ Error updating video count: ' + error.message);
            });
        }
    }
};

// Global wrapper functions for backward compatibility with inline onclick handlers
function showUploadStatus(message, type) {
    AdminVideos.showUploadStatus(message, type);
}

function loadVideoList() {
    AdminVideos.loadVideoList();
}

function displayVideoList(videos) {
    AdminVideos.displayVideoList(videos);
}

function formatFileSize(bytes) {
    return AdminVideos.formatFileSize(bytes);
}

function viewVideoDetails(videoName) {
    AdminVideos.viewVideoDetails(videoName);
}

function loadVideoDimensions(videoName) {
    AdminVideos.loadVideoDimensions(videoName);
}

function deleteVideo(videoName) {
    AdminVideos.deleteVideo(videoName);
}

function createJsonForNewVideos() {
    AdminVideos.createJsonForNewVideos();
}

function checkStorageStatus() {
    AdminVideos.checkStorageStatus();
}

function switchVideo(videoName) {
    AdminVideos.switchVideo(videoName);
}

function readVideoCount() {
    AdminVideos.readVideoCount();
}

function updateVideoCount() {
    const detectedCount = document.getElementById('detectedVideoCount')?.textContent || '1';
    AdminVideos.updateVideoCount(parseInt(detectedCount));
}
