/**
 * Admin Common Module
 * Contains shared utility functions and common admin functionality
 */
const AdminCommon = {
    currentUrls: [],
    
    /**
     * URL Management Functions
     */
    loadUrls() {
        const videoName = document.getElementById('videoSelect').value;
        const savedUrls = localStorage.getItem(videoName + '_showOnPages');
        
        if (savedUrls) {
            try {
                this.currentUrls = JSON.parse(savedUrls);
            } catch (e) {
                this.currentUrls = [];
            }
        } else {
            this.currentUrls = [];
        }
        
        this.renderUrlList();
    },
    
    addUrl() {
        const input = document.getElementById('urlInput');
        const url = input.value.trim();
        
        if (!url) {
            alert('Please enter a URL');
            return;
        }
        
        // Validate URL format
        try {
            new URL(url);
        } catch (e) {
            alert('Please enter a valid URL (e.g., https://example.com/page)');
            return;
        }
        
        // Check for duplicates
        if (this.currentUrls.includes(url)) {
            alert('This URL is already in the list');
            return;
        }
        
        // Add to list
        this.currentUrls.push(url);
        input.value = '';
        
        // Save and render
        this.saveUrls();
        this.renderUrlList();
    },
    
    removeUrl(url) {
        const index = this.currentUrls.indexOf(url);
        if (index > -1) {
            this.currentUrls.splice(index, 1);
        }
        
        this.saveUrls();
        this.renderUrlList();
    },
    
    saveUrls() {
        const videoName = document.getElementById('videoSelect').value;
        localStorage.setItem(videoName + '_showOnPages', JSON.stringify(this.currentUrls));
    },
    
    renderUrlList() {
        const container = document.getElementById('urlList');
        
        if (this.currentUrls.length === 0) {
            container.innerHTML = '<em style="color: #999; font-size: 12px;">No URLs - video shows on all pages</em>';
            return;
        }
        
        container.innerHTML = this.currentUrls.map(url => `
            <div style="display: flex; align-items: center; gap: 8px; padding: 6px; background: #f0f4ff; border: 1px solid #cbd5e0; border-radius: 4px; margin-bottom: 4px;">
                <span style="flex: 1; font-family: monospace; font-size: 12px; word-break: break-all;">${url}</span>
                <button onclick="removeUrl('${url.replace(/'/g, "\\'")}'); event.stopPropagation();" 
                        style="padding: 4px 8px; background: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 11px; white-space: nowrap;">Remove</button>
            </div>
        `).join('');
    },
    
    /**
     * Position Management Functions
     */
    updatePositionUI(position) {
        document.querySelectorAll('.position-btn').forEach(btn => {
            btn.classList.remove('active', 'btn-primary');
            btn.classList.add('btn-outline-secondary');
        });
        
        if (position === 'custom') {
            document.getElementById('customPositionSelect').value = 'yes';
            document.getElementById('customPosition').classList.add('show');
        } else {
            const activeBtn = document.querySelector(`[data-position="${position}"]`);
            if (activeBtn) {
                activeBtn.classList.add('active', 'btn-primary');
                activeBtn.classList.remove('btn-outline-secondary');
            }
            document.getElementById('customPositionSelect').value = 'no';
            document.getElementById('customPosition').classList.remove('show');
            
            const positions = {
                'top-left': { left: '0', right: 'auto', top: '0', bottom: 'auto' },
                'top-center': { left: '50%', right: 'auto', top: '0', bottom: 'auto' },
                'top-right': { left: 'auto', right: '0', top: '0', bottom: 'auto' },
                'middle-left': { left: '0', right: 'auto', top: '50%', bottom: 'auto' },
                'center': { left: '50%', right: 'auto', top: '50%', bottom: 'auto' },
                'middle-right': { left: 'auto', right: '0', top: '50%', bottom: 'auto' },
                'bottom-left': { left: '0', right: 'auto', top: 'auto', bottom: '0' },
                'bottom-center': { left: '50%', right: 'auto', top: 'auto', bottom: '0' },
                'bottom-right': { left: 'auto', right: '0', top: 'auto', bottom: '0' }
            };
            
            if (positions[position]) {
                const pos = positions[position];
                document.getElementById('leftPos').value = pos.left;
                document.getElementById('rightPos').value = pos.right;
                document.getElementById('topPos').value = pos.top;
                document.getElementById('bottomPos').value = pos.bottom;
            }
        }
    },
    
    updatePreview() {
        const previewPlayer = document.getElementById('previewPlayer');
        if (!previewPlayer) return;

        const left = document.getElementById('leftPos').value || 'auto';
        const right = document.getElementById('rightPos').value || 'auto';
        const top = document.getElementById('topPos').value || 'auto';
        const bottom = document.getElementById('bottomPos').value || 'auto';
        
        let horizontalOffset = 'auto';
        let verticalOffset = 'auto';
        
        if (left === '50%') {
            horizontalOffset = -(320 / 2);
        }
        if (top === '50%') {
            verticalOffset = -(320 / 2);
        }
        
        const width = 320;
        const height = 320;

        const maxSize = 80;
        const scale = Math.min(maxSize / width, maxSize / height, 1);
        const previewWidth = Math.round(width * scale);
        const previewHeight = Math.round(height * scale);

        previewPlayer.style.width = previewWidth + 'px';
        previewPlayer.style.height = previewHeight + 'px';
        previewPlayer.style.position = 'absolute';
        previewPlayer.style.left = left !== 'auto' ? left : 'auto';
        previewPlayer.style.right = right !== 'auto' ? right : 'auto';
        previewPlayer.style.top = top !== 'auto' ? top : 'auto';
        previewPlayer.style.bottom = bottom !== 'auto' ? bottom : 'auto';

        if (horizontalOffset !== 'auto' && horizontalOffset !== undefined) {
            const scaledOffset = Math.round(parseFloat(horizontalOffset) * scale);
            previewPlayer.style.marginLeft = scaledOffset + 'px';
        } else {
            previewPlayer.style.marginLeft = '0px';
        }
        if (verticalOffset !== 'auto' && verticalOffset !== undefined) {
            const scaledOffset = Math.round(parseFloat(verticalOffset) * scale);
            previewPlayer.style.marginTop = scaledOffset + 'px';
        } else {
            previewPlayer.style.marginTop = '0px';
        }

        const positionText = `${width}×${height}\n${left}, ${top}`;
        previewPlayer.textContent = positionText;
    },
    
    validatePositionValue(value) {
        value = value.trim();
        
        if (value === '' || value.toLowerCase() === 'auto') {
            return 'auto';
        }
        
        if (/^-?\d+\.?\d*$/.test(value)) {
            return value + 'px';
        }
        
        if (/^-?\d+\.?\d*%$/.test(value)) {
            return value;
        }
        
        if (/^-?\d+\.?\d*(px|em|rem|vh|vw|%)$/i.test(value)) {
            return value.toLowerCase();
        }
        
        return null;
    },
    
    /**
     * Load contact form submissions
     */
    loadContactSubmissions() {
        const container = document.getElementById('contactSubmissions');
        container.innerHTML = '<p>Loading submissions...</p>';
        
        fetch('contact_submissions.json')
            .then(response => {
                if (!response.ok) {
                    throw new Error('No submissions file found');
                }
                return response.json();
            })
            .then(submissions => {
                if (!submissions || submissions.length === 0) {
                    container.innerHTML = '<p style="color: #666;">No contact form submissions yet.</p>';
                    return;
                }
                
                submissions.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
                
                let html = '<div style="max-height: 400px; overflow-y: auto;">';
                submissions.forEach(sub => {
                    html += `
                        <div style="background: #f9f9f9; padding: 15px; margin-bottom: 10px; border-radius: 4px; border-left: 4px solid #0073FF;">
                            <div style="margin-bottom: 8px;">
                                <strong style="color: #0073FF;">${sub.name}</strong>
                                <span style="color: #666; font-size: 12px; float: right;">${sub.timestamp}</span>
                            </div>
                            <div style="margin-bottom: 8px; font-size: 14px;">
                                📧 <a href="mailto:${sub.email}">${sub.email}</a>
                            </div>
                            <div style="margin-bottom: 8px; color: #666; font-size: 12px;">
                                Video: ${sub.video_name} | To: ${sub.to_email}
                            </div>
                            <div style="padding: 10px; background: white; border-radius: 4px; font-size: 14px;">
                                ${sub.message.replace(/\n/g, '<br>')}
                            </div>
                        </div>
                    `;
                });
                html += '</div>';
                
                container.innerHTML = html;
            })
            .catch(error => {
                console.error('Error loading submissions:', error);
                container.innerHTML = '<p style="color: #999;">No submissions file found. Submissions will be saved here when email delivery fails.</p>';
            });
    },
    
    /**
     * Load email captures
     */
    loadEmailCaptures() {
        const container = document.getElementById('emailCaptures');
        container.innerHTML = '<p>Loading email captures...</p>';
        
        fetch('email_captures.json')
            .then(response => {
                if (!response.ok) {
                    throw new Error('No email captures file found');
                }
                return response.json();
            })
            .then(captures => {
                if (!captures || captures.length === 0) {
                    container.innerHTML = '<p style="color: #666;">No email captures yet.</p>';
                    return;
                }
                
                captures.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
                
                let html = '<div style="max-height: 400px; overflow-y: auto;">';
                captures.forEach(capture => {
                    html += `
                        <div style="background: #f0f8ff; padding: 15px; margin-bottom: 10px; border-radius: 4px; border-left: 4px solid #28a745;">
                            <div style="margin-bottom: 8px;">
                                <strong style="color: #28a745;">📧 Email Capture</strong>
                                <span style="color: #666; font-size: 12px; float: right;">${capture.timestamp}</span>
                            </div>
                            <div style="margin-bottom: 8px; font-size: 14px;">
                                📧 <a href="mailto:${capture.email}">${capture.email}</a>
                            </div>
                            <div style="margin-bottom: 8px; color: #666; font-size: 12px;">
                                Video: ${capture.video_name} | To: ${capture.to_email}
                            </div>
                            <div style="padding: 8px; background: white; border-radius: 4px; font-size: 12px; color: #666;">
                                Email captured from video exit behavior
                            </div>
                        </div>
                    `;
                });
                html += '</div>';
                
                container.innerHTML = html;
            })
            .catch(error => {
                console.error('Error loading email captures:', error);
                container.innerHTML = '<p style="color: #999;">No email captures file found. Email captures will be saved here when users submit their email.</p>';
            });
    }
};

// Global wrapper functions for backward compatibility with inline onclick handlers
function loadUrls() {
    AdminCommon.loadUrls();
}

function addUrl() {
    AdminCommon.addUrl();
}

function removeUrl(url) {
    AdminCommon.removeUrl(url);
}

function saveUrls() {
    AdminCommon.saveUrls();
}

function renderUrlList() {
    AdminCommon.renderUrlList();
}

function updatePositionUI(position) {
    AdminCommon.updatePositionUI(position);
}

function updatePreview() {
    AdminCommon.updatePreview();
}

function validatePositionValue(value) {
    return AdminCommon.validatePositionValue(value);
}

function loadContactSubmissions() {
    AdminCommon.loadContactSubmissions();
}

function loadEmailCaptures() {
    AdminCommon.loadEmailCaptures();
}
