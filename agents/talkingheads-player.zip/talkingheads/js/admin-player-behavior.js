/**
 * Admin Player Behavior Module
 * Handles player appearance and behavior settings
 */
const AdminPlayerBehavior = {
    /**
     * Initialize player behavior settings and event listeners
     */
    initializeSettings() {
        this.setupEventListeners();
        console.log('✅ Player behavior settings initialized');
    },
    
    /**
     * Load player behavior settings
     */
    loadSettings() {
        // Player behavior settings are now loaded as part of the main loadSettings() function
        console.log('✅ Player behavior settings loaded via main config');
    },
    
    /**
     * Setup event listeners for player behavior controls
     */
    setupEventListeners() {
        // Color picker synchronization
        document.getElementById('playerColor').addEventListener('input', () => {
            document.getElementById('playerColorText').value = document.getElementById('playerColor').value;
        });
        
        document.getElementById('playerColorText').addEventListener('input', () => {
            const colorText = document.getElementById('playerColorText').value;
            if (this.isValidHexColor(colorText)) {
                document.getElementById('playerColor').value = colorText;
            }
        });
        
        // Scroll threshold
        document.getElementById('scrollThreshold').addEventListener('input', function() {
            document.getElementById('scrollThresholdValue').textContent = this.value;
        });
    },
    
    /**
     * Reset player color to default
     */
    resetPlayerColor() {
        document.getElementById('playerColor').value = '#0073FF';
        document.getElementById('playerColorText').value = '#0073FF';
    },
    
    /**
     * Validate hex color format
     */
    isValidHexColor(hex) {
        return /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(hex);
    },
    
    /**
     * Save player behavior settings
     */
    async saveSettings() {
        const videoSelect = document.getElementById('videoSelect');
        const playerFile = videoSelect.value + '.js';
        
        // Collect all settings
        const settings = {
            color: document.getElementById('playerColor').value,
            scrollThreshold: parseFloat(document.getElementById('scrollThreshold').value),
            zIndex: parseInt(document.getElementById('playerZIndex').value)
        };
        
        try {
            // Load current player.js content
            const response = await fetch(playerFile);
            let content = await response.text();
            
            // Update each setting in the content
            content = content.replace(/color:\s*["'][^"']*["']/, `color: "${settings.color}"`);
            content = content.replace(/scrollThreshold:\s*[\d.]+/, `scrollThreshold: ${settings.scrollThreshold}`);
            content = content.replace(/zIndex:\s*\d+/, `zIndex: ${settings.zIndex}`);
            
            // Save updated content
            const saveResponse = await fetch('save-config.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `filename=${playerFile}&content=${encodeURIComponent(content)}`
            });
            
            if (saveResponse.ok) {
                this.showStatus('Player settings saved successfully!', 'success');
            } else {
                this.showStatus('Error saving player settings', 'danger');
            }
        } catch (error) {
            console.error('Error saving player settings:', error);
            this.showStatus('Error saving player settings: ' + error.message, 'danger');
        }
    },
    
    /**
     * Show status message
     */
    showStatus(message, type) {
        let statusDiv = document.getElementById('playerBehaviorStatus');
        if (!statusDiv) {
            statusDiv = document.createElement('div');
            statusDiv.id = 'playerBehaviorStatus';
            statusDiv.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 12px 20px;
                border-radius: 6px;
                color: white;
                font-weight: 500;
                z-index: 10000;
                transition: all 0.3s ease;
            `;
            document.body.appendChild(statusDiv);
        }
        
        statusDiv.textContent = message;
        statusDiv.style.backgroundColor = type === 'success' ? '#28a745' : '#dc3545';
        statusDiv.style.display = 'block';
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }
};

// Global wrapper functions for backward compatibility
function initializePlayerBehaviorSettings() {
    AdminPlayerBehavior.initializeSettings();
}

function loadPlayerBehaviorSettings() {
    AdminPlayerBehavior.loadSettings();
}

function setupPlayerBehaviorEventListeners() {
    AdminPlayerBehavior.setupEventListeners();
}

function resetPlayerColor() {
    AdminPlayerBehavior.resetPlayerColor();
}

function isValidHexColor(hex) {
    return AdminPlayerBehavior.isValidHexColor(hex);
}

function savePlayerBehaviorSettings() {
    AdminPlayerBehavior.saveSettings();
}

function showPlayerBehaviorStatus(message, type) {
    AdminPlayerBehavior.showStatus(message, type);
}
