/**
 * Admin Analytics Module
 * Handles all analytics and statistics display functionality
 */
const AdminAnalytics = {
    /**
     * Load and display analytics data for the current video
     */
    async loadAnalytics() {
        const videoName = document.getElementById('videoSelect').value;
        console.log('📊 Loading analytics for video:', videoName);
        
        // Try to load from JSON file first (primary storage)
        let stats = await this.loadStatsFromJson(videoName);
        let dataSource = 'JSON File';
        
        if (!stats) {
            console.log('📁 JSON file not available');
            stats = {
                totalViews: 0,
                uniqueVisitors: 0,
                completions: 0,
                totalWatchTime: 0
            };
            dataSource = 'No Data Available';
        }
        
        // Calculate completion rate
        const completionRate = stats.totalViews > 0 ? Math.round((stats.completions / stats.totalViews) * 100) : 0;
        
        // Calculate average watch time
        const avgWatchTime = stats.totalViews > 0 ? Math.round(stats.totalWatchTime / stats.totalViews) : 0;
        
        // Check player status (from sessionStorage - autoplay feature)
        const playerOnPage = sessionStorage.getItem(videoName + '_onPage') === 'true';
        
        // Update UI
        document.getElementById('uniqueVisits').textContent = stats.uniqueVisitors;
        document.getElementById('totalViews').textContent = stats.totalViews;
        document.getElementById('completionRate').textContent = completionRate + '%';
        document.getElementById('avgWatchTime').textContent = this.formatTime(avgWatchTime);
        document.getElementById('playerStatus').textContent = playerOnPage ? 'Online' : 'Offline';
        document.getElementById('statusIndicator').className = playerOnPage ? 'status-indicator status-online' : 'status-indicator status-offline';
        
        // Enhanced Analytics - Session Views
        const sessionViews = sessionStorage.getItem(videoName + '_session') || '0';
        document.getElementById('sessionViews').textContent = sessionViews;
        
        // Enhanced Analytics - Device Stats (simulated for demo)
        const deviceStats = this.getDeviceStats();
        document.getElementById('deviceBreakdown').textContent = deviceStats;
        
        // Enhanced Analytics - Exit Behavior (simulated for demo)
        const exitStats = this.getExitBehaviorStats();
        document.getElementById('exitBreakdown').textContent = exitStats;
        
        // Update video info
        document.getElementById('currentVideo').textContent = videoName;
        const resolvedPath = (typeof window.resolvePlayerPath === 'function')
            ? window.resolvePlayerPath()
            : (typeof window.currentPlayerPath === 'string' && window.currentPlayerPath.trim() !== '' ? window.currentPlayerPath : 'talkingheads');
        document.getElementById('videoPath').textContent = resolvedPath;
        const currentPoster = sessionStorage.getItem(videoName + '_poster') || 'Thumb';
        document.getElementById('videoPoster').textContent = currentPoster;
        
        // Update storage method indicator
        document.getElementById('storageMethod').textContent = dataSource;
        
        console.log('✅ Analytics loaded successfully from:', dataSource, stats);
    },
    
    /**
     * Load stats from JSON file (primary storage method)
     */
    async loadStatsFromJson(videoName) {
        try {
            const response = await fetch(`stats/${videoName}-stats.json`);
            
            if (response.ok) {
                const data = await response.json();
                
                // Validate JSON structure
                if (!data.stats) {
                    console.warn('⚠️ Invalid JSON file structure - missing stats object');
                    return null;
                }
                
                console.log('✅ Analytics loaded from JSON file:', {
                    videoName: data.videoName,
                    lastUpdated: data.lastUpdated,
                    stats: data.stats
                });
                return data.stats;
            } else if (response.status === 404) {
                console.log('📁 No JSON file found for', videoName);
                return null;
            } else {
                console.warn('⚠️ JSON file load failed - HTTP error:', response.status);
                return null;
            }
        } catch (error) {
            console.warn('⚠️ JSON file load failed - network/server error:', error);
            return null;
        }
    },
    
    /**
     * Format time in seconds to readable format
     */
    formatTime(seconds) {
        if (seconds < 60) {
            return seconds + 's';
        } else if (seconds < 3600) {
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = seconds % 60;
            return minutes + 'm ' + remainingSeconds + 's';
        } else {
            const hours = Math.floor(seconds / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            return hours + 'h ' + minutes + 'm';
        }
    },
    
    /**
     * Refresh analytics data
     */
    refreshAnalytics() {
        this.loadAnalytics();
    },
    
    /**
     * Get device statistics
     * In production, this would come from the JSON stats
     */
    getDeviceStats() {
        const userAgent = navigator.userAgent.toLowerCase();
        if (/tablet|ipad|playbook|silk/.test(userAgent)) {
            return 'Tablet: 1';
        } else if (/mobile|iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/.test(userAgent)) {
            return 'Mobile: 1';
        } else {
            return 'Desktop: 1';
        }
    },
    
    /**
     * Get exit behavior statistics
     * In production, this would come from the JSON stats
     */
    getExitBehaviorStats() {
        const exitBehaviors = ['No Action', 'Replay', 'Close', 'Contact', 'Email'];
        const randomBehavior = exitBehaviors[Math.floor(Math.random() * exitBehaviors.length)];
        return randomBehavior;
    },

    // --- Daily charts (30d) ---
    renderDailyCharts(stats) {
        if (!stats) return;
        const viewsByDay = stats.viewsByDay || {};
        const uniquesByDay = stats.uniquesByDay || {};
        const days = this.buildLastNDays(30);

        const views = days.map(d => Number(viewsByDay[d] || 0));
        const uniques = days.map(d => Number(uniquesByDay[d] || 0));

        const viewsCanvas = this.ensureCanvas('viewsChartCanvas', 'Daily Views (30d)');
        const uniquesCanvas = this.ensureCanvas('uniquesChartCanvas', 'Daily Unique Visitors (30d)');

        this.drawBarChart(viewsCanvas, views, '#4da3ff', days);
        this.drawBarChart(uniquesCanvas, uniques, '#9b59b6', days);
    },

    buildLastNDays(n) {
        const out = [];
        const today = new Date();
        for (let i = n - 1; i >= 0; i--) {
            const d = new Date(today);
            d.setDate(today.getDate() - i);
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            out.push(`${y}-${m}-${day}`);
        }
        return out;
    },

    ensureCanvas(id, labelText) {
        let container = document.getElementById('analyticsCharts');
        if (!container) {
            container = document.createElement('div');
            container.id = 'analyticsCharts';
            container.style.marginTop = '12px';
            const anchor = document.getElementById('analyticsRoot') || document.body;
            anchor.appendChild(container);
        }
        let wrapper = document.getElementById(id + '-wrapper');
        if (!wrapper) {
            wrapper = document.createElement('div');
            wrapper.id = id + '-wrapper';
            wrapper.style.margin = '8px 0';
            wrapper.style.position = 'relative';
            const label = document.createElement('div');
            label.textContent = labelText;
            label.style.fontWeight = '600';
            label.style.margin = '4px 0';
            const canvas = document.createElement('canvas');
            canvas.id = id;
            canvas.width = 600;
            canvas.height = 100;
            canvas.style.maxWidth = '100%';
            wrapper.appendChild(label);
            // Add DNT note for uniques chart
            if (id === 'uniquesChartCanvas') {
                const note = document.createElement('div');
                note.textContent = 'Uniques respect Do Not Track (DNT)';
                note.style.fontSize = '11px';
                note.style.opacity = '0.75';
                note.style.marginBottom = '2px';
                wrapper.appendChild(note);
            }
            wrapper.appendChild(canvas);
            container.appendChild(wrapper);
        }
        return document.getElementById(id);
    },

    drawBarChart(canvas, values, color, labels) {
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        ctx.clearRect(0, 0, width, height);

        const maxVal = Math.max(1, ...values);
        const barCount = values.length;
        const gap = 2;
        const barWidth = Math.max(1, Math.floor((width - (gap * (barCount - 1))) / barCount));

        values.forEach((v, i) => {
            const h = Math.round((v / maxVal) * (height - 10));
            const x = i * (barWidth + gap);
            const y = height - h;
            ctx.fillStyle = color;
            ctx.fillRect(x, y, barWidth, h);
        });

        // Tooltips on hover
        const wrapper = canvas.parentElement;
        let tip = wrapper.querySelector('.thp-chart-tooltip');
        if (!tip) {
            tip = document.createElement('div');
            tip.className = 'thp-chart-tooltip';
            tip.style.position = 'absolute';
            tip.style.pointerEvents = 'none';
            tip.style.background = 'rgba(0,0,0,0.8)';
            tip.style.color = '#fff';
            tip.style.fontSize = '11px';
            tip.style.padding = '3px 6px';
            tip.style.borderRadius = '4px';
            tip.style.display = 'none';
            wrapper.appendChild(tip);
        }
        if (!canvas._thpEventsBound) {
            canvas.addEventListener('mousemove', (e) => {
                const rect = canvas.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const idx = Math.floor(x / (barWidth + gap));
                if (idx < 0 || idx >= barCount) { tip.style.display = 'none'; return; }
                const mod = x % (barWidth + gap);
                if (mod > barWidth) { tip.style.display = 'none'; return; }
                const val = values[idx];
                const label = labels ? labels[idx] : String(idx);
                tip.textContent = `${label}: ${val}`;
                const tipX = Math.max(0, Math.min(width - 80, idx * (barWidth + gap) + Math.floor(barWidth / 2)));
                tip.style.left = tipX + 'px';
                tip.style.top = '0px';
                tip.style.display = 'block';
            });
            canvas.addEventListener('mouseleave', () => { tip.style.display = 'none'; });
            canvas._thpEventsBound = true;
        }
    }
};

// Global wrapper functions for backward compatibility with inline onclick handlers
function loadAnalytics() {
    AdminAnalytics.loadAnalytics();
}

function refreshAnalytics() {
    AdminAnalytics.refreshAnalytics();
}

