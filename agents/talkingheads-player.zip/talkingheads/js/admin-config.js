/**
 * Admin Configuration Module
 * Handles loading and saving player configuration settings
 */
const AdminConfig = {
    /**
     * Load settings from player.js file
     */
    loadSettings() {
        const videoSelect = document.getElementById('videoSelect');
        
        // Always use player.js (single player file system)
        // The videoName in config determines which video to use
        const actualPlayerFile = 'player.js';
        
        // Call admin.php to get VIDEO_CONFIG
        fetch('admin.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=getConfig&playerFile=' + encodeURIComponent(actualPlayerFile)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.config) {
                const config = data.config;
                const resolvedPath = this.normalizePath(config.path);
                config.path = resolvedPath;
                // Store loaded config for setupType access
                window.loadedConfig = { ...config };
                window.currentPlayerPath = resolvedPath;
                
                // Populate form fields with config values
                if (config.setupType) {
                    const setupTypeControl = document.getElementById('setupType');
                    if (setupTypeControl) setupTypeControl.value = config.setupType;
                }
                if (config.posterSelect) document.getElementById('posterSelect').value = config.posterImage || 'Thumb';
                document.getElementById('autostart').value = config.autostart || 'yes';
                if (config.timeStop !== undefined) document.getElementById('timeStop').value = config.timeStop || 1;
                document.getElementById('exitOnComplete').value = config.exitOnComplete || 'poster';
                document.getElementById('controlsMode').value = config.controlsMode || 'hover';
                if (config.contactEmail) document.getElementById('contactEmail').value = config.contactEmail || '';
                
                // Load position settings
                if (config.position) document.getElementById('positionType').value = config.position || 'fixed';
                if (config.left !== undefined) document.getElementById('leftPos').value = config.left || 'auto';
                if (config.right !== undefined) document.getElementById('rightPos').value = config.right || '0';
                if (config.top !== undefined) document.getElementById('topPos').value = config.top || 'auto';
                if (config.bottom !== undefined) document.getElementById('bottomPos').value = config.bottom || '0';
                
                // Determine and highlight which grid position matches these values
                const matchingGridPos = this.getGridPositionFromValues(
                    config.left || 'auto',
                    config.right || '0',
                    config.top || 'auto',
                    config.bottom || '0'
                );
                this.highlightGridPosition(matchingGridPos);
                
                // Load exit behavior conditional fields
                if (config.redirectURL !== undefined) document.getElementById('redirectURL').value = config.redirectURL;
                if (config.redirectDelay !== undefined) document.getElementById('redirectDelay').value = config.redirectDelay || '0';
                if (config.emailSubject !== undefined) document.getElementById('emailSubject').value = config.emailSubject || 'New lead from video';
                
                const pathInput = document.getElementById('playerPath');
                if (pathInput) {
                    pathInput.value = resolvedPath;
                }
                
                // Load Player Behavior Settings
                if (config.color) {
                    document.getElementById('playerColor').value = config.color;
                    document.getElementById('playerColorText').value = config.color;
                }
                if (config.scrollThreshold !== undefined) {
                    document.getElementById('scrollThreshold').value = config.scrollThreshold;
                    document.getElementById('scrollThresholdValue').textContent = config.scrollThreshold;
                }
                if (config.zIndex !== undefined) {
                    document.getElementById('playerZIndex').value = config.zIndex;
                }
                
                // Trigger change events to show/hide conditional fields
                document.getElementById('exitOnComplete').dispatchEvent(new Event('change'));
                document.getElementById('autostart').dispatchEvent(new Event('change'));
                document.getElementById('controlsMode').dispatchEvent(new Event('change'));
                
                // Update preview with loaded settings
                if (typeof updatePreview === 'function') {
                    setTimeout(updatePreview, 50);
                }
                
                console.log('✅ Settings loaded from ' + actualPlayerFile);
                
                // Also load Player Behavior Settings and Contact Form Settings
                if (typeof loadPlayerBehaviorSettings === 'function') {
                    loadPlayerBehaviorSettings();
                }
                if (typeof loadContactFormSettings === 'function') {
                    loadContactFormSettings();
                }
            } else {
                console.error('Failed to load settings:', data.error);
            }
        })
        .catch(error => {
            console.error('Error loading settings:', error);
        });
    },
    
    /**
     * Save settings to player.js file
     */
    saveSettings() {
        const videoSelect = document.getElementById('videoSelect');
        
        // Always use player.js (single player file system)
        // The videoName in config determines which video to use
        const actualPlayerFile = 'player.js';
        
        // Get selected video name directly from dropdown at save time
        const selectedVideoName = videoSelect?.value || '';
        
        if (!selectedVideoName) {
            alert('❌ Error: Please select a video before saving.');
            return;
        }
        
        // Get setupType if control exists, otherwise use loaded value or default
        const setupTypeControl = document.getElementById('setupType');
        const setupType = setupTypeControl ? setupTypeControl.value : (window.loadedConfig?.setupType || 'single');
        
        const pathInput = document.getElementById('playerPath');
        const resolvedPath = this.normalizePath(pathInput ? pathInput.value : '');
        
        // Build config object - videoName comes from dropdown, NOT from any loaded config
        const config = {
            setupType: setupType,
            videoName: selectedVideoName,
            posterImage: document.getElementById('posterSelect').value,
            autostart: document.getElementById('autostart').value,
            timeStop: parseFloat(document.getElementById('timeStop').value) || 1,
            exitOnComplete: document.getElementById('exitOnComplete').value,
            controlsMode: document.getElementById('controlsMode').value,
            contactEmail: document.getElementById('contactEmail').value,
            position: document.getElementById('positionType').value,
            redirectURL: document.getElementById('redirectURL').value,
            redirectDelay: parseInt(document.getElementById('redirectDelay').value) || 0,
            emailSubject: document.getElementById('emailSubject').value || 'New lead from video',
            scrollThreshold: parseFloat(document.getElementById('scrollThreshold').value) || 0.5,
            zIndex: parseInt(document.getElementById('playerZIndex').value) || 9999,
            color: document.getElementById('playerColor').value || '#0073FF',
            path: resolvedPath
        };
        window.currentPlayerPath = resolvedPath;
        window.loadedConfig = { ...(window.loadedConfig || {}), ...config };
        
        // Get position values from the active grid position button
        const activeButton = document.querySelector('.position-btn.active');
        if (activeButton) {
            const position = activeButton.dataset.position;
            const positions = {
                'top-left': { left: '0', right: 'auto', top: '0', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                'top-center': { left: '50%', right: 'auto', top: '0', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                'top-right': { left: 'auto', right: '0', top: '0', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                'middle-left': { left: '0', right: 'auto', top: '50%', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                'center': { left: '50%', right: 'auto', top: '50%', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                'middle-right': { left: 'auto', right: '0', top: '50%', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                'bottom-left': { left: '0', right: 'auto', top: 'auto', bottom: '0', horizontalOffset: 'auto', verticalOffset: 'auto' },
                'bottom-center': { left: '50%', right: 'auto', top: 'auto', bottom: '0', horizontalOffset: 'auto', verticalOffset: 'auto' },
                'bottom-right': { left: 'auto', right: '0', top: 'auto', bottom: '0', horizontalOffset: 'auto', verticalOffset: 'auto' }
            };
            
            if (positions[position]) {
                config.left = positions[position].left;
                config.right = positions[position].right;
                config.top = positions[position].top;
                config.bottom = positions[position].bottom;
                config.horizontalOffset = positions[position].horizontalOffset;
                config.verticalOffset = positions[position].verticalOffset;
            }
        }
        
        // Calculate proper offset values for centered positions
        if (config.left === '50%') {
            const width = config.width || 320;
            config.horizontalOffset = -(width / 2);
        } else {
            config.horizontalOffset = 0;
        }
        if (config.top === '50%') {
            const height = config.height || 320;
            config.verticalOffset = -(height / 2);
        } else {
            config.verticalOffset = 0;
        }
        
        // Convert numeric values to actual numbers
        const numericFields = ['timeStop', 'redirectDelay', 'zIndex', 'scrollThreshold', 'horizontalOffset', 'verticalOffset'];
        numericFields.forEach(field => {
            if (config[field] !== undefined && config[field] !== 'auto') {
                config[field] = Number(config[field]);
            }
        });
        
        // Validate position values
        const errors = [];
        ['left', 'right', 'top', 'bottom'].forEach(pos => {
            const value = config[pos];
            if (typeof value === 'string') {
                const trimmed = value.trim();
                
                if (trimmed !== 'auto' && 
                    !/^-?\d+\.?\d*$/.test(trimmed) &&
                    !/^-?\d+\.?\d*(px|em|rem|vh|vw|%)$/i.test(trimmed)) {
                    errors.push(pos + ' has invalid format. Use: auto, 100, 100px, 50%, etc.');
                }
            }
        });
        
        if (errors.length > 0) {
            alert('Validation errors:\n\n' + errors.join('\n'));
            return;
        }
        
        // Update UI with formatted values
        document.getElementById('leftPos').value = config.left;
        document.getElementById('rightPos').value = config.right;
        document.getElementById('topPos').value = config.top;
        document.getElementById('bottomPos').value = config.bottom;
        
        // Send to admin.php
        const formData = new FormData();
        formData.append('action', 'saveConfig');
        formData.append('playerFile', actualPlayerFile);
        
        // Explicitly ensure videoName is set from current selection
        if (!selectedVideoName) {
            console.error('⚠️ No video selected! Cannot save without videoName.');
            alert('❌ Error: No video selected. Please select a video first.');
            return;
        }
        
        // CRITICAL: Verify videoName matches dropdown before sending
        if (config.videoName !== selectedVideoName) {
            console.error('❌ MISMATCH! config.videoName is', config.videoName, 'but dropdown shows', selectedVideoName);
            // Force it to match dropdown
            config.videoName = selectedVideoName;
            console.warn('⚠️ Forced videoName to match dropdown:', config.videoName);
        }
        
        // Build config object with explicit videoName - do this AFTER videoName verification
        Object.keys(config).forEach(key => {
            const value = config[key];
            // Handle null/undefined values - but allow empty strings for some fields
            if (value !== null && value !== undefined) {
                formData.append('config[' + key + ']', value);
            }
        });
        
        // Double-check videoName is in formData
        console.log('📤 SENDING TO admin.php:');
        console.log('  Selected video (from dropdown):', selectedVideoName);
        console.log('  videoName in config object:', config.videoName);
        console.log('  Match:', config.videoName === selectedVideoName ? '✅' : '❌ MISMATCH!');
        console.log('  Player file:', actualPlayerFile);
        console.log('  Video select index:', videoSelect && videoSelect.tagName === 'SELECT' ? videoSelect.selectedIndex : 'N/A');
        console.log('  Full config object:', JSON.stringify(config, null, 2));
        console.log('  Config keys:', Object.keys(config));
        console.log('  exitOnComplete value:', config.exitOnComplete);
        console.log('  autostart value:', config.autostart);
        
        // Verify videoName is in FormData
        let formDataEntries = [];
        for (let [key, val] of formData.entries()) {
            formDataEntries.push(key + '=' + val);
        }
        console.log('  FormData entries (ALL):', formDataEntries);
        console.log('  FormData entries (videoName only):', formDataEntries.filter(e => e.includes('videoName')));
        
        fetch('admin.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            console.log('📥 RESPONSE DATA:', data);
            if (data.success) {
                // alert('✅ Settings saved to ' + actualPlayerFile + '!\n\nAll website visitors will see the new settings.');
                console.log('✅ Settings saved to ' + actualPlayerFile + '!\n\nAll website visitors will see the new settings.');
                // DO NOT reload settings after save - it would overwrite the user's current selection
                // User can manually reload if they want to see saved values
                
                if (data.version) {
                    sessionStorage.setItem('playerVersion', data.version);
                    console.log('✅ Cache version updated to:', data.version);
                }
            } else {
                // alert('❌ Error saving settings: ' + (data.error || 'Unknown error'));
                console.error('❌ Error saving settings: ' + (data.error || 'Unknown error'));
                console.error('Save error:', data);
            }
        })
        .catch(error => {
            console.error('❌ FETCH ERROR:', error);
            // alert('❌ Error communicating with server: ' + error);
            console.error('❌ Error communicating with server: ' + error);
        });
        
        // Also save contact form settings
        if (typeof saveContactFormSettings === 'function') {
            saveContactFormSettings();
        }
    },
    
    normalizePath(rawValue) {
        const fallback = 'talkingheads';
        if (typeof rawValue !== 'string') {
            return fallback;
        }
        const trimmed = rawValue.trim();
        if (!trimmed) {
            return fallback;
        }
        const withoutBackslashes = trimmed.replace(/\\/g, '/');
        const normalized = withoutBackslashes.replace(/\/+$/, '');
        return normalized || fallback;
    },
    
    /**
     * Determine which grid position matches the given position values
     */
    getGridPositionFromValues(left, right, top, bottom) {
        const positions = {
            'top-left': { left: '0', right: 'auto', top: '0', bottom: 'auto' },
            'top-center': { left: '50%', right: 'auto', top: '0', bottom: 'auto' },
            'top-right': { left: 'auto', right: '0', top: '0', bottom: 'auto' },
            'middle-left': { left: '0', right: 'auto', top: '50%', bottom: 'auto' },
            'center': { left: '50%', right: 'auto', top: '50%', bottom: 'auto' },
            'middle-right': { left: 'auto', right: '0', top: '50%', bottom: 'auto' },
            'bottom-left': { left: '0', right: 'auto', top: 'auto', bottom: '0' },
            'bottom-center': { left: '50%', right: 'auto', top: 'auto', bottom: '0' },
            'bottom-right': { left: 'auto', right: '0', top: 'auto', bottom: '0' }
        };
        
        for (const [posName, posValues] of Object.entries(positions)) {
            if (left === posValues.left && right === posValues.right && 
                top === posValues.top && bottom === posValues.bottom) {
                return posName;
            }
        }
        return null;
    },
    
    /**
     * Update grid button UI to show which position is active
     */
    highlightGridPosition(positionName) {
        document.querySelectorAll('.position-btn').forEach(btn => {
            btn.classList.remove('active', 'btn-primary');
            btn.classList.add('btn-outline-secondary');
        });
        if (positionName) {
            const activeBtn = document.querySelector(`[data-position="${positionName}"]`);
            if (activeBtn) {
                activeBtn.classList.add('active', 'btn-primary');
                activeBtn.classList.remove('btn-outline-secondary');
            }
        }
    }
};

// Global wrapper functions for backward compatibility
function loadSettings() {
    AdminConfig.loadSettings();
}

function saveSettings() {
    AdminConfig.saveSettings();
}

function getGridPositionFromValues(left, right, top, bottom) {
    return AdminConfig.getGridPositionFromValues(left, right, top, bottom);
}

function highlightGridPosition(positionName) {
    AdminConfig.highlightGridPosition(positionName);
}
