/**
 * Position Manager Module
 * Handles all positioning logic for the Talking Head Video Player
 * Extracted from player.js for better modularity
 */

class PositionManager {
    constructor(config, container = null) {
        this.config = config;
        this.container = container;
        
        // Store original position settings for reset functionality
        this.originalPosition = {
            position: config.position,
            left: config.left,
            right: config.right,
            top: config.top,
            bottom: config.bottom,
            horizontalOffset: config.horizontalOffset,
            verticalOffset: config.verticalOffset
        };
        
        // Position variables from config
        this.left = config.left;
        this.right = config.right;
        this.top = config.top;
        this.bottom = config.bottom;
        this.horizontalOffset = config.horizontalOffset;
        this.verticalOffset = config.verticalOffset;
    }
    
    /**
     * Apply position preset (top-left, top-center, etc.)
     */
    applyPositionPreset(position) {
        switch (position) {
            case 'top-left':
                this.config.left = "0";
                this.config.top = "0";
                this.config.right = "auto";
                this.config.bottom = "auto";
                this.config.horizontalOffset = "auto";
                this.config.verticalOffset = "auto";
                break;
            case 'top-center':
                this.config.left = "50%";
                this.config.horizontalOffset = "-" + (this.config.width / 2);
                this.config.top = "0";
                this.config.right = "auto";
                this.config.bottom = "auto";
                this.config.verticalOffset = "auto";
                break;
            case 'top-right':
                this.config.right = "0";
                this.config.top = "0";
                this.config.left = "auto";
                this.config.bottom = "auto";
                this.config.horizontalOffset = "auto";
                this.config.verticalOffset = "auto";
                break;
            case 'center':
                this.config.left = "50%";
                this.config.horizontalOffset = "-" + (this.config.width / 2);
                this.config.top = "50%";
                this.config.right = "auto";
                this.config.bottom = "auto";
                this.config.verticalOffset = "-" + (this.config.height / 2);
                break;
            case 'bottom-left':
                this.config.left = "0";
                this.config.bottom = "0";
                this.config.right = "auto";
                this.config.top = "auto";
                this.config.horizontalOffset = "auto";
                this.config.verticalOffset = "auto";
                break;
            case 'bottom-center':
                this.config.left = "50%";
                this.config.horizontalOffset = "-" + (this.config.width / 2);
                this.config.bottom = "0";
                this.config.right = "auto";
                this.config.top = "auto";
                this.config.verticalOffset = "auto";
                break;
            case 'bottom-right':
                this.config.right = "0";
                this.config.bottom = "0";
                this.config.left = "auto";
                this.config.top = "auto";
                this.config.horizontalOffset = "auto";
                this.config.verticalOffset = "auto";
                break;
            default:
                if (THP_DEBUG) console.warn('Unknown position preset:', position);
        }
        
        // Update local variables
        this.left = this.config.left;
        this.right = this.config.right;
        this.top = this.config.top;
        this.bottom = this.config.bottom;
        this.horizontalOffset = this.config.horizontalOffset;
        this.verticalOffset = this.config.verticalOffset;
    }
    
    /**
     * Load position settings from storage (from admin panel)
     */
    loadPositionFromStorage() {
        try {
            // Position values are now in VIDEO_CONFIG
            this.left = VIDEO_CONFIG.left;
            this.right = VIDEO_CONFIG.right;
            this.top = VIDEO_CONFIG.top;
            this.bottom = VIDEO_CONFIG.bottom;
            this.horizontalOffset = VIDEO_CONFIG.horizontalOffset;
            this.verticalOffset = VIDEO_CONFIG.verticalOffset;
            this.config.position = VIDEO_CONFIG.position;
            
        } catch (error) {
            console.error('Failed to load position from VIDEO_CONFIG:', error);
        }
    }
    
    /**
     * Apply position to container
     */
    applyPosition() {
        if (!this.container) {
            throw new Error('PositionManager: No container available for positioning! Container must be set before calling applyPosition()');
        }
        
        this.container.style.position = this.config.position;
        this.container.style.zIndex = this.config.zIndex;
        this.container.style.overflow = 'hidden';
        
        // Apply position values using helper functions
        this.setPositionValue('left', this.config.left);
        this.setPositionValue('right', this.config.right);
        this.setPositionValue('top', this.config.top);
        this.setPositionValue('bottom', this.config.bottom);
        
        // Apply offsets using margins (consistent with fallback version)
        if (this.config.horizontalOffset !== 'auto' && this.config.horizontalOffset !== undefined) {
            // Convert to number if it's a string
            let horizontalOffset = this.config.horizontalOffset;
            if (typeof horizontalOffset === 'string') {
                horizontalOffset = parseFloat(horizontalOffset);
                if (isNaN(horizontalOffset)) {
                    if (THP_DEBUG) console.warn('PositionManager: horizontalOffset is not a valid number, using 0. Original value:', this.config.horizontalOffset);
                    horizontalOffset = 0;
                }
            }
            if (typeof horizontalOffset !== 'number') {
                throw new Error(`PositionManager: horizontalOffset must be a number, got: ${typeof this.config.horizontalOffset} (${this.config.horizontalOffset})`);
            }
            this.container.style.marginLeft = horizontalOffset + 'px';
        }
        if (this.config.verticalOffset !== 'auto' && this.config.verticalOffset !== undefined) {
            // Convert to number if it's a string
            let verticalOffset = this.config.verticalOffset;
            if (typeof verticalOffset === 'string') {
                verticalOffset = parseFloat(verticalOffset);
                if (isNaN(verticalOffset)) {
                    if (THP_DEBUG) console.warn('PositionManager: verticalOffset is not a valid number, using 0:', this.config.verticalOffset);
                    verticalOffset = 0;
                }
            }
            if (typeof verticalOffset !== 'number') {
                throw new Error(`PositionManager: verticalOffset must be a number, got: ${typeof this.config.verticalOffset} (${this.config.verticalOffset})`);
            }
            this.container.style.marginTop = verticalOffset + 'px';
        }
    }
    
    /**
     * Set position value with validation
     */
    setPositionValue(property, value) {
        if (value && value !== 'auto') {
            this.container.style[property] = value;
        } else {
            this.container.style[property] = 'auto';
        }
    }
    
    /**
     * Reset to original position settings
     */
    resetToOriginalPosition() {
        if (this.originalPosition) {
            this.config.position = this.originalPosition.position;
            this.left = this.originalPosition.left;
            this.right = this.originalPosition.right;
            this.top = this.originalPosition.top;
            this.bottom = this.originalPosition.bottom;
            this.horizontalOffset = this.originalPosition.horizontalOffset;
            this.verticalOffset = this.originalPosition.verticalOffset;
            
            // Update config object
            this.config.left = this.left;
            this.config.right = this.right;
            this.config.top = this.top;
            this.config.bottom = this.bottom;
            this.config.horizontalOffset = this.horizontalOffset;
            this.config.verticalOffset = this.verticalOffset;
            
            if (this.container) {
                this.applyPosition();
            }
        }
    }
    
    /**
     * Set container reference
     */
    setContainer(container) {
        this.container = container;
    }
    
    /**
     * Position setter methods
     */
    setLeft(value) {
        this.config.left = value;
        this.applyPosition();
    }
    
    setRight(value) {
        this.config.right = value;
        this.applyPosition();
    }
    
    setTop(value) {
        this.config.top = value;
        this.applyPosition();
    }
    
    setBottom(value) {
        this.config.bottom = value;
        this.applyPosition();
    }
    
    setHorizontalOffset(value) {
        this.config.horizontalOffset = value;
        this.applyPosition();
    }
    
    setVerticalOffset(value) {
        this.config.verticalOffset = value;
        this.applyPosition();
    }
    
    /**
     * Get current position settings
     */
    getPositionSettings() {
        return {
            position: this.config.position,
            left: this.config.left,
            right: this.config.right,
            top: this.config.top,
            bottom: this.config.bottom,
            horizontalOffset: this.config.horizontalOffset,
            verticalOffset: this.config.verticalOffset
        };
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PositionManager;
} else if (typeof window !== 'undefined') {
    window.PositionManager = PositionManager;
}

