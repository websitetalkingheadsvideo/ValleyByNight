/**
 * Storage Manager Module
 * Handles localStorage, sessionStorage, and view tracking
 * Version: 0.9.2 - JSON-first storage for statistics
 * 
 * Changes in v0.8.0:
 * - JSON file is now the only storage for statistics
 * - Removed localStorage fallback system for simplicity
 * - Preserved localStorage for autoplay features only
 * - Enhanced error handling and logging
 */


// Debug flag for StorageManager (follows window.THP_DEBUG if present)
const SM_DEBUG = (typeof window !== 'undefined' && !!window.THP_DEBUG);

if (SM_DEBUG) console.log('📦 Storage Manager module loaded'); // v0.9.2

class StorageManager {
    constructor(videoName) {
        this.videoName = videoName;
        this.sessionViewCount = 0;
        this.totalViewCount = 0;
        this.startedViews = 0; // Tracks all views that started playing (even if < 25%)
        this.uniqueVisits = 0;
        this.completionCount = 0;
        this.totalWatchTime = 0;
        this.sessionStartTime = 0;
        this.hasCompleted = false;
        this.playerOnPage = true;
        this.currentVolume = 1.0;
        this.contactEmail = '';
        this.isPaused = false; // Track if video is currently paused
        // Track uniques per page load only (no session/local storage for tracking)
        this._uniqueCountedThisLoad = false;
    }

    /**
     * Save volume to localStorage
     */
    saveVolumeToStorage() {
        try {
            localStorage.setItem(this.videoName, this.currentVolume.toString());
        } catch (error) {
            console.error('Failed to save volume to localStorage:', error);
        }
    }

    /**
     * Load volume from localStorage
     */
    loadVolumeFromStorage() {
        try {
            const savedVolume = localStorage.getItem(this.videoName);
            if (savedVolume !== null) {
                this.currentVolume = parseFloat(savedVolume);
                return this.currentVolume;
            }
        } catch (error) {
            console.error('Failed to load volume from localStorage:', error);
        }
        return 1.0; // Default volume
    }

    /**
     * Start session timer for watch time tracking
     */
    startSessionTimer() {
        // Only start timer if not already running to avoid resetting mid-session
        if (this.sessionStartTime === 0) {
            this.sessionStartTime = Date.now();
            if (SM_DEBUG) console.log(`⏱️ Timer started at ${new Date(this.sessionStartTime).toISOString()}`);
        } else {
            if (SM_DEBUG) console.log(`⏱️ Timer already running (started ${Math.round((Date.now() - this.sessionStartTime) / 1000)}s ago)`);
        }
    }

    /**
     * Track when a video starts playing (counts all starts, even if < 25%)
     */
    trackVideoStart() {
        this.startedViews++;
        if (SM_DEBUG) console.log(`▶️ Video started - total started views: ${this.startedViews}`);
        // Save immediately to ensure it's persisted
        this.saveViewCountsToStorage();
    }

    /**
     * Increment view count and track unique visitors
     */
    incrementViewCount() {
        this.sessionViewCount++;
        this.totalViewCount++;
        
        // Start session timer for watch time tracking
        this.startSessionTimer();
        
        // Check if this is a new unique visitor
        this.checkUniqueVisitor();
        
        // Save to storage
        this.saveViewCountsToStorage();
    }

    /**
     * Check and increment unique visitor count
     */
    checkUniqueVisitor() {
        // Increment unique once per page load (no browser storage used)
        if (!this._uniqueCountedThisLoad) {
            this.uniqueVisits++;
            this._uniqueCountedThisLoad = true;
        }
    }

    // getVisitorId removed: uniques tracked per page load only

    /**
     * Save view counts to storage (JSON file only)
     */
    async saveViewCountsToStorage() {
        try {
            // Save to JSON file on server (JSON-only metrics persistence)
            await this.saveToJsonFile();
            
        } catch (error) {
            console.error('❌ Error saving statistics to JSON:', error);
            throw error; // Re-throw to let caller handle
        }
    }

    /**
     * Load view counts from storage (JSON file only)
     */
    async loadViewCountsFromStorage() {
        if (SM_DEBUG) console.log('🔧 loadViewCountsFromStorage called for video:', this.videoName);
        try {
            
            // Load from JSON file
            if (SM_DEBUG) console.log('🔧 Loading from JSON file');
            await this.loadFromJsonFile();
            
            // Load other settings from localStorage (autoplay features - always from localStorage)
            const onPage = localStorage.getItem(this.videoName + '_onPage');
            if (onPage !== null) {
                this.playerOnPage = onPage === 'true';
            }
            
        } catch (error) {
            console.error('Failed to load view counts from storage:', error);
            throw error; // Re-throw to let caller handle
        }
    }


    /**
     * Load contact email from storage
     */
    loadContactEmailFromStorage() {
        try {
            const savedEmail = localStorage.getItem(this.videoName + '_contactEmail');
            if (savedEmail !== null) {
                this.contactEmail = savedEmail;
                return savedEmail;
            }
        } catch (error) {
            console.error('Failed to load contact email from storage:', error);
        }
        return '';
    }

    /**
     * Save contact email to storage
     */
    saveContactEmailToStorage(email) {
        try {
            this.contactEmail = email;
            localStorage.setItem(this.videoName + '_contactEmail', email);
        } catch (error) {
            console.error('Failed to save contact email to storage:', error);
        }
    }

    /**
     * Get all watch statistics
     */
    getAllWatchStats() {
        const abandonedViews = this.startedViews - this.totalViewCount; // Started but didn't reach 25%
        return {
            sessionViews: this.sessionViewCount,
            totalViews: this.totalViewCount,
            startedViews: this.startedViews,
            abandonedViews: abandonedViews,
            uniqueVisitors: this.uniqueVisits,
            completions: this.completionCount,
            totalWatchTime: this.totalWatchTime,
            averageWatchTime: this.totalViewCount > 0 ? Math.round(this.totalWatchTime / this.totalViewCount) : 0,
            completionRate: this.totalViewCount > 0 ? Math.round((this.completionCount / this.totalViewCount) * 100) : 0,
            engagementRate: this.startedViews > 0 ? Math.round((this.totalViewCount / this.startedViews) * 100) : 0 // % who reached 25%
        };
    }

    /**
     * Track video pause and accumulate watch time
     */
    trackVideoPause() {
        if (this.sessionStartTime > 0) {
            const watchTime = Math.round((Date.now() - this.sessionStartTime) / 1000);
            // Only accumulate if watch time is positive and reasonable (not more than video duration * 2)
            // This prevents accumulation errors from timer issues
            if (watchTime > 0 && watchTime < 3600) { // Max 1 hour per session (safety check)
                if (SM_DEBUG) console.log(`⏱️ Tracking pause: accumulated ${watchTime}s (total: ${this.totalWatchTime + watchTime}s)`);
                this.totalWatchTime += watchTime;
            } else {
                if (SM_DEBUG) console.warn(`⚠️ Invalid watch time detected: ${watchTime}s - not accumulating`);
            }
            // Stop the timer (set to 0) - it will restart when video resumes
            this.sessionStartTime = 0;
        } else {
            if (SM_DEBUG) console.log('⏱️ trackVideoPause() called but timer not running (sessionStartTime is 0)');
        }
        
        // Save updated metrics
        this.saveViewCountsToStorage();
    }

    /**
     * Track video completion
     */
    trackVideoCompletion() {
        if (!this.hasCompleted) {
            this.completionCount++;
            this.hasCompleted = true;
        }
        
        if (this.sessionStartTime > 0) {
            const watchTime = Math.round((Date.now() - this.sessionStartTime) / 1000);
            this.totalWatchTime += watchTime;
            // Stop the timer after completion
            this.sessionStartTime = 0;
        }
        
        // Reset hasCompleted flag after tracking to allow future completions
        this.hasCompleted = false;
        
        // Save updated metrics
        this.saveViewCountsToStorage();
    }

    /**
     * Reset session view count
     */
    resetSessionViewCount() {
        this.sessionViewCount = 0;
        try {
            if (SM_DEBUG) console.log('Session view count reset for video:', this.videoName);
        } catch (error) {
            console.error('Failed to reset session view count:', error);
        }
    }

    /**
     * Reset all view counts
     */
    resetAllViewCounts() {
        this.sessionViewCount = 0;
        this.totalViewCount = 0;
        this.uniqueVisits = 0;
        this.completionCount = 0;
        this.totalWatchTime = 0;
        
        try {
            if (SM_DEBUG) console.log('All view counts reset for video:', this.videoName);
        } catch (error) {
            console.error('Failed to reset all view counts:', error);
        }
    }

    /**
     * Export watch statistics as JSON
     */
    exportWatchStats() {
        const stats = this.getAllWatchStats();
        stats.videoName = this.videoName;
        stats.exportDate = new Date().toISOString();
        return JSON.stringify(stats, null, 2);
    }

    // Removed legacy storage helpers (get/set/remove/clear) not used for metrics

    /**
     * Save view counts to JSON file on server (primary storage method)
     */
    async saveToJsonFile() {
        const maxRetries = 3;
        const retryDelay = 1000; // 1 second
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                const stats = this.getAllWatchStats();
                const data = {
                    videoName: this.videoName,
                    lastUpdated: new Date().toISOString(),
                    stats: stats
                };

                if (SM_DEBUG) console.log(`💾 Saving statistics to JSON file (attempt ${attempt}/${maxRetries}):`, stats);

                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

                const basePath = (window.VIDEO_CONFIG && window.VIDEO_CONFIG.path) ? window.VIDEO_CONFIG.path.replace(/\/$/, '') : 'talkingheads';
                const response = await fetch(`${basePath}/save-stats.php`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data),
                    signal: controller.signal
                });

                clearTimeout(timeoutId);

                if (response.ok) {
                    const result = await response.json();
                    if (SM_DEBUG) console.log('✅ Statistics successfully saved to JSON file:', result);
                    return true;
                } else {
                    const errorText = await response.text();
                    if (SM_DEBUG) console.warn(`⚠️ Failed to save stats to JSON file - HTTP ${response.status}:`, errorText);
                    
                    // Don't retry for certain HTTP errors
                    if (response.status === 400 || response.status === 422) {
                        console.error('❌ Bad request - not retrying:', errorText);
                        return false;
                    }
                    
                    // Retry for server errors and network issues
                    if (attempt < maxRetries) {
                        if (SM_DEBUG) console.log(`🔄 Retrying in ${retryDelay}ms...`);
                        await this.sleep(retryDelay * attempt); // Exponential backoff
                        continue;
                    }
                    
                    return false;
                }
            } catch (error) {
                if (error.name === 'AbortError') {
                    if (SM_DEBUG) console.warn('⚠️ JSON file save timed out');
                } else {
                    if (SM_DEBUG) console.warn('⚠️ JSON file save failed - network/server error:', error.message);
                }
                
                // Retry for network errors
                if (attempt < maxRetries) {
                    if (SM_DEBUG) console.log(`🔄 Retrying in ${retryDelay}ms...`);
                    await this.sleep(retryDelay * attempt); // Exponential backoff
                    continue;
                }
                
                return false;
            }
        }
        
        console.error('❌ All retry attempts failed for JSON file save');
        return false;
    }

    /**
     * Load view counts from JSON file on server (primary storage method)
     */
    async loadFromJsonFile() {
        const maxRetries = 2;
        const retryDelay = 500; // 500ms
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                const basePath = (window.VIDEO_CONFIG && window.VIDEO_CONFIG.path) ? window.VIDEO_CONFIG.path.replace(/\/$/, '') : 'talkingheads';
                const jsonUrl = `${basePath}/stats/${this.videoName}-stats.json`;
                if (SM_DEBUG) console.log(`🔍 Attempting to load statistics from JSON file (attempt ${attempt}/${maxRetries}):`, jsonUrl);
                
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
                
                const response = await fetch(jsonUrl, {
                    signal: controller.signal,
                    cache: 'no-cache' // Ensure we get fresh data
                });
                
                clearTimeout(timeoutId);
                
                if (response.ok) {
                    const data = await response.json();
                    
                    // Validate JSON structure
                    if (!data || typeof data !== 'object') {
                        if (SM_DEBUG) console.warn('⚠️ Invalid JSON file - not an object');
                        if (attempt < maxRetries) {
                            if (SM_DEBUG) console.log(`🔄 Retrying in ${retryDelay}ms...`);
                            await this.sleep(retryDelay);
                            continue;
                        }
                        return false;
                    }
                    
                    if (!data.stats || typeof data.stats !== 'object') {
                        if (SM_DEBUG) console.warn('⚠️ Invalid JSON file structure - missing or invalid stats object');
                        if (attempt < maxRetries) {
                            if (SM_DEBUG) console.log(`🔄 Retrying in ${retryDelay}ms...`);
                            await this.sleep(retryDelay);
                            continue;
                        }
                        return false;
                    }
                    
                    // Validate stats data types
                    const stats = data.stats;
                    if (typeof stats.totalViews !== 'number' || 
                        typeof stats.uniqueVisitors !== 'number' || 
                        typeof stats.completions !== 'number' || 
                        typeof stats.totalWatchTime !== 'number') {
                        if (SM_DEBUG) console.warn('⚠️ Invalid JSON file - stats contain non-numeric values');
                        if (attempt < maxRetries) {
                            if (SM_DEBUG) console.log(`🔄 Retrying in ${retryDelay}ms...`);
                            await this.sleep(retryDelay);
                            continue;
                        }
                        return false;
                    }
                    
                    // Update local counts from JSON file
                    // Only update if current value is 0 (to prevent overwriting increments that happened before load completed)
                    this.totalViewCount = Math.max(this.totalViewCount, stats.totalViews || 0);
                    this.startedViews = Math.max(this.startedViews, stats.startedViews || 0); // Don't overwrite if already incremented
                    this.uniqueVisits = Math.max(this.uniqueVisits, stats.uniqueVisitors || 0);
                    this.completionCount = Math.max(this.completionCount, stats.completions || 0);
                    this.totalWatchTime = Math.max(this.totalWatchTime, stats.totalWatchTime || 0);
                    
                    if (SM_DEBUG) console.log('✅ Statistics successfully loaded from JSON file:', {
                        totalViews: this.totalViewCount,
                        startedViews: this.startedViews,
                        uniqueVisits: this.uniqueVisits,
                        completions: this.completionCount,
                        totalWatchTime: this.totalWatchTime,
                        lastUpdated: data.lastUpdated
                    });
                    return true;
                    
                } else if (response.status === 404) {
                    if (SM_DEBUG) console.log('📁 No JSON file found (404)');
                    return false;
                } else if (response.status === 403) {
                    if (SM_DEBUG) console.warn('⚠️ JSON file access forbidden (403)');
                    return false;
                } else if (response.status >= 500) {
                    if (SM_DEBUG) console.warn(`⚠️ Server error (${response.status}) - will retry`);
                    if (attempt < maxRetries) {
                        if (SM_DEBUG) console.log(`🔄 Retrying in ${retryDelay}ms...`);
                        await this.sleep(retryDelay);
                        continue;
                    }
                    return false;
                } else {
                    if (SM_DEBUG) console.warn(`⚠️ JSON file load failed - HTTP error: ${response.status}`);
                    return false;
                }
                
            } catch (error) {
                if (error.name === 'AbortError') {
                    if (SM_DEBUG) console.warn('⚠️ JSON file load timed out');
                } else if (error.name === 'TypeError' && error.message.includes('fetch')) {
                    if (SM_DEBUG) console.warn('⚠️ Network error - fetch failed:', error.message);
                } else {
                    if (SM_DEBUG) console.warn('⚠️ JSON file load failed - error:', error.message);
                }
                
                // Retry for network errors and timeouts
                if (attempt < maxRetries) {
                    if (SM_DEBUG) console.log(`🔄 Retrying in ${retryDelay}ms...`);
                    await this.sleep(retryDelay);
                    continue;
                }
                
                return false;
            }
        }
        
        if (SM_DEBUG) console.warn('⚠️ All retry attempts failed for JSON file load');
        return false;
    }

    /**
     * Get JSON file path for this video
     */
    getJsonFilePath() {
        const basePath = (window.VIDEO_CONFIG && window.VIDEO_CONFIG.path) ? window.VIDEO_CONFIG.path.replace(/\/$/, '') : 'talkingheads';
        return `${basePath}/stats/${this.videoName}-stats.json`;
    }

    /**
     * Sleep utility for retry delays
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = StorageManager;
} else if (typeof window !== 'undefined') {
    // Always export as VideoStorageManager to avoid conflicts with browser's native StorageManager API
    window.VideoStorageManager = StorageManager;
    // Only export as StorageManager if browser hasn't already defined it
    // Check by trying to see if existing StorageManager is constructible
    try {
        // If browser's native StorageManager exists, it will fail this check
        const test = window.StorageManager;
        if (!test || (test.prototype && test.prototype.constructor === StorageManager)) {
            window.StorageManager = StorageManager;
        }
    } catch (e) {
        // Browser's StorageManager might not be assignable, that's fine - we have VideoStorageManager
    }
    
    // Ensure our class is definitely available
    if (SM_DEBUG) console.log('📦 StorageManager exported as VideoStorageManager');
}






