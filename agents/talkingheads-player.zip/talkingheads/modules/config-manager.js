/**
 * Configuration Manager Module
 * Handles VIDEO_CONFIG and configuration validation
 * Version: 0.8.0 (VIDEO_CONFIG-only)
 */

class ConfigManager {
    constructor(videoConfig) {
        const normalizedConfig = { ...videoConfig };
        if (normalizedConfig.poster && !normalizedConfig.posterImage) {
            normalizedConfig.posterImage = normalizedConfig.poster;
        }
        if (normalizedConfig.posterImage && !normalizedConfig.poster) {
            normalizedConfig.poster = normalizedConfig.posterImage;
        }

        this.config = { ...normalizedConfig };
        this.originalConfig = { ...normalizedConfig };
        const resolvedPath = this.normalizePath(this.config.path);
        this.config.path = resolvedPath;
        this.originalConfig.path = resolvedPath;
    }

    // URL parameter parsing has been removed. VIDEO_CONFIG is the sole source of behavior.

    /**
     * Apply settings from config.json video configuration
     * @param {Object} videoConfig - Video configuration from config.json
     */
    applyConfigSettings(videoConfig) {
        if (videoConfig.videoName) this.config.videoName = videoConfig.videoName;
        const posterValue = videoConfig.posterImage || videoConfig.poster;
        if (posterValue) {
            this.config.posterImage = posterValue;
            this.config.poster = posterValue;
        }
        if (videoConfig.autostart) this.config.autostart = videoConfig.autostart;
        if (videoConfig.path) {
            this.config.path = this.normalizePath(videoConfig.path);
        }
        // No localStorage writes: behavior comes only from VIDEO_CONFIG
    }

    


    /**
     * Get current configuration
     * @returns {Object} Current configuration object
     */
    getConfig() {
        return { ...this.config };
    }

    /**
     * Get URL parameters
     * @returns {Object} URL parameters object
     */
    // URL parameters are not used; VIDEO_CONFIG is authoritative

    /**
     * Reset configuration to original values
     */
    resetConfig() {
        this.config = { ...this.originalConfig };
    }

    /**
     * Update configuration value
     * @param {string} key - Configuration key
     * @param {*} value - Configuration value
     */
    updateConfig(key, value) {
        if (key === 'path') {
            this.config.path = this.normalizePath(value);
            return;
        }
        if (this.config.hasOwnProperty(key)) {
            this.config[key] = value;
        } else {
            console.warn(`Configuration key '${key}' does not exist`);
        }
    }

    normalizePath(pathValue) {
        const fallback = 'talkingheads';
        if (typeof pathValue !== 'string') {
            return fallback;
        }
        const trimmed = pathValue.trim();
        if (!trimmed) {
            return fallback;
        }
        const normalized = trimmed.replace(/\\/g, '/').replace(/\/+$/, '');
        return normalized || fallback;
    }

    /**
     * Validate configuration values
     * @returns {Object} Validation result with errors array
     */
    validateConfig() {
        const errors = [];
        
        // Validate required fields
        if (!this.config.videoName) {
            errors.push('videoName is required');
        }
        if (!this.config.posterImage && !this.config.poster) {
            errors.push('posterImage is required');
        }
        
        // Validate autostart values
        const validAutostartModes = ['yes', 'mute', 'loop', 'poster', 'once', 'onceLocal', 'hover', 'scroll', 'delay', 'slide', 'gostopgo'];
        if (this.config.autostart && !validAutostartModes.includes(this.config.autostart)) {
            errors.push(`Invalid autostart mode: ${this.config.autostart}`);
        }
        
        // Validate position values
        const validPositions = ['fixed', 'absolute'];
        if (this.config.position && !validPositions.includes(this.config.position)) {
            errors.push(`Invalid position type: ${this.config.position}`);
        }
        
        // Validate exit behaviors
        const validExitBehaviors = ['no', 'close', 'poster', 'contact', 'email', 'redirect'];
        if (this.config.exitOnComplete && !validExitBehaviors.includes(this.config.exitOnComplete)) {
            errors.push(`Invalid exit behavior: ${this.config.exitOnComplete}`);
        }

        if (!this.config.path || typeof this.config.path !== 'string') {
            errors.push('path is required');
        }
        
        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ConfigManager;
} else if (typeof window !== 'undefined') {
    window.ConfigManager = ConfigManager;
}

