// Talking Head Video Player - Version 0.10.21
// Self-Contained JavaScript Player - No HTML Required
// Multi-Video Support with Config.json and URL Matching
// Automatically loads required modules internally

// ========== SITE CONFIGURATION ==========
// Set this when creating the package:
// - Set to 1 for single video (no config.json needed)
// - Set to 2+ for multiple videos (requires config.json with URL matching)
// This can be updated via admin panel's "Update Video Count" button
const SITE_VIDEO_COUNT = 1;
// Debug flag (set window.THP_DEBUG = true in console to enable verbose logs)
const THP_DEBUG = (typeof window !== 'undefined' && !!window.THP_DEBUG);
// ========================================

// ========== VIDEO CONFIGURATION (EDITABLE BY ADMIN PANEL) ==========
// This object contains all settings that can be configured via admin.php
// When admin.php saves changes, it updates this object and saves the file
const VIDEO_CONFIG = {
    setupType: "single",
    videoName: "angelica",
    poster: "angelica",
    posterImage: "angelica",
    autostart: "yes",
    timeStop: 1,
    exitOnComplete: "poster",
    controlsMode: "hover",
    contactEmail: "",
    position: "fixed",
    redirectURL: "",
    redirectDelay: 0,
    emailSubject: "auto",
    scrollThreshold: 0.5,
    zIndex: 9999,
    color: "#0073ff",
    path: "talkingheads",
    width: 320,
    height: 320,
    left: "auto",
    right: "0",
    top: "auto",
    bottom: "0",
    horizontalOffset: 0,
    verticalOffset: 0
};
// ==================================================================





class TalkingHeadPlayer {
    constructor() {
        // Flag to prevent redundant positioning calls
        this.positionApplied = false;
        
        // Initialize Configuration Manager (modules required)
        if (typeof window.ConfigManager !== 'undefined') {
            this.configManager = new window.ConfigManager(VIDEO_CONFIG);
        } else {
            console.error('❌ ConfigManager module not loaded. Please ensure modules/config-manager.js is loaded before player.js');
            throw new Error('ConfigManager module is required but not loaded');
        }
        
        // Apply configuration from VIDEO_CONFIG (sole source)
        this.path = this.normalizePath(VIDEO_CONFIG.path);
        VIDEO_CONFIG.path = this.path;
        this.videoName = VIDEO_CONFIG.videoName;
        this.posterImage = VIDEO_CONFIG.posterImage || VIDEO_CONFIG.poster || "";
        this.poster = this.posterImage;
        if (!VIDEO_CONFIG.posterImage && this.posterImage) {
            VIDEO_CONFIG.posterImage = this.posterImage;
        }
        if (!VIDEO_CONFIG.poster && this.posterImage) {
            VIDEO_CONFIG.poster = this.posterImage;
        }
        
        // Initialize Storage Manager (modules required) - AFTER videoName is set
        // MUST use VideoStorageManager to avoid conflicts with browser's native StorageManager API
        if (typeof window.VideoStorageManager !== 'undefined' && window.VideoStorageManager instanceof Function) {
            // Verify it's constructible by checking if it's actually our class
            try {
                if (THP_DEBUG) console.log('🔍 Creating VideoStorageManager instance...', typeof window.VideoStorageManager, window.VideoStorageManager.name || 'unnamed');
                this.storageManager = new window.VideoStorageManager(this.videoName);
            } catch (e) {
                console.error('❌ Failed to construct VideoStorageManager:', e);
                throw new Error('VideoStorageManager constructor failed: ' + e.message);
            }
        } else {
            console.error('❌ VideoStorageManager module not loaded. Type:', typeof window.VideoStorageManager);
            throw new Error('VideoStorageManager module is required but not loaded');
        }
        
        // Position settings are now handled by PositionManager
        this.contactEmail = VIDEO_CONFIG.contactEmail;
        
        // Autostart comes only from VIDEO_CONFIG
        this.autostart = VIDEO_CONFIG.autostart;

        // Video dimension variables
        this.timeStop = VIDEO_CONFIG.timeStop;
        this.scrollThreshold = VIDEO_CONFIG.scrollThreshold;

        // Position variables are now handled by PositionManager
        
        // Normalize legacy position keys before handing off to PositionManager
        const resolvedHorizontalOffset = (VIDEO_CONFIG.horizontalOffset !== undefined && VIDEO_CONFIG.horizontalOffset !== null)
            ? VIDEO_CONFIG.horizontalOffset
            : (VIDEO_CONFIG.centerOffset !== undefined ? VIDEO_CONFIG.centerOffset : 0);
        const resolvedVerticalOffset = (VIDEO_CONFIG.verticalOffset !== undefined && VIDEO_CONFIG.verticalOffset !== null)
            ? VIDEO_CONFIG.verticalOffset
            : (VIDEO_CONFIG.centerOffsetY !== undefined
                ? VIDEO_CONFIG.centerOffsetY
                : (VIDEO_CONFIG.centerOffsetVertical !== undefined ? VIDEO_CONFIG.centerOffsetVertical : 0));

        VIDEO_CONFIG.horizontalOffset = resolvedHorizontalOffset;
        VIDEO_CONFIG.verticalOffset = resolvedVerticalOffset;

        if ((VIDEO_CONFIG.horizontalOffset === undefined || VIDEO_CONFIG.horizontalOffset === null || VIDEO_CONFIG.horizontalOffset === 'auto')
            && VIDEO_CONFIG.left === '50%') {
            const widthForOffset = VIDEO_CONFIG.width || 320;
            VIDEO_CONFIG.horizontalOffset = -(widthForOffset / 2);
        }

        if ((VIDEO_CONFIG.verticalOffset === undefined || VIDEO_CONFIG.verticalOffset === null || VIDEO_CONFIG.verticalOffset === 'auto')
            && VIDEO_CONFIG.top === '50%') {
            const heightForOffset = VIDEO_CONFIG.height || 320;
            VIDEO_CONFIG.verticalOffset = -(heightForOffset / 2);
        }

        // Configuration for positioning and controls
        this.config = {
            position: VIDEO_CONFIG.position,
            left: VIDEO_CONFIG.left,
            right: VIDEO_CONFIG.right,
            top: VIDEO_CONFIG.top,
            bottom: VIDEO_CONFIG.bottom,
            horizontalOffset: VIDEO_CONFIG.horizontalOffset,
            verticalOffset: VIDEO_CONFIG.verticalOffset,
            width: VIDEO_CONFIG.width,
            height: VIDEO_CONFIG.height,
            zIndex: VIDEO_CONFIG.zIndex,
            controlsMode: VIDEO_CONFIG.controlsMode
        };
        
        // Initialize Position Manager - FAIL if not available
        if (typeof window.PositionManager !== 'undefined') {
            this.positionManager = new window.PositionManager(this.config);
        } else {
            throw new Error('PositionManager module not loaded! Check that position-manager.js is included before player.js');
        }
        
        // Simple page URL configuration for site-wide usage
        this.showOnPages = [];
        
        // Color configuration with fallback
        this.color = VIDEO_CONFIG.color || '#0073FF'; // Default to blue if undefined
        
        // Duration bar state
        this.isDragging = false;
        
        // Volume bar state
        this.isVolumeDragging = false;
        this.currentVolume = 1.0;
        
        // Loop mode state
        this.loopMode = false;
        
        // View tracking variables
        this.hasViewed = false;
        this.hasStartedTracking = false; // Track if we've counted this video start
        this.playerOnPage = true;
        
        // Statistics are now handled by StorageManager
        // All statistics operations should go through this.storageManager
        // StorageManager owns session timing
        this.hasCompleted = false;
        
        // Once mode flags
        this.shouldCreatePlayer = true;
        this.isPosterOnlyMode = false;
        
        // Control hover event handler references (for proper cleanup)
        this.controlHoverEnterHandler = null;
        this.controlHoverLeaveHandler = null;
        this.isContainerHovered = false; // Track hover state
        
        // Initialize directly from VIDEO_CONFIG (no URL/config.json overrides)
        // Prepare icons and base styles before building UI
        this.initIconCache();
        this.ensureBaseStyles();
        this.init();
    }
    
    normalizePath(pathValue) {
        const fallback = 'talkingheads';
        if (typeof pathValue !== 'string') {
            return fallback;
        }
        const trimmed = pathValue.trim();
        if (!trimmed) {
            return fallback;
        }
        if (/^https?:\/\//i.test(trimmed)) {
            return trimmed.replace(/\/+$/, '');
        }
        const normalized = trimmed.replace(/\\/g, '/').replace(/\/+$/, '');
        return normalized || fallback;
    }
    
    // Config.json loading removed: VIDEO_CONFIG is authoritative
    
    
    checkViewThreshold() {
        if (this.video.duration && !this.hasViewed) {
            const threshold = this.video.duration * 0.25; // 25% of video duration
            if (this.video.currentTime >= threshold) {
                this.hasViewed = true;
                if (THP_DEBUG) console.log(`👁️ View threshold reached (25% = ${threshold.toFixed(1)}s) - incrementing view count`);
                this.storageManager.incrementViewCount();
            }
        }
    }
    
    // Load position settings from storage (from admin panel)
    loadPositionFromStorage() {
        this.positionManager.loadPositionFromStorage();
    }
    
    async init() {
        // Early exit if config determined we shouldn't create player (no URL match)
        if (!this.shouldCreatePlayer) {
            return;
        }
        
        // No URL parameter overrides; VIDEO_CONFIG is authoritative
        
        // Check autostart settings before creating player
        this.checkAutostart();
        
        // Check if video should show on current page
        const shouldShow = this.shouldShowOnCurrentPage();
        
        if (!shouldShow) {
            return; // Don't create the player at all
        }
        
        // For "once" and "onceLocal" modes, check if player should be created
        if ((this.autostart === "once" || this.autostart === "onceLocal") && this.shouldCreatePlayer === false) {
            return; // Don't create the player at all
        }
        
        // Create the entire player structure
        this.createPlayer();
        this.applyControlVisibility();
        
        // Set up event listeners
        this.setupEvents();
        
        // Handle slide animation if in slide mode
        if (this.slideMode) {
            this.initSlideAnimation();
        }
        
        // Handle gostopgo mode 
        if (this.gostopgoMode) {
            this.initGoStopGo();
        }
        
        // Handle loop mode
        if (this.loopMode) {
            this.initLoopMode();
        }
        
        // Handle hover mode
        if (this.hoverMode) {
            this.initHoverMode();
        }
        
        // Handle delay mode
        if (this.delayMode) {
            this.initDelayMode();
        }
        
        // Load saved volume from storage
        this.currentVolume = this.storageManager.loadVolumeFromStorage();
        
        // Load view counts from storage (async - tries JSON file first)
        this.storageManager.loadViewCountsFromStorage().catch(error => {
            if (THP_DEBUG) console.warn('Failed to load view counts from JSON file:', error);
        });
        
        // Contact email comes only from VIDEO_CONFIG
        
        // Load position settings from storage (admin panel)
        this.loadPositionFromStorage();
        
        // Handle scroll mode (after position loading to override it)
        if (this.scrollMode) {
            this.initScrollMode();
        }
    }

    checkAutostart() {
        // Read storage once at the beginning for all modes that need it
        const sessionKey = this.videoName + '_visited';
        const localKey = this.videoName + '_visited_local';
        const hasVisited = sessionStorage.getItem(sessionKey) === 'true';
        const hasVisitedLocal = localStorage.getItem(localKey) === 'true';
        
        switch (this.autostart) {
            case "yes":
                this.videoAutoplay = true;
                this.videoMuted = false;
                this.resetToOriginalPosition(); // Reset position if coming from scroll mode
                break;
            case "mute":
                this.videoAutoplay = true;
                this.videoMuted = true;
                this.loopMode = false; // Play once, then show poster
                this.muteOnceMode = true; // Special flag for mute-once behavior
                this.resetToOriginalPosition(); // Reset position if coming from scroll mode
                break;
            case "loop":
                this.videoAutoplay = true;
                this.videoMuted = true; // Start muted until user clicks
                this.loopMode = true; // Loop until user clicks play button
                this.loopUntilClickMode = true; // Special flag for loop-until-click behavior
                this.resetToOriginalPosition(); // Reset position if coming from scroll mode
                break;
            case "once":
                if (hasVisited) {
                    // Already visited - don't create player at all
                    this.shouldCreatePlayer = false;
                } else {
                    // First visit - autoplay and mark as visited
                    this.videoAutoplay = true;
                    this.videoMuted = false;
                    this.loopMode = false; // Play once, don't loop
                    this.shouldCreatePlayer = true;
                    sessionStorage.setItem(sessionKey, 'true');
                }
                this.resetToOriginalPosition(); // Reset position if coming from scroll mode
                break;
            case "onceLocal":
                if (hasVisitedLocal) {
                    // Already visited - don't create player at all
                    this.shouldCreatePlayer = false;
                } else {
                    // First visit - autoplay and mark as visited
                    this.videoAutoplay = true;
                    this.videoMuted = false;
                    this.loopMode = false; // Play once, don't loop
                    this.shouldCreatePlayer = true;
                    localStorage.setItem(localKey, 'true');
                }
                break;
            case "picSession":
            case "oncethenpic":
                if (hasVisited) {
                    // Second visit - show poster only
                    this.videoAutoplay = false;
                    this.videoMuted = false;
                } else {
                    // First visit - autoplay unmuted
                    this.videoAutoplay = true;
                    this.videoMuted = false;
                    this.loopMode = false; // Play once, don't loop
                    sessionStorage.setItem(sessionKey, 'true');
                }
                break;
            case "picLocal":
                if (hasVisitedLocal) {
                    // Second visit - show poster only
                    this.videoAutoplay = false;
                    this.videoMuted = false;
                } else {
                    // First visit - autoplay unmuted
                    this.videoAutoplay = true;
                    this.videoMuted = false;
                    this.loopMode = false; // Play once, don't loop
                    localStorage.setItem(localKey, 'true');
                }
                break;
            case "muteSession":
            case "oncethenmute":
                if (hasVisited) {
                    // Already visited - play muted
                    this.videoAutoplay = true;
                    this.videoMuted = true;
                } else {
                    // First visit - autoplay unmuted and mark as visited
                    this.videoAutoplay = true;
                    this.videoMuted = false;
                    this.loopMode = false; // Play once, don't loop
                    sessionStorage.setItem(sessionKey, 'true');
                }
                break;
            case "muteLocal":
                if (hasVisitedLocal) {
                    // Already visited - play muted
                    this.videoAutoplay = true;
                    this.videoMuted = true;
                } else {
                    // First visit - autoplay unmuted and mark as visited
                    this.videoAutoplay = true;
                    this.videoMuted = false;
                    this.loopMode = false; // Play once, don't loop
                    localStorage.setItem(localKey, 'true');
                }
                break;
            case "slide":
                this.videoAutoplay = true;
                this.videoMuted = false;
                this.loopMode = false; // Play once, don't loop
                this.slideMode = true;
                break;
            case "gostopgo":
                this.videoAutoplay = true;
                this.videoMuted = false;
                this.loopMode = false; // Play once, don't loop
                this.gostopgoMode = true;
                break;
            case "hover":
                this.videoAutoplay = false;
                this.videoMuted = false;
                this.hoverMode = true;
                this.hoverDisabled = false; // Track if hover functionality is disabled
                this.resetToOriginalPosition(); // Reset position if coming from scroll mode
                break;
            case "scroll":
                this.videoAutoplay = false;
                this.videoMuted = false;
                this.scrollMode = true;
                break;
            case "delay":
                this.videoAutoplay = false; // Don't autoplay - we'll start after delay
                this.videoMuted = false;
                this.loopMode = false; // Play once, don't loop
                this.delayMode = true;
                this.resetToOriginalPosition(); // Reset position if coming from scroll mode
                break;
            case "poster":
                this.videoAutoplay = false;
                this.videoMuted = false;
                this.resetToOriginalPosition(); // Reset position if coming from scroll mode
                break;
            default:
                this.videoAutoplay = true;
                this.videoMuted = false;
        }
    }
    
    addSlideAnimationCSS() {
        // Add CSS for slide animation if not already added
        if (!document.getElementById('slideAnimationCSS')) {
            const style = document.createElement('style');
            style.id = 'slideAnimationCSS';
            style.textContent = `
                @keyframes slideInFromBottom {
                    from {
                        transform: translateY(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateY(0);
                        opacity: 1;
                    }
                }
                
                .slide-in-animation {
                    animation: slideInFromBottom 0.6s ease-out forwards;
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    initSlideAnimation() {
        // Set initial position off-screen (bottom)
        this.container.style.transform = 'translateY(100%)';
        this.container.style.opacity = '0';
        
        // Trigger slide-in animation after a short delay
        setTimeout(() => {
            this.container.classList.add('slide-in-animation');
        }, 100);
    }
    
    initGoStopGo() {
        // Set up gostopgo behavior - play until specific time then pause
        // The check will be handled in the existing timeupdate event listener
    }
    
    initLoopMode() {
        // Set up loop mode behavior
        
        // Show muted play button overlay for loop mode if muted
        if (this.videoMuted) {
            this.showMutedPlayButton();
        }
    }
    
    initHoverMode() {
        // Set up hover mode behavior - play on mouse enter, pause on mouse leave
        
        // Add mouse enter event listener - play video
        this.container.addEventListener('mouseenter', () => {
            if (!this.hoverDisabled && this.video.paused) {
                this.video.play();
            }
        });
        
        // Add mouse leave event listener - pause video
        this.container.addEventListener('mouseleave', () => {
            if (!this.hoverDisabled && !this.video.paused) {
                this.video.pause();
            }
        });
        
        // Add click event listener to disable hover functionality
        this.container.addEventListener('click', (e) => {
            // Only handle if we're in hover mode and hover isn't already disabled
            if (this.hoverMode && !this.hoverDisabled) {
                this.hoverDisabled = true;
                
                // Ensure video continues playing
                if (this.video.paused) {
                    this.video.play();
                }
            }
        });
    }
    
    initDelayMode() {
        // Set up delay mode behavior - wait timeStop seconds before playing
        const delaySeconds = this.timeStop;
        const delayMs = delaySeconds * 1000;
        
        // Start video after delay
        setTimeout(() => {
            this.video.play();
        }, delayMs);
    }
    
    initScrollMode() {
        // Set up scroll mode behavior - play when video scrolls into view
        // Change to absolute positioning so video can scroll with page
        this.config.position = "absolute";
        
        // Position the player lower on the page for scroll testing
        this.top = "400px";
        this.bottom = "auto";
        this.left = "auto";
        this.right = "20px";
        
        // Reset flag to allow repositioning for scroll mode
        this.positionApplied = false;
        this.applyPosition();
        
        // Create intersection observer to detect when video is visible
        const observerOptions = {
            root: null, // Use viewport as root
            rootMargin: '0px',
            threshold: this.scrollThreshold // Use configurable threshold
        };
        
        const observerCallback = (entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Video is visible - play it
                    if (this.video.paused) {
                        this.video.play();
                    }
                } else {
                    // Video is not visible - pause it
                    if (!this.video.paused) {
                        this.video.pause();
                    }
                }
            });
        };
        
        // Create and start observing
        this.scrollObserver = new IntersectionObserver(observerCallback, observerOptions);
        this.scrollObserver.observe(this.container);
    }
    
    createPlayer() {
        // 1. Create all elements (no styling)
        this.createVideoElement();
        this.createControlElements();
        
        // 2. Apply ALL styling in one place
        this.applyAllStyling();
        
        // 3. Add to DOM
        this.assemblePlayer();
        
        // 4. Apply positioning once after container is fully ready
        this.applyPosition();
    }
    
    createVideoElement() {
        // Create main container
        this.container = document.createElement('div');
        this.container.id = 'talkingHeadVideoContainer';
        this.container.style.width = VIDEO_CONFIG.width + 'px';
        this.container.style.height = VIDEO_CONFIG.height + 'px';
        
        // Position will be applied after container is added to DOM
        
        // Create video element
        this.video = document.createElement('video');
        this.video.id = 'talkingHeadVideo';
        // Set initial poster image
        this.setPosterImage();
        this.video.preload = 'metadata';
        this.video.playsInline = true;
        // CRITICAL: Set muted BEFORE autoplay - some browsers require this order
        // This ensures muted autoplay is more likely to succeed
        this.video.muted = this.videoMuted;
        
        // Set autoplay property AND HTML attribute (before adding to DOM)
        this.video.autoplay = this.videoAutoplay;
        if (this.videoAutoplay) {
            this.video.setAttribute('autoplay', '');
            console.log('✅ Autoplay property and HTML attribute set on video element. Property:', this.video.autoplay, 'Attribute:', this.video.hasAttribute('autoplay'));
        } else {
            this.video.removeAttribute('autoplay');
            console.log('⏸️ Autoplay disabled - property set to false, attribute removed');
        }
        
        // For "oncethenpic" mode, disable autoplay and show poster only
        if (this.isPosterOnlyMode) {
            this.video.autoplay = false;
            this.video.removeAttribute('autoplay');
            this.video.controls = false; // Hide native controls
        }
        
        // Set loop attribute - only for loop mode
        if (this.loopMode) {
            this.video.loop = true;
        }
        
        // Create video source
        const source = document.createElement('source');
        source.src = this.path + "/" + this.videoName + ".webm";
        source.type = 'video/webm';
        this.video.appendChild(source);
        
        // Video metadata will be handled by existing event listeners
    }
    
    createControlElements() {
        // Create controls container
        this.controls = document.createElement('div');
        this.controls.id = 'talkingHeadControls';
        
        // Set initial opacity based on controls mode (prevents flash of visible controls)
        if (this.config && this.config.controlsMode === 'hover') {
            this.controls.style.opacity = '0';
            this.controls.classList.add('th-controls-hover-hidden');
        }
        
        // For "oncethenpic" mode, hide all controls (poster only)
        if (this.isPosterOnlyMode) {
            this.controls.style.display = 'none';
            return; // Don't create any controls
        }
        
        // Create control buttons
        this.createControlButtons();
        
        // Create duration bar
        this.createDurationBar();
        
        // Create volume slider
        this.createVolumeSlider();
        
        // Create center play button
        this.createCenterPlayButton();
    }
    
    assemblePlayer() {
        // Assemble the player
        this.container.appendChild(this.video);
        this.container.appendChild(this.controls);
        
        // Only add center play button if not in poster-only mode
        if (!this.isPosterOnlyMode) {
            this.container.appendChild(this.centerPlayBtn);
        }
        
        // Add to page
        document.body.appendChild(this.container);
        
        // Autoplay attribute is set - browser will attempt autoplay automatically
        // We'll check if it worked after metadata loads, and only call play() as fallback if needed
        if (this.videoAutoplay && this.video) {
            console.log('📹 Video element added to DOM with autoplay attribute. Browser will attempt autoplay automatically.');
            console.log('   Video muted:', this.video.muted, '| Autoplay attribute:', this.video.hasAttribute('autoplay'));
        }
    }

    // Helper: set the poster image based on current config
    setPosterImage() {
        if (this.video) {
            this.video.poster = this.path + "/" + this.posterImage + ".png";
        }
    }
    
    applyAllStyling() {
        // Apply video styling
        this.video.style.width = '100%';
        this.video.style.height = 'auto';
        this.video.style.display = 'block';
        this.video.style.position = 'relative'; // Ensure proper positioning
        this.video.style.transition = 'none'; // Prevent unwanted animations
        
        // Apply control bar styling
        this.setupControlsStyle();
        
        // Style control rows
        this.topRow.style.display = 'flex';
        this.topRow.style.alignItems = 'center';
        this.topRow.style.gap = '12px';
        this.topRow.style.marginBottom = '2px';
        
        this.bottomRow.style.display = 'flex';
        this.bottomRow.style.alignItems = 'center';
        this.bottomRow.style.justifyContent = 'center';
        this.bottomRow.style.gap = '12px';
        
        // Style duration bar
        this.styleDurationBar();
        
        // Style volume slider
        this.styleVolumeSlider();
        
        // Style center play button
        this.styleCenterPlayButton();
        
        // Apply control visibility and glassmorphism
        this.applyControlVisibility();
        
        // Add slide animation CSS
        this.addSlideAnimationCSS();
        
        // Style all control buttons
        this.styleControlButtons();
        
    }
    
    styleDurationBar() {
        // Duration bar container
        this.durationContainer.style.flex = '1';
        this.durationContainer.style.display = 'flex';
        this.durationContainer.style.alignItems = 'center';
        this.durationContainer.style.margin = '0 8px';
        
        // Duration bar track
        this.durationBar.style.position = 'relative';
        this.durationBar.style.width = '100%';
        this.durationBar.style.height = '8px';
        this.durationBar.style.background = `linear-gradient(90deg, 
            rgba(255, 255, 255, 0.2) 0%, 
            rgba(255, 255, 255, 0.1) 100%)`;
        this.durationBar.style.borderRadius = '4px';
        this.durationBar.style.cursor = 'pointer';
        this.durationBar.style.overflow = 'visible';
        this.durationBar.style.border = `1px solid rgba(255, 255, 255, 0.15)`;
        this.durationBar.style.transition = 'all 0.2s ease';
        
        // Duration progress fill
        this.durationProgress.style.position = 'absolute';
        this.durationProgress.style.top = '0';
        this.durationProgress.style.left = '0';
        this.durationProgress.style.height = '100%';
        this.durationProgress.style.width = '0%';
        this.durationProgress.style.background = `linear-gradient(90deg, 
            ${this.color}FF 0%, 
            ${this.color}CC 100%)`;
        this.durationProgress.style.borderRadius = '4px';
        this.durationProgress.style.transition = 'width 0.1s ease';
        this.durationProgress.style.boxShadow = `0 0 8px ${this.color}60`;
        
        // Duration handle
        this.durationHandle.style.position = 'absolute';
        this.durationHandle.style.top = '50%';
        this.durationHandle.style.left = '0%';
        this.durationHandle.style.width = '20px';
        this.durationHandle.style.height = '20px';
        this.durationHandle.style.background = `linear-gradient(135deg, 
            ${this.color}FF 0%, 
            ${this.color}DD 100%)`;
        this.durationHandle.style.borderRadius = '50%';
        this.durationHandle.style.transform = 'translate(-50%, -50%)';
        this.durationHandle.style.cursor = 'pointer';
        this.durationHandle.style.opacity = '1';
        this.durationHandle.style.zIndex = '10';
        this.durationHandle.style.border = `2px solid rgba(255, 255, 255, 0.8)`;
        this.durationHandle.style.backdropFilter = 'blur(12px)';
        this.durationHandle.style.webkitBackdropFilter = 'blur(12px)';
        this.durationHandle.style.boxShadow = `
            0 4px 16px ${this.color}60,
            0 2px 8px rgba(0, 0, 0, 0.2),
            inset 0 1px 0 rgba(255, 255, 255, 0.3)
        `;
        this.durationHandle.style.transition = 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)';
        
        // Add hover effects
        this.addDurationBarHoverEffects();
    }
    
    styleVolumeSlider() {
        // Volume slider container
        this.volumeContainer.style.flex = '1';
        this.volumeContainer.style.display = 'flex';
        this.volumeContainer.style.alignItems = 'center';
        this.volumeContainer.style.margin = '0 8px';
        
        // Volume slider track
        this.volumeBar.style.position = 'relative';
        this.volumeBar.style.width = '100%';
        this.volumeBar.style.height = '8px';
        this.volumeBar.style.background = `linear-gradient(90deg, 
            rgba(255, 255, 255, 0.2) 0%, 
            rgba(255, 255, 255, 0.1) 100%)`;
        this.volumeBar.style.borderRadius = '4px';
        this.volumeBar.style.cursor = 'pointer';
        this.volumeBar.style.overflow = 'visible';
        this.volumeBar.style.border = `1px solid rgba(255, 255, 255, 0.15)`;
        this.volumeBar.style.transition = 'all 0.2s ease';
        
        // Volume level fill
        this.volumeLevel.style.position = 'absolute';
        this.volumeLevel.style.top = '0';
        this.volumeLevel.style.left = '0';
        this.volumeLevel.style.height = '100%';
        this.volumeLevel.style.width = '100%'; // Start at full volume
        this.volumeLevel.style.background = `linear-gradient(90deg, 
            ${this.color}FF 0%, 
            ${this.color}CC 100%)`;
        this.volumeLevel.style.borderRadius = '4px';
        this.volumeLevel.style.transition = 'width 0.1s ease';
        this.volumeLevel.style.boxShadow = `0 0 8px ${this.color}60`;
        
        // Volume handle
        this.volumeHandle.style.position = 'absolute';
        this.volumeHandle.style.top = '50%';
        this.volumeHandle.style.left = '100%'; // Start at full volume
        this.volumeHandle.style.width = '20px';
        this.volumeHandle.style.height = '20px';
        this.volumeHandle.style.background = `linear-gradient(135deg, 
            ${this.color}FF 0%, 
            ${this.color}DD 100%)`;
        this.volumeHandle.style.borderRadius = '50%';
        this.volumeHandle.style.transform = 'translate(-50%, -50%)';
        this.volumeHandle.style.cursor = 'pointer';
        this.volumeHandle.style.opacity = '1';
        this.volumeHandle.style.zIndex = '10';
        this.volumeHandle.style.border = `2px solid rgba(255, 255, 255, 0.8)`;
        this.volumeHandle.style.backdropFilter = 'blur(12px)';
        this.volumeHandle.style.webkitBackdropFilter = 'blur(12px)';
        this.volumeHandle.style.boxShadow = `
            0 4px 16px ${this.color}60,
            0 2px 8px rgba(0, 0, 0, 0.2),
            inset 0 1px 0 rgba(255, 255, 255, 0.3)
        `;
        this.volumeHandle.style.transition = 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)';
        
        // Add hover effects
        this.addVolumeSliderHoverEffects();
    }
    
    styleCenterPlayButton() {
        // Center play button styling
        this.centerPlayBtn.style.position = 'absolute';
        this.centerPlayBtn.style.top = '50%';
        this.centerPlayBtn.style.left = '50%';
        this.centerPlayBtn.style.transform = 'translate(-50%, -50%)';
        this.centerPlayBtn.style.width = '80px';
        this.centerPlayBtn.style.height = '80px';
        this.centerPlayBtn.style.borderRadius = '50%';
        this.centerPlayBtn.style.border = 'none';
        this.centerPlayBtn.style.background = `linear-gradient(135deg, 
            ${this.color}60 0%, 
            ${this.color}40 100%)`;
        this.centerPlayBtn.style.border = `3px solid ${this.color}80`;
        this.centerPlayBtn.style.color = '#FFFFFF';
        this.centerPlayBtn.style.fontSize = '32px';
        this.centerPlayBtn.style.cursor = 'pointer';
        this.centerPlayBtn.style.fontFamily = 'Arial, sans-serif';
        this.centerPlayBtn.style.fontWeight = 'bold';
        this.centerPlayBtn.style.textShadow = '0 1px 2px rgba(0, 0, 0, 0.3)';
        this.centerPlayBtn.style.backdropFilter = 'blur(8px)';
        this.centerPlayBtn.style.webkitBackdropFilter = 'blur(8px)';
        this.centerPlayBtn.style.boxShadow = `
            0 2px 8px ${this.color}30,
            inset 0 1px 0 rgba(255, 255, 255, 0.2)
        `;
        this.centerPlayBtn.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
        this.centerPlayBtn.style.opacity = '0';
        this.centerPlayBtn.style.pointerEvents = 'none';
        this.centerPlayBtn.style.zIndex = '10';
        // Center the play symbol inside the button
        this.centerPlayBtn.style.display = 'flex';
        this.centerPlayBtn.style.alignItems = 'center';
        this.centerPlayBtn.style.justifyContent = 'center';
        
        // Add hover effects
        this.addCenterPlayButtonHoverEffects();
    }
    
    // Generic method to add hover effects for bar/handle slider pairs
    addHoverEffects(bar, handle) {
        // Add hover effect for bar
        bar.addEventListener('mouseenter', () => {
            bar.style.background = `linear-gradient(90deg, 
                rgba(255, 255, 255, 0.3) 0%, 
                rgba(255, 255, 255, 0.2) 100%)`;
            bar.style.transform = 'scaleY(1.2)';
        });
        
        bar.addEventListener('mouseleave', () => {
            bar.style.background = `linear-gradient(90deg, 
                rgba(255, 255, 255, 0.2) 0%, 
                rgba(255, 255, 255, 0.1) 100%)`;
            bar.style.transform = 'scaleY(1)';
        });
        
        // Add hover effect for handle
        handle.addEventListener('mouseenter', () => {
            handle.style.transform = 'translate(-50%, -50%) scale(1.2)';
            handle.style.boxShadow = `
                0 6px 20px ${this.color}80,
                0 3px 12px rgba(0, 0, 0, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.4)
            `;
        });
        
        handle.addEventListener('mouseleave', () => {
            handle.style.transform = 'translate(-50%, -50%) scale(1)';
            handle.style.boxShadow = `
                0 4px 16px ${this.color}60,
                0 2px 8px rgba(0, 0, 0, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.3)
            `;
        });
    }
    
    addDurationBarHoverEffects() {
        this.addHoverEffects(this.durationBar, this.durationHandle);
    }
    
    addVolumeSliderHoverEffects() {
        this.addHoverEffects(this.volumeBar, this.volumeHandle);
    }
    
    addCenterPlayButtonHoverEffects() {
        // Add hover effect
        this.centerPlayBtn.addEventListener('mouseenter', () => {
            this.centerPlayBtn.style.background = `linear-gradient(135deg, 
                ${this.color}80 0%, 
                ${this.color}60 100%)`;
            this.centerPlayBtn.style.transform = 'translate(-50%, -50%) scale(1.1)';
            this.centerPlayBtn.style.boxShadow = `
                0 4px 16px ${this.color}70,
                inset 0 1px 0 rgba(255, 255, 255, 0.3)
            `;
        });
        
        this.centerPlayBtn.addEventListener('mouseleave', () => {
            this.centerPlayBtn.style.background = `linear-gradient(135deg, 
                ${this.color}60 0%, 
                ${this.color}40 100%)`;
            this.centerPlayBtn.style.transform = 'translate(-50%, -50%) scale(1)';
            this.centerPlayBtn.style.boxShadow = `
                0 2px 8px ${this.color}50,
                inset 0 1px 0 rgba(255, 255, 255, 0.2)
            `;
        });
    }
    
    setupControlsStyle() {
        // Base control bar styling
        this.controls.style.position = 'absolute';
        this.controls.style.bottom = '10px';
        this.controls.style.left = '10px';
        this.controls.style.right = '10px';
        this.controls.style.padding = '4px';
        this.controls.style.display = 'flex';
        this.controls.style.flexDirection = 'column';
        this.controls.style.gap = '2px';
        this.controls.style.transition = 'opacity 0.3s ease';
    }
    
    createControlButtons() {
        // Create top row (duration bar + exit button)
        this.topRow = document.createElement('div');
        
        // Create bottom row (play + mute + volume slider)
        this.bottomRow = document.createElement('div');
        
        // Play/Pause button with inline SVG (Variant 1: Circular outline with triangle)
        this.playPauseBtn = document.createElement('button');
        this.playPauseBtn.className = 'th-control-btn';
        this.playPauseBtn.innerHTML = this.icons.play;
        
        // Mute button with inline SVG (Variant 1: Speaker with waves)
        this.muteBtn = document.createElement('button');
        this.muteBtn.className = 'th-control-btn';
        this.muteBtn.innerHTML = this.icons.unmute;
        
        // Exit button (1/4 size) with SVG icon
        this.closeBtn = document.createElement('button');
        this.closeBtn.innerHTML = this.icons.exit;
        this.closeBtn.className = 'th-control-btn th-exit-btn';
        
        // Add buttons to bottom row
        this.bottomRow.appendChild(this.playPauseBtn);
        this.bottomRow.appendChild(this.muteBtn);
        
        // Initialize mute button icon based on initial muted state
        // This will be set when video metadata loads, but set initial state here
        if (this.videoMuted !== undefined) {
            this.muteBtn.innerHTML = this.videoMuted ? this.icons.mute : this.icons.unmute;
        }
        
        // Add rows to controls
        this.controls.appendChild(this.topRow);
        this.controls.appendChild(this.bottomRow);
    }
    
    // SVG Icon Creation Methods - Play Buttons (3 variants)
    createPlayIconSVG(variant = 1) {
        const svgNS = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(svgNS, 'svg');
        svg.setAttribute('viewBox', '0 0 100 100');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.style.display = 'block';
        
        let content = '';
        switch(variant) {
            case 1:
                // Variant 1: Triangle "play" symbol centered in a circular outline
                content = `
                    <circle cx="50" cy="50" r="45" fill="none" stroke="#FFFFFF" stroke-width="3" opacity="0.9"/>
                    <polygon points="32,20 32,80 72,50" fill="#FFFFFF" opacity="0.95"/>
                    <defs>
                        <filter id="playShadow">
                            <feGaussianBlur in="SourceAlpha" stdDeviation="2"/>
                            <feOffset dx="0" dy="2" result="offsetblur"/>
                            <feComponentTransfer>
                                <feFuncA type="linear" slope="0.3"/>
                            </feComponentTransfer>
                            <feMerge>
                                <feMergeNode/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                `;
                break;
            case 2:
                // Variant 2: Minimal triangle with soft drop shadow
                content = `
                    <defs>
                        <filter id="playSoftShadow">
                            <feGaussianBlur in="SourceAlpha" stdDeviation="3"/>
                            <feOffset dx="0" dy="2" result="offsetblur"/>
                            <feComponentTransfer>
                                <feFuncA type="linear" slope="0.2"/>
                            </feComponentTransfer>
                            <feMerge>
                                <feMergeNode/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                    <polygon points="35,25 35,75 68,50" fill="#FFFFFF" filter="url(#playSoftShadow)" opacity="0.95"/>
                `;
                break;
            case 3:
                // Variant 3: Circular play icon with subtle pulse animation on hover
                content = `
                    <circle cx="50" cy="50" r="40" fill="#FFFFFF" opacity="0.3" class="play-pulse"/>
                    <polygon points="40,32 40,68 62,50" fill="#FFFFFF" opacity="1"/>
                    <style>
                        .play-pulse {
                            animation: pulse 2s ease-in-out infinite;
                        }
                        @keyframes pulse {
                            0%, 100% { opacity: 0.3; transform: scale(1); }
                            50% { opacity: 0.5; transform: scale(1.05); }
                        }
                    </style>
                `;
                break;
        }
        svg.innerHTML = content;
        return svg.outerHTML;
    }
    
    // Pause Buttons (3 variants)
    createPauseIconSVG(variant = 1) {
        const svgNS = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(svgNS, 'svg');
        svg.setAttribute('viewBox', '0 0 100 100');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.style.display = 'block';
        
        let content = '';
        switch(variant) {
            case 1:
                // Variant 1: Two vertical bars in a circular outline (matching play button style)
                content = `
                    <circle cx="50" cy="50" r="45" fill="none" stroke="#FFFFFF" stroke-width="3" opacity="0.9"/>
                    <rect x="30" y="20" width="15" height="60" rx="3" fill="#FFFFFF" opacity="0.95"/>
                    <rect x="55" y="20" width="15" height="60" rx="3" fill="#FFFFFF" opacity="0.95"/>
                    <defs>
                        <filter id="pauseShadow">
                            <feGaussianBlur in="SourceAlpha" stdDeviation="2"/>
                            <feOffset dx="0" dy="2" result="offsetblur"/>
                            <feComponentTransfer>
                                <feFuncA type="linear" slope="0.3"/>
                            </feComponentTransfer>
                            <feMerge>
                                <feMergeNode/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                `;
                break;
            case 2:
                // Variant 2: Dual bars with light depth (shadow or gradient)
                content = `
                    <defs>
                        <linearGradient id="pauseGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" style="stop-color:#FFFFFF;stop-opacity:1" />
                            <stop offset="100%" style="stop-color:#FFFFFF;stop-opacity:0.7" />
                        </linearGradient>
                        <filter id="pauseDepth">
                            <feGaussianBlur in="SourceAlpha" stdDeviation="2.5"/>
                            <feOffset dx="0" dy="3" result="offsetblur"/>
                            <feComponentTransfer>
                                <feFuncA type="linear" slope="0.25"/>
                            </feComponentTransfer>
                            <feMerge>
                                <feMergeNode/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                    <rect x="30" y="20" width="15" height="60" rx="4" fill="url(#pauseGradient)" filter="url(#pauseDepth)"/>
                    <rect x="55" y="20" width="15" height="60" rx="4" fill="url(#pauseGradient)" filter="url(#pauseDepth)"/>
                `;
                break;
            case 3:
                // Variant 3: Circular pause icon with hover glow or ring effect
                content = `
                    <circle cx="50" cy="50" r="40" fill="none" stroke="#FFFFFF" stroke-width="3" opacity="0.3" class="pause-ring"/>
                    <rect x="32" y="28" width="12" height="44" rx="2" fill="#FFFFFF" opacity="0.95"/>
                    <rect x="56" y="28" width="12" height="44" rx="2" fill="#FFFFFF" opacity="0.95"/>
                    <style>
                        .pause-ring {
                            transition: opacity 0.3s ease;
                        }
                    </style>
                `;
                break;
        }
        svg.innerHTML = content;
        return svg.outerHTML;
    }
    
    // Mute/Unmute Buttons (3 variants each)
    createUnmuteIconSVG(variant = 1) {
        const svgNS = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(svgNS, 'svg');
        svg.setAttribute('viewBox', '0 0 100 100');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.style.display = 'block';
        
        let content = '';
        switch(variant) {
            case 1:
                // Variant 1: Speaker with stylized cone and 2-3 wave lines
                content = `
                    <path d="M 25 35 L 25 65 L 35 60 L 50 75 L 50 25 L 35 40 Z" fill="#FFFFFF" opacity="0.95"/>
                    <path d="M 58 40 Q 65 50 58 60" stroke="#FFFFFF" stroke-width="4" fill="none" opacity="0.8"/>
                    <path d="M 65 32 Q 78 50 65 68" stroke="#FFFFFF" stroke-width="4" fill="none" opacity="0.6"/>
                    <path d="M 72 25 Q 92 50 72 75" stroke="#FFFFFF" stroke-width="4" fill="none" opacity="0.4"/>
                `;
                break;
            case 2:
                // Variant 2: Minimalist flat speaker
                content = `
                    <path d="M 20 30 L 20 70 L 30 65 L 45 80 L 45 20 L 30 35 Z" fill="#FFFFFF" opacity="0.95"/>
                    <circle cx="60" cy="50" r="8" fill="none" stroke="#FFFFFF" stroke-width="3" opacity="0.7"/>
                    <circle cx="70" cy="50" r="12" fill="none" stroke="#FFFFFF" stroke-width="3" opacity="0.5"/>
                `;
                break;
            case 3:
                // Variant 3: Rounded speaker icon with soft shadow
                content = `
                    <defs>
                        <filter id="speakerShadow">
                            <feGaussianBlur in="SourceAlpha" stdDeviation="2"/>
                            <feOffset dx="0" dy="2" result="offsetblur"/>
                            <feComponentTransfer>
                                <feFuncA type="linear" slope="0.3"/>
                            </feComponentTransfer>
                            <feMerge>
                                <feMergeNode/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                    <path d="M 22 32 Q 22 22 28 22 L 38 28 L 48 18 Q 52 18 52 22 L 52 78 Q 52 82 48 82 L 38 72 L 28 78 Q 22 78 22 68 Z" fill="#FFFFFF" opacity="0.95" filter="url(#speakerShadow)"/>
                    <path d="M 55 42 Q 62 50 55 58" stroke="#FFFFFF" stroke-width="3.5" fill="none" opacity="0.8"/>
                    <path d="M 62 35 Q 75 50 62 65" stroke="#FFFFFF" stroke-width="3.5" fill="none" opacity="0.6"/>
                `;
                break;
        }
        svg.innerHTML = content;
        return svg.outerHTML;
    }
    
    createMuteIconSVG(variant = 1) {
        const svgNS = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(svgNS, 'svg');
        svg.setAttribute('viewBox', '0 0 100 100');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.style.display = 'block';
        
        let content = '';
        switch(variant) {
            case 1:
                // Variant 1: Speaker with diagonal slash
                content = `
                    <path d="M 25 35 L 25 65 L 35 60 L 50 75 L 50 25 L 35 40 Z" fill="#FFFFFF" opacity="0.95"/>
                    <path d="M 58 40 Q 65 50 58 60" stroke="#FFFFFF" stroke-width="4" fill="none" opacity="0.8"/>
                    <path d="M 65 32 Q 78 50 65 68" stroke="#FFFFFF" stroke-width="4" fill="none" opacity="0.6"/>
                    <path d="M 72 25 Q 92 50 72 75" stroke="#FFFFFF" stroke-width="4" fill="none" opacity="0.4"/>
                    <line x1="65" y1="28" x2="85" y2="72" stroke="#FFFFFF" stroke-width="5" stroke-linecap="round" opacity="0.95"/>
                `;
                break;
            case 2:
                // Variant 2: Minimalist flat speaker with red X
                content = `
                    <path d="M 20 30 L 20 70 L 30 65 L 45 80 L 45 20 L 30 35 Z" fill="#FFFFFF" opacity="0.95"/>
                    <circle cx="60" cy="50" r="8" fill="none" stroke="#FFFFFF" stroke-width="3" opacity="0.7"/>
                    <circle cx="70" cy="50" r="12" fill="none" stroke="#FFFFFF" stroke-width="3" opacity="0.5"/>
                    <line x1="58" y1="32" x2="82" y2="68" stroke="#FF4444" stroke-width="4.5" stroke-linecap="round" opacity="0.9"/>
                    <line x1="82" y1="32" x2="58" y2="68" stroke="#FF4444" stroke-width="4.5" stroke-linecap="round" opacity="0.9"/>
                `;
                break;
            case 3:
                // Variant 3: Rounded speaker with soft shadow and diagonal slash
                content = `
                    <defs>
                        <filter id="muteShadow">
                            <feGaussianBlur in="SourceAlpha" stdDeviation="2"/>
                            <feOffset dx="0" dy="2" result="offsetblur"/>
                            <feComponentTransfer>
                                <feFuncA type="linear" slope="0.3"/>
                            </feComponentTransfer>
                            <feMerge>
                                <feMergeNode/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                    <path d="M 22 32 Q 22 22 28 22 L 38 28 L 48 18 Q 52 18 52 22 L 52 78 Q 52 82 48 82 L 38 72 L 28 78 Q 22 78 22 68 Z" fill="#FFFFFF" opacity="0.95" filter="url(#muteShadow)"/>
                    <path d="M 55 42 Q 62 50 55 58" stroke="#FFFFFF" stroke-width="3.5" fill="none" opacity="0.8"/>
                    <path d="M 62 35 Q 75 50 62 65" stroke="#FFFFFF" stroke-width="3.5" fill="none" opacity="0.6"/>
                    <line x1="62" y1="28" x2="85" y2="72" stroke="#FF4444" stroke-width="5" stroke-linecap="round" opacity="0.95"/>
                `;
                break;
        }
        svg.innerHTML = content;
        return svg.outerHTML;
    }
    
    // Exit Button (Close/X) SVG
    createExitIconSVG() {
        const svgNS = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(svgNS, 'svg');
        svg.setAttribute('viewBox', '0 0 100 100');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.style.display = 'block';
        
        // Circular outline matching play/pause style
        // Large, bold X that fills the circular space
        const content = `
            <circle cx="50" cy="50" r="45" fill="none" stroke="#FFFFFF" stroke-width="3" opacity="0.9"/>
            <line x1="22" y1="22" x2="78" y2="78" stroke="#FFFFFF" stroke-width="16" stroke-linecap="round" opacity="0.95"/>
            <line x1="78" y1="22" x2="22" y2="78" stroke="#FFFFFF" stroke-width="16" stroke-linecap="round" opacity="0.95"/>
        `;
        
        svg.innerHTML = content;
        return svg.outerHTML;
    }
    
    createDurationBar() {
        // Duration bar container
        this.durationContainer = document.createElement('div');
        
        // Duration bar track
        this.durationBar = document.createElement('div');
        
        // Duration progress fill
        this.durationProgress = document.createElement('div');
        
        // Duration handle
        this.durationHandle = document.createElement('div');
        
        // Assemble duration bar
        this.durationBar.appendChild(this.durationProgress);
        this.durationBar.appendChild(this.durationHandle);
        this.durationContainer.appendChild(this.durationBar);
        
        // Add duration bar to top row
        this.topRow.appendChild(this.durationContainer);
        // Add exit button to top row
        this.topRow.appendChild(this.closeBtn);
    }
    
    createVolumeSlider() {
        // Volume slider container
        this.volumeContainer = document.createElement('div');
        
        // Volume slider track
        this.volumeBar = document.createElement('div');
        
        // Volume level fill
        this.volumeLevel = document.createElement('div');
        
        // Volume handle
        this.volumeHandle = document.createElement('div');
        
        // Assemble volume slider
        this.volumeBar.appendChild(this.volumeLevel);
        this.volumeBar.appendChild(this.volumeHandle);
        this.volumeContainer.appendChild(this.volumeBar);
        
        // Add volume slider to bottom row
        this.bottomRow.appendChild(this.volumeContainer);
    }
    
    createCenterPlayButton() {
        // Center play button
        this.centerPlayBtn = document.createElement('button');
        this.centerPlayBtn.textContent = '▶';
        this.centerPlayBtn.id = 'talkingHeadCenterPlay';
        
        // Add click handler
        this.centerPlayBtn.addEventListener('click', () => this.togglePlayPause());
    }
    
    setupEvents() {
        // Video events
        this.video.addEventListener('loadedmetadata', () => {
            this.updateVolumeBar(); // Initialize volume bar display
            this.updatePlayButtons();
            // Update mute button icon to match video muted state
            if (this.muteBtn) {
                this.muteBtn.innerHTML = this.video.muted ? this.icons.mute : this.icons.unmute;
            }
            
            // Check if autoplay attribute worked (browser should have started playback automatically)
            if (this.videoAutoplay) {
                if (this.video.paused) {
                    // Autoplay attribute didn't work - browser blocked it, try programmatic play() as fallback
                    console.warn('⚠️ Autoplay attribute was set but video is still paused. Browser blocked autoplay.');
                    console.log('   Video muted:', this.video.muted, '| Autoplay attribute:', this.video.hasAttribute('autoplay'), '| ReadyState:', this.video.readyState);
                    console.log('🔧 Attempting programmatic play() as fallback...');
                    
                    const playPromise = this.video.play();
                    if (playPromise !== undefined) {
                        playPromise.then(() => {
                            console.log('✅ Programmatic play() succeeded (fallback)');
                        }).catch((error) => {
                            if (error.name === 'NotAllowedError') {
                                console.warn('⚠️ Programmatic play() also BLOCKED by browser:', error.message);
                                console.log('🔧 User interaction required to start playback');
                            } else {
                                console.error('❌ Video play() error:', error);
                            }
                            // Show play button prominently if autoplay fails
                            if (this.centerPlayBtn) {
                                this.centerPlayBtn.style.opacity = '1';
                                this.centerPlayBtn.style.pointerEvents = 'auto';
                            }
                        });
                    }
                } else {
                    console.log('✅ Autoplay attribute worked! Video is playing automatically.');
                }
            }
        });
        
        this.video.addEventListener('timeupdate', () => {
            if (!this.isDragging) {
                this.updateDurationBar();
                this.checkViewThreshold();
                
                // Check for gostopgo mode
                if (this.gostopgoMode && this.video.currentTime >= this.timeStop) {
                    this.video.pause();
                    // Disable gostopgo mode and switch to normal autostart
                    this.gostopgoMode = false;
                    this.autostart = "yes";
                }
            }
        });
        
        this.video.addEventListener('ended', () => {
            this.onVideoEnded();
        });
        
        this.video.addEventListener('play', () => {
            this.updatePlayButtons();
            
            // Track that video started playing (counts all starts, even if < 25%)
            if (this.storageManager && !this.hasStartedTracking) {
                this.storageManager.trackVideoStart();
                this.hasStartedTracking = true; // Prevent counting multiple play events
            }
            
            // Start tracking watch time for this session (only start if timer not running)
            if (this.storageManager) {
                this.storageManager.startSessionTimer();
            }
            // Session timing handled by StorageManager; no player-level timer
            
            // Show center unmute button if video is muted (for oncethenmute mode)
            if (this.video.muted && !document.getElementById('talkingHeadMutedOverlay')) {
                this.showMutedPlayButton();
            }
        });
        
        this.video.addEventListener('pause', () => {
            this.updatePlayButtons();
            this.hideMutedOverlay(); // Hide muted overlay when paused
            
            // Reset start tracking flag for next play
            this.hasStartedTracking = false;
            
            // Track watch time on pause
            if (this.storageManager) {
                this.storageManager.trackVideoPause();
                
                // Check if video is near completion (95% or more) - count as completion
                if (this.video.duration && this.video.currentTime >= (this.video.duration * 0.95)) {
                    // Video was paused near the end - treat as completion
                    if (!this.hasCompleted) {
                        if (THP_DEBUG) console.log('✅ Video paused near end (95%+) - counting as completion');
                        this.trackVideoCompletion();
                    }
                }
            }
        });
        
        // Duration bar events (only if it exists)
        if (this.durationBar) {
            this.durationBar.addEventListener('click', (e) => this.seekToPosition(e));
            this.durationBar.addEventListener('mousedown', (e) => this.startDrag(e));
        }
        document.addEventListener('mousemove', (e) => this.drag(e));
        document.addEventListener('mouseup', () => this.endDrag());
        
        // Track watch time when page visibility changes (user switches tabs, minimizes, etc.)
        // Only track if video is actually playing (not paused)
        document.addEventListener('visibilitychange', () => {
            if (document.hidden && this.storageManager && !this.video.paused) {
                if (THP_DEBUG) console.log('👁️ Page hidden while video playing - tracking pause');
                this.storageManager.trackVideoPause();
            }
        });

        
        // Volume bar events (only if it exists)
        if (this.volumeBar) {
            this.volumeBar.addEventListener('click', (e) => this.setVolumeFromPosition(e));
            this.volumeBar.addEventListener('mousedown', (e) => this.startVolumeDrag(e));
        }
        document.addEventListener('mousemove', (e) => this.dragVolume(e));
        document.addEventListener('mouseup', () => this.endVolumeDrag());
        
        // Button controls (only if they exist)
        if (this.playPauseBtn) {
            this.playPauseBtn.addEventListener('click', () => {
                const isPaused = this.video.paused;
                if (THP_DEBUG) console.log(isPaused ? '▶️ Play clicked' : '⏸️ Pause clicked');
                this.togglePlayPause();
            });
        }
        if (this.muteBtn) {
            this.muteBtn.addEventListener('click', () => this.toggleMute());
        }
        if (this.closeBtn) {
            this.closeBtn.addEventListener('click', () => this.closePlayer());
        }
        
    }

    // Show muted play button overlay
    showMutedPlayButton() {
        // Remove any existing muted overlay first
        this.hideMutedOverlay();
        
        // Create muted indicator overlay
        const mutedOverlay = document.createElement('div');
        mutedOverlay.id = 'talkingHeadMutedOverlay';
        mutedOverlay.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, 
                ${this.color}60 0%, 
                ${this.color}40 100%);
            color: #FFFFFF;
            padding: 8px 16px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 500;
            z-index: 1000;
            backdrop-filter: blur(12px);
            webkit-backdrop-filter: blur(12px);
            border: 2px solid ${this.color}80;
            box-shadow: 
                0 4px 16px ${this.color}40,
                0 2px 8px rgba(0, 0, 0, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.3);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-align: center;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
            font-family: Arial, sans-serif;
            min-width: 80px;
            white-space: nowrap;
        `;
        mutedOverlay.innerHTML = '🔇 Unmute';
        
        // Add click handler to unmute
        mutedOverlay.addEventListener('click', () => {
            this.toggleMute(); // Use the unified unmute method
            
            // If in loop mode, restart from beginning
            if (this.video.loop) {
                this.video.currentTime = 0;
            }
        });
        
        // Add hover effects matching player style
        mutedOverlay.addEventListener('mouseenter', () => {
            mutedOverlay.style.background = `linear-gradient(135deg, 
                ${this.color}80 0%, 
                ${this.color}60 100%)`;
            mutedOverlay.style.transform = 'translate(-50%, -50%) scale(1.05)';
            mutedOverlay.style.boxShadow = `
                0 12px 40px ${this.color}60,
                0 6px 20px rgba(0, 0, 0, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.4)
            `;
            mutedOverlay.style.borderColor = `${this.color}AA`;
        });
        
        mutedOverlay.addEventListener('mouseleave', () => {
            mutedOverlay.style.background = `linear-gradient(135deg, 
                ${this.color}60 0%, 
                ${this.color}40 100%)`;
            mutedOverlay.style.transform = 'translate(-50%, -50%) scale(1)';
            mutedOverlay.style.boxShadow = `
                0 8px 32px ${this.color}40,
                0 4px 16px rgba(0, 0, 0, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.3)
            `;
            mutedOverlay.style.borderColor = `${this.color}80`;
        });
        
        this.container.appendChild(mutedOverlay);
    }

    applyPosition() {
        // Skip if already positioned (prevent redundant calls)
        if (this.positionApplied) {
            return;
        }
        this.positionManager.setContainer(this.container);
        this.positionManager.applyPosition();
        
        // Mark as positioned to prevent redundant calls
        this.positionApplied = true;
    }
    
    applyControlVisibility() {
        // Remove all visibility classes
        this.controls.classList.remove('always', 'hover', 'hide');
        
        // Remove existing hover listeners before adding new ones (prevents accumulation)
        this.removeControlHoverListeners();
        
        // Apply visibility mode
        switch(this.config.controlsMode) {
            case 'always':
                this.controls.style.opacity = '1';
                break;
            case 'hover':
                // Ensure controls start hidden
                this.controls.style.opacity = '0';
                this.controls.style.pointerEvents = 'auto'; // Allow interaction when visible
                // Add CSS classes for WordPress theme compatibility
                this.controls.classList.remove('th-controls-hover-visible');
                this.controls.classList.add('th-controls-hover-hidden');
                // Store handler references for proper cleanup
                this.controlHoverEnterHandler = () => {
                    this.isContainerHovered = true;
                    if (this.controls) {
                        this.controls.style.opacity = '1';
                        this.controls.classList.remove('th-controls-hover-hidden');
                        this.controls.classList.add('th-controls-hover-visible');
                    }
                };
                this.controlHoverLeaveHandler = () => {
                    this.isContainerHovered = false;
                    if (this.controls) {
                        this.controls.style.opacity = '0';
                        this.controls.classList.remove('th-controls-hover-visible');
                        this.controls.classList.add('th-controls-hover-hidden');
                    }
                };
                // Add listeners with stored references (only if container exists)
                if (this.container) {
                    this.container.addEventListener('mouseenter', this.controlHoverEnterHandler);
                    this.container.addEventListener('mouseleave', this.controlHoverLeaveHandler);
                }
                break;
            case 'hide':
            case 'none': // Backwards compatibility - admin.php previously used 'none'
                this.controls.style.opacity = '0';
                this.controls.style.pointerEvents = 'none';
                break;
        }
        
        // Apply glassmorphism styling with proper iOS Safari support
        // Convert hex color to rgba for better iOS compatibility
        const hexToRgba = (hex, alpha) => {
            // Safety check - ensure hex is valid
            if (!hex || typeof hex !== 'string') {
                hex = '#0073FF'; // Fallback to blue
            }
            const colorHex = hex.startsWith('#') ? hex : '#' + hex;
            const r = parseInt(colorHex.slice(1, 3), 16);
            const g = parseInt(colorHex.slice(3, 5), 16);
            const b = parseInt(colorHex.slice(5, 7), 16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        };
        // Ensure color is always valid
        if (!this.color || typeof this.color !== 'string') {
            this.color = '#0073FF'; // Fallback to blue
        }
        const colorHex = this.color.startsWith('#') ? this.color : '#' + this.color;
        this.controls.style.backgroundColor = hexToRgba(colorHex, 0.19); // More transparent for glassmorphism (30/255 ≈ 0.19)
        this.controls.style.border = `3px solid ${this.color}60`; // Semi-transparent border
        this.controls.style.borderRadius = "12px";
        this.controls.style.backdropFilter = "blur(10px)";
        this.controls.style.webkitBackdropFilter = "blur(10px)"; // Safari support
        this.controls.style.boxShadow = "0 4px 16px rgba(0, 0, 0, 0.1)";
        // Additional iOS Safari fixes for transparency
        this.controls.style.webkitTransform = "translateZ(0)"; // Force hardware acceleration
        this.controls.style.transform = "translateZ(0)";
        
        // Style the buttons
        this.styleControlButtons();
        
        // Enforce opacity for hover mode after all styling is complete
        if (this.config.controlsMode === 'hover' && this.controls) {
            // Force opacity based on tracked hover state (safety check)
            // This ensures opacity is correct even if something tried to change it
            this.controls.style.opacity = this.isContainerHovered ? '1' : '0';
        }
        
    }
    
    /**
     * Remove control hover event listeners to prevent accumulation
     * Called before adding new listeners in applyControlVisibility()
     */
    removeControlHoverListeners() {
        if (this.container && this.controlHoverEnterHandler) {
            this.container.removeEventListener('mouseenter', this.controlHoverEnterHandler);
            this.controlHoverEnterHandler = null;
        }
        if (this.container && this.controlHoverLeaveHandler) {
            this.container.removeEventListener('mouseleave', this.controlHoverLeaveHandler);
            this.controlHoverLeaveHandler = null;
        }
    }
    
    styleControlButtons() {
        // Get all control buttons
        const buttons = this.controls.querySelectorAll('.th-control-btn');
        
        // Helper function for rgba conversion (better iOS Safari support)
        const hexToRgba = (hex, alpha) => {
            // Safety check - ensure hex is valid
            if (!hex || typeof hex !== 'string') {
                hex = '#0073FF'; // Fallback to blue
            }
            const colorHex = hex.startsWith('#') ? hex : '#' + hex;
            const r = parseInt(colorHex.slice(1, 3), 16);
            const g = parseInt(colorHex.slice(3, 5), 16);
            const b = parseInt(colorHex.slice(5, 7), 16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        };
        
        buttons.forEach(button => {
            // Check if it's the exit button (1/4 size)
            const isExitBtn = button.classList.contains('th-exit-btn');
            
            // Enhanced button styling with glassmorphism (using rgba for iOS Safari)
            button.style.background = `linear-gradient(135deg, 
                ${hexToRgba(this.color, 0.25)} 0%, 
                ${hexToRgba(this.color, 0.125)} 100%)`;
            button.style.border = `1px solid ${this.color}60`;
            button.style.color = '#FFFFFF';
            button.style.borderRadius = "8px";
            button.style.cursor = "pointer";
            button.style.transition = "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)";
            button.style.backdropFilter = "blur(8px)";
            button.style.webkitBackdropFilter = "blur(8px)";
            button.style.boxShadow = `
                0 2px 8px ${this.color}30,
                inset 0 1px 0 rgba(255, 255, 255, 0.2)
            `;
            button.style.fontWeight = "500";
            button.style.userSelect = "none";
            button.style.display = "flex";
            button.style.alignItems = "center";
            button.style.justifyContent = "center";
            button.style.overflow = "visible";
            
            // Size based on button type
            if (isExitBtn) {
                // Exit button - same size as slider handles
                button.style.padding = "2px";
                button.style.fontSize = "8px";
                button.style.minWidth = "20px";
                button.style.height = "20px";
                button.style.borderRadius = "50%";
            } else {
                // Regular buttons - ensure square shape
                button.style.padding = "0";
                button.style.fontSize = "26px";
                button.style.width = "32px"; // Explicit width to match height
                button.style.minWidth = "32px";
                button.style.height = "32px";
                button.style.maxWidth = "32px"; // Prevent stretching
                button.style.maxHeight = "32px"; // Prevent stretching
            }
            
            // Enhanced hover effect
            const isPlayPauseBtn = button === this.playPauseBtn;
            const isMuteBtn = button === this.muteBtn;
            
            button.addEventListener('mouseenter', () => {
                button.style.background = `linear-gradient(135deg, 
                    ${hexToRgba(this.color, 0.375)} 0%, 
                    ${hexToRgba(this.color, 0.25)} 100%)`;
                button.style.transform = "translateY(-2px) scale(1.1)";
                button.style.boxShadow = `
                    0 4px 16px ${hexToRgba(this.color, 0.31)},
                    0 0 20px ${hexToRgba(this.color, 0.25)},
                    inset 0 1px 0 rgba(255, 255, 255, 0.3)
                `;
                button.style.borderColor = `${this.color}80`;
                
                // Add SVG-specific hover effects (glow/pulse)
                if (isPlayPauseBtn || isMuteBtn) {
                    const svg = button.querySelector('svg');
                    if (svg) {
                        svg.style.filter = `drop-shadow(0 0 8px ${this.color}CC)`;
                        svg.style.transition = 'filter 0.3s ease';
                    }
                }
            });
            
            button.addEventListener('mouseleave', () => {
                button.style.background = `linear-gradient(135deg, 
                    ${hexToRgba(this.color, 0.25)} 0%, 
                    ${hexToRgba(this.color, 0.125)} 100%)`;
                button.style.transform = "translateY(0) scale(1)";
                button.style.boxShadow = `
                    0 2px 8px ${hexToRgba(this.color, 0.19)},
                    inset 0 1px 0 rgba(255, 255, 255, 0.2)
                `;
                button.style.borderColor = `${this.color}60`;
                
                // Remove SVG-specific hover effects
                if (isPlayPauseBtn || isMuteBtn) {
                    const svg = button.querySelector('svg');
                    if (svg) {
                        svg.style.filter = 'none';
                    }
                }
            });
            
            // Add active state
            button.addEventListener('mousedown', () => {
                button.style.transform = "translateY(0) scale(0.95)";
                button.style.boxShadow = `
                    0 1px 4px ${this.color}40,
                    inset 0 1px 0 rgba(255, 255, 255, 0.1)
                `;
            });
            
            button.addEventListener('mouseup', () => {
                button.style.transform = "translateY(-2px) scale(1.05)";
                button.style.boxShadow = `
                    0 4px 16px ${this.color}50,
                    inset 0 1px 0 rgba(255, 255, 255, 0.3)
                `;
            });
        });
        
    }

    ensureBaseStyles() {
        if (document.getElementById('th-base-styles')) return;
        const style = document.createElement('style');
        style.id = 'th-base-styles';
        style.textContent = `
            .th-control-btn { display:flex; align-items:center; justify-content:center; padding:0; color:#fff; overflow:visible; border:none; background:transparent; user-select:none; }
            .th-exit-btn { min-width:20px; height:20px; border-radius:50%; font-size:8px; }
            /* Ensure control visibility works even with WordPress theme CSS overrides */
            #talkingHeadControls.th-controls-hover-hidden { opacity: 0 !important; }
            #talkingHeadControls.th-controls-hover-visible { opacity: 1 !important; }
        `;
        document.head.appendChild(style);
    }

    initIconCache() {
        this.icons = {
            play: this.createPlayIconSVG(1),
            pause: this.createPauseIconSVG(1),
            mute: this.createMuteIconSVG(1),
            unmute: this.createUnmuteIconSVG(1),
            exit: this.createExitIconSVG()
        };
    }
    
    // Duration bar methods
    updateDurationBar() {
        if (this.video.duration) {
            const progress = (this.video.currentTime / this.video.duration) * 100;
            this.durationProgress.style.width = progress + '%';
            this.durationHandle.style.left = progress + '%';
        }
    }
    
    seekToPosition(e) {
        if (this.video.duration) {
            const rect = this.durationBar.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            const percentage = clickX / rect.width;
            const newTime = percentage * this.video.duration;
            
            this.video.currentTime = Math.max(0, Math.min(this.video.duration, newTime));
            this.updateDurationBar();
        }
    }
    
    startDrag(e) {
        this.isDragging = true;
        this.seekToPosition(e);
    }
    
    drag(e) {
        if (this.isDragging) {
            this.seekToPosition(e);
        }
    }
    
    endDrag() {
        this.isDragging = false;
    }
    
    // Volume bar methods
    updateVolumeBar() {
        const volumePercent = this.currentVolume * 100;
        this.volumeLevel.style.width = volumePercent + '%';
        this.volumeHandle.style.left = volumePercent + '%';
    }
    
    setVolumeFromPosition(e) {
        const rect = this.volumeBar.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const percentage = Math.max(0, Math.min(1, clickX / rect.width));
        
        this.currentVolume = percentage;
        this.video.volume = this.currentVolume;
        this.updateVolumeBar();
    }
    
    startVolumeDrag(e) {
        this.isVolumeDragging = true;
        this.setVolumeFromPosition(e);
    }
    
    dragVolume(e) {
        if (this.isVolumeDragging) {
            this.setVolumeFromPosition(e);
        }
    }
    
    endVolumeDrag() {
        this.isVolumeDragging = false;
    }
    
    updatePlayButtons() {
        // Update both center play button visibility and control bar play button symbol
        const isPaused = this.video.paused;
        
        // Center play button visibility
        if (isPaused) {
            this.centerPlayBtn.style.opacity = '1';
            this.centerPlayBtn.style.pointerEvents = 'auto';
        } else {
            this.centerPlayBtn.style.opacity = '0';
            this.centerPlayBtn.style.pointerEvents = 'none';
        }
        
        // Control bar play button symbol - update SVG icon (using variant 1)
        this.playPauseBtn.innerHTML = isPaused ? this.icons.play : this.icons.pause;
    }
    
    // Button control methods
    togglePlayPause() {
        
        // Special behavior for loop-until-click mode
        if (this.loopUntilClickMode) {
            this.loopUntilClickMode = false; // Disable the mode
            this.loopMode = false; // Stop looping
            this.video.loop = false; // Stop HTML5 loop
            
            // Unmute the video
            this.video.muted = false;
            this.videoMuted = false;
            
            // Update mute button if it exists
            if (this.muteBtn) {
                this.muteBtn.innerHTML = this.icons.unmute;
            }
            
            // Restart from beginning and play normally
            this.video.currentTime = 0;
            this.video.play();
            return;
        }
        
        // Special behavior for loop mode (legacy)
        if (this.video.loop) {
            if (this.video.paused) {
                // Starting to play - restart from beginning, unmute, and stop looping
                this.video.currentTime = 0;
                this.video.loop = false; // Stop looping
                
                // Unmute the video (same as unmute button)
                this.video.muted = false;
                this.muteBtn.innerHTML = this.icons.unmute;
                
                // Remove muted overlay if it exists
                const mutedOverlay = document.getElementById('talkingHeadMutedOverlay');
                if (mutedOverlay) {
                    mutedOverlay.remove();
                }
                
                this.video.play();
            } else {
                // Already playing - pause the video
                this.video.pause();
            }
        } else {
            // Normal toggle behavior for non-loop modes
            if (THP_DEBUG) console.log('🎮 Normal toggle behavior');
            if (THP_DEBUG) console.log('📹 Video state:', {
                paused: this.video.paused,
                readyState: this.video.readyState,
                networkState: this.video.networkState,
                error: this.video.error,
                src: this.video.src,
                duration: this.video.duration,
                currentTime: this.video.currentTime
            });
            
            if (this.video.paused) {
                if (THP_DEBUG) console.log('▶️ Attempting to play video...');
                this.video.play().then(() => {
                    if (THP_DEBUG) console.log('✅ Video.play() succeeded');
                }).catch((error) => {
                    console.error('❌ Video.play() failed:', error);
                });
            } else {
                if (THP_DEBUG) console.log('⏸️ Pausing video...');
                this.video.pause();
            }
        }
        
        // Both center play button visibility and control bar button symbol are handled by event listeners
    }
    
    toggleMute() {
        if (this.video.muted) {
            if (THP_DEBUG) console.log('🔊 Unmute clicked');
            this.video.muted = false;
            this.muteBtn.innerHTML = this.icons.unmute; // cached
            this.hideMutedOverlay(); // Remove center unmute button when unmuting
        } else {
            if (THP_DEBUG) console.log('🔇 Mute toggled');
            this.video.muted = true;
            this.muteBtn.innerHTML = this.icons.mute; // cached
        }
    }
    
    hideMutedOverlay() {
        // Remove all muted overlays (in case multiple were created)
        const mutedOverlays = document.querySelectorAll('#talkingHeadMutedOverlay');
        mutedOverlays.forEach(overlay => overlay.remove());
    }
    
    closePlayer() {
        // Save volume before closing
        this.storageManager.saveVolumeToStorage();
        
        // Update player presence and save view counts
        this.playerOnPage = false;
        this.storageManager.saveViewCountsToStorage();
        
        // Remove the entire player from the page
        if (this.container && this.container.parentNode) {
            this.container.parentNode.removeChild(this.container);
        }
    }
    
    // Video end handler
    onVideoEnded() {
        // Always track completion metrics first
        this.trackVideoCompletion();
        
        // Handle special autostart modes first
        if (this.muteOnceMode) {
            this.muteOnceMode = false; // Disable the mode
            this.showPosterAndReset();
            return;
        }
        
        if (this.loopUntilClickMode) {
            // Don't return - let it continue to normal loop behavior
        }
        
        // Get exit setting and handle accordingly
        const exitSetting = this.getExitSetting();
        
        switch (exitSetting) {
            case 'no':
                // No exit behavior - do nothing
                break;
                
            case 'yes':
            case 'close':
                // Close player after delay
                this.closePlayerAfterDelay();
                break;

            case 'contact':
                // Show contact form and reset to poster
                this.showContactFormAndResetToPoster();
                break;

            case 'email':
                // Show email capture form
                this.showEmailCapture();
                break;

            case 'redirect':
                // Redirect to specified URL
                this.handleRedirect();
                break;

            case 'poster':
                // Show poster only
                this.showPosterOnly();
                break;

            default:
                // Unknown exit setting - do nothing (no fallback)
                if (THP_DEBUG) console.warn('⚠️ Unknown exitOnComplete setting:', exitSetting);
                break;
        }
    }
    
    // Track video completion metrics
    trackVideoCompletion() {
        // Use storage manager to track completion
        this.storageManager.trackVideoCompletion();
        
        // Mark as completed for this session
        this.hasCompleted = true;
    }
    
    // Get exit on complete setting
    getExitSetting() {
        return VIDEO_CONFIG.exitOnComplete || 'poster';
    }

    // Get redirect URL setting
    getRedirectURL() {
        const url = VIDEO_CONFIG.redirectURL;
        return (url && url !== 'auto') ? url : '';
    }

    // Get redirect delay setting
    getRedirectDelay() {
        return VIDEO_CONFIG.redirectDelay ? parseInt(VIDEO_CONFIG.redirectDelay) : 0;
    }

    // Get email subject setting
    getEmailSubject() {
        return (VIDEO_CONFIG.emailSubject && VIDEO_CONFIG.emailSubject !== 'auto') ? VIDEO_CONFIG.emailSubject : 'New lead from video';
    }
    
    // Reset video state for potential replay
    resetVideoForReplay() {
        // Reset video to beginning
        this.video.currentTime = 0;
        this.updateDurationBar();
        
        // Reset view tracking for potential rewatch
        this.hasViewed = false;
        this.hasStartedTracking = false; // Allow tracking on replay
        
        // Update play button state
        this.updatePlayButtons();
    }
    
    // Close player after a delay
    closePlayerAfterDelay() {
        setTimeout(() => {
            this.closePlayer();
        }, 1000); // Small delay to show video ended state
    }
    
    // Show poster and reset video for mute-once mode
    showPosterAndReset() {
        // Pause video and reset to beginning
        this.video.pause();
        this.video.currentTime = 0;
        
        // Unmute the video for future plays
        this.video.muted = false;
        this.videoMuted = false;
        
        // Update mute button if it exists
        if (this.muteBtn) {
            this.muteBtn.innerHTML = this.icons.unmute;
        }
        
        // Show poster image
        this.setPosterImage();
        
        // Update play button to show it's ready for replay
        this.updatePlayButtons();
    }
    
    // Reset position to original settings (for switching away from scroll mode)
    resetToOriginalPosition() {
        this.positionManager.resetToOriginalPosition();
    }
    
    // Helper method to reset video and show poster (used by multiple exit behaviors)
    resetVideoAndShowPoster() {
        // Pause video and reset to beginning
        this.video.pause();
        this.video.currentTime = 0;
        this.updateDurationBar();

        // Show poster image
        this.setPosterImage();
    }
    
    // Show contact form and reset to poster
    showContactFormAndResetToPoster() {
        this.resetVideoAndShowPoster();

        // Show contact form overlay
        this.showContactForm();
    }

    // Show email capture form
    showEmailCapture() {
        this.resetVideoAndShowPoster();

        // Show email capture overlay
        this.showEmailCaptureForm();
    }

    // Handle link redirect
    handleRedirect() {
        const redirectURL = this.getRedirectURL();
        const redirectDelay = this.getRedirectDelay();

        if (redirectURL) {
            if (redirectDelay > 0) {
                // Delayed redirect
                setTimeout(() => {
                    window.location.href = redirectURL;
                }, redirectDelay * 1000);
            } else {
                // Immediate redirect
                window.location.href = redirectURL;
            }
        } else {
            // No redirect URL configured - do nothing (no fallback)
            if (THP_DEBUG) console.warn('⚠️ Redirect exitOnComplete selected but no redirect URL configured');
        }
    }

    // Show poster only (no form)
    showPosterOnly() {
        this.resetVideoAndShowPoster();

        // Update play button to show it's ready for replay
        this.updatePlayButtons();
    }
    
    // Show email capture form overlay
    showEmailCaptureForm() {
        // Create email capture overlay inside player container
        const overlay = document.createElement('div');
        overlay.id = 'talkingHeadEmailOverlay';
        overlay.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10001;
            box-sizing: border-box;
            overflow: hidden;
        `;

        // Create email capture form with glassmorphism styling
        const form = document.createElement('div');
        form.style.cssText = `
            background: linear-gradient(135deg, 
                ${this.color}60 0%, 
                ${this.color}40 100%);
            backdrop-filter: blur(10px);
            webkit-backdrop-filter: blur(10px);
            border: 3px solid ${this.color}80;
            padding: 15px 20px;
            border-radius: 12px;
            text-align: center;
            max-width: 90%;
            max-height: 90%;
            width: 90%;
            box-sizing: border-box;
            margin: auto;
            flex-shrink: 0;
            box-shadow: 
                0 4px 16px ${this.color}40,
                0 2px 8px rgba(0, 0, 0, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.3);
        `;

        form.innerHTML = `
            <h3 style="margin: 0 0 10px 0; color: #FFFFFF; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3); font-size: 18px;">Get More Videos!</h3>
            <p style="margin: 0 0 12px 0; color: rgba(255, 255, 255, 0.9); text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2); font-size: 13px;">Enter your email to receive more video content</p>
            <form id="emailCaptureForm">
                <input type="email" id="emailInput" placeholder="your@email.com" required
                       style="width: 100%; padding: 10px; border: 2px solid rgba(255, 255, 255, 0.3); background: rgba(255, 255, 255, 0.2); color: #FFFFFF; border-radius: 8px; margin-bottom: 10px; font-size: 14px; box-sizing: border-box; backdrop-filter: blur(8px); webkit-backdrop-filter: blur(8px);">
                <style>
                    #emailInput::placeholder {
                        color: rgba(255, 255, 255, 0.7);
                    }
                </style>
                <button type="submit" id="emailSubmitBtn" style="width: 100%; padding: 10px; background: linear-gradient(135deg, ${this.color}80 0%, ${this.color}60 100%); color: white; border: 2px solid ${this.color}AA; border-radius: 8px; font-size: 14px; cursor: pointer; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3); box-shadow: 0 2px 8px ${this.color}50, inset 0 1px 0 rgba(255, 255, 255, 0.2);">
                    Subscribe
                </button>
            </form>
            <button id="emailCloseBtn" style="margin-top: 10px; background: none; border: none; color: rgba(255, 255, 255, 0.9); cursor: pointer; text-decoration: underline; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2); font-size: 12px;">
                Skip
            </button>
        `;

        // Handle form submission
        const emailForm = form.querySelector('#emailCaptureForm');
        emailForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = form.querySelector('#emailInput').value;
            const submitBtn = form.querySelector('#emailSubmitBtn');
            const originalText = submitBtn.textContent;

            // Validate email
            if (!email || !email.includes('@')) {
                alert('Please enter a valid email address');
                return;
            }

            // Show loading state
            submitBtn.textContent = 'Saving...';
            submitBtn.disabled = true;

            // Prepare data for PHP script
            const emailData = {
                email: email,
                to_email: this.contactEmail,
                video_name: this.videoName
            };

            // Send to PHP script
            fetch(this.path + '/save_email_capture.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(emailData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Thank you! Your email has been captured successfully.');
                } else {
                    alert('Error: ' + (data.message || 'Failed to save email. Please try again.'));
                }
            })
            .catch(error => {
                console.error('Email capture error:', error);
                alert('Error saving email. Please try again later.');
            })
            .finally(() => {
                // Reset button state
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                // Close overlay
                overlay.remove();
            });
        });

        // Handle close button
        const closeBtn = form.querySelector('#emailCloseBtn');
        closeBtn.addEventListener('click', () => {
            overlay.remove();
        });

        overlay.appendChild(form);
        this.container.appendChild(overlay);
    }

    // Show contact form overlay
    showContactForm() {
        // Create contact form overlay inside player container
        const overlay = document.createElement('div');
        overlay.id = 'talkingHeadContactOverlay';
        overlay.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: transparent;
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        `;
        
        // Create contact form
        const form = document.createElement('div');
        form.style.cssText = `
            background: rgba(0, 115, 255, 0.6);
            backdrop-filter: blur(8px);
            webkit-backdrop-filter: blur(8px);
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 115, 255, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2);
            max-width: calc(100% - 20px);
            max-height: calc(100% - 20px);
            width: 95%;
            transform: scale(0.9);
            transition: transform 0.3s ease;
            overflow-y: auto;
        `;
        
        form.innerHTML = `
            <h3 style="margin: 0 0 8px 0; color: #FFFFFF; font-size: 16px; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);">Get in Touch</h3>
            <form id="contactForm">
                <div style="margin-bottom: 8px;">
                    <label style="display: block; margin-bottom: 2px; font-weight: 500; color: #FFFFFF; font-size: 12px; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);">Name:</label>
                    <input type="text" name="name" required style="width: 100%; padding: 6px; border: 1px solid rgba(255, 255, 255, 0.3); background: rgba(255, 255, 255, 0.2); color: #FFFFFF; border-radius: 4px; font-size: 12px; box-sizing: border-box; placeholder-color: rgba(255, 255, 255, 0.7);">
                </div>
                <div style="margin-bottom: 8px;">
                    <label style="display: block; margin-bottom: 2px; font-weight: 500; color: #FFFFFF; font-size: 12px; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);">Email:</label>
                    <input type="email" name="email" required style="width: 100%; padding: 6px; border: 1px solid rgba(255, 255, 255, 0.3); background: rgba(255, 255, 255, 0.2); color: #FFFFFF; border-radius: 4px; font-size: 12px; box-sizing: border-box; placeholder-color: rgba(255, 255, 255, 0.7);">
                </div>
                <div style="margin-bottom: 10px;">
                    <label style="display: block; margin-bottom: 2px; font-weight: 500; color: #FFFFFF; font-size: 12px; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);">Message:</label>
                    <textarea name="message" rows="2" required style="width: 100%; padding: 6px; border: 1px solid rgba(255, 255, 255, 0.3); background: rgba(255, 255, 255, 0.2); color: #FFFFFF; border-radius: 4px; font-size: 12px; resize: vertical; box-sizing: border-box; placeholder-color: rgba(255, 255, 255, 0.7);"></textarea>
                </div>
                <div style="display: flex; gap: 6px; justify-content: flex-end;">
                    <button type="button" id="closeContactForm" style="padding: 6px 12px; border: 1px solid rgba(255, 255, 255, 0.3); background: rgba(255, 255, 255, 0.2); color: #FFFFFF; border-radius: 4px; cursor: pointer; font-size: 12px;">Cancel</button>
                    <button type="submit" style="padding: 6px 12px; background: rgba(255, 255, 255, 0.3); color: #FFFFFF; border: 1px solid rgba(255, 255, 255, 0.5); border-radius: 4px; cursor: pointer; font-size: 12px;">Send</button>
                </div>
            </form>
        `;
        
        overlay.appendChild(form);
        this.container.appendChild(overlay);
        
        // Animate in
        setTimeout(() => {
            overlay.style.opacity = '1';
            form.style.transform = 'scale(1)';
        }, 10);
        
        // Handle form submission
        form.querySelector('#contactForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            // Send email via PHP
            this.sendContactEmail(data);
        });
        
        // Handle close button
        form.querySelector('#closeContactForm').addEventListener('click', () => {
            this.closeContactForm();
        });
        
        // Close on overlay click
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                this.closeContactForm();
            }
        });
    }
    
    // Send contact email using PHP
    sendContactEmail(formData) {
        // Show loading state
        const submitBtn = document.querySelector('#contactForm button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;

        // Prepare email data
        const emailData = {
            name: formData.name,
            email: formData.email,
            message: formData.message,
            to_email: this.contactEmail,
            video_name: this.videoName
        };

        if (THP_DEBUG) console.log('📧 Contact form submission:', {
            to_email: this.contactEmail,
            from_email: formData.email,
            from_name: formData.name,
            video_name: this.videoName,
            message_length: formData.message.length
        });

        // Send to PHP script
        fetch(this.path + '/send_email.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(emailData)
        })
        .then(response => {
            if (THP_DEBUG) console.log('📧 Email send response status:', response.status);
            return response.json();
        })
        .then(data => {
            if (THP_DEBUG) console.log('📧 Email send response data:', data);
            if (data.success) {
                // Check if it was saved locally (email failed)
                if (data.saved_locally) {
                    if (THP_DEBUG) console.log('⚠️ Email delivery failed, but saved locally');
                    if (THP_DEBUG) console.log('📧 SMTP Error details:', data.error_details);
                    alert('Thank you for your message! Email delivery encountered an issue, but your message was saved and we will respond soon.\n\nError details: ' + (data.error_details || 'Unknown error'));
                } else {
                    if (THP_DEBUG) console.log('✅ Email sent successfully');
                    alert('Thank you for your message! We\'ll get back to you soon.');
                }
                this.closeContactForm();
            } else {
                console.error('❌ Email send failed:', data.message);
                console.error('📧 Error details:', data.error_details);
                throw new Error(data.message || 'Unknown error');
            }
        })
        .catch(error => {
            console.error('Email send failed:', error);
            alert('Sorry, there was an error sending your message. Please try again or contact us directly at ' + this.contactEmail);
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        });
    }

    // Close contact form
    closeContactForm() {
        const overlay = document.getElementById('talkingHeadContactOverlay');
        if (overlay) {
            overlay.style.opacity = '0';
            overlay.querySelector('div').style.transform = 'scale(0.9)';
            setTimeout(() => {
                if (overlay.parentNode) {
                    overlay.parentNode.removeChild(overlay);
                }
            }, 300);
        }
    }
    
    // Simple Page URL Configuration Methods
    
    
    /**
     * Set multiple page URLs at once
     * @param {string[]} pageUrls - Array of page URLs
     */
    setPageUrls(pageUrls) {
        if (Array.isArray(pageUrls)) {
            this.showOnPages = pageUrls.filter(url => typeof url === 'string' && url.trim());
            if (THP_DEBUG) console.log(`Set page URLs:`, this.showOnPages);
        } else {
            console.error('Page URLs must be an array of strings');
        }
    }
    
    
    /**
     * Check if video should show on current page
     * @returns {boolean} True if video should show on current page
     */
    shouldShowOnCurrentPage() {
        const currentUrl = window.location.href;
        
        // If no pages configured, show on all pages
        if (this.showOnPages.length === 0) {
            return true;
        }
        
        // Check if current URL matches any configured page
        for (let i = 0; i < this.showOnPages.length; i++) {
            const pageUrl = this.showOnPages[i];
            
            if (currentUrl === pageUrl) {
                return true;
            }
        }
        
        return false;
    }
    
}

/**
 * Dynamically load a JavaScript module
 * @param {string} src - Path to the JavaScript file
 * @returns {Promise} Promise that resolves when the script loads
 */
function loadModule(src) {
    return new Promise((resolve, reject) => {
        const modulePath = src.split('/').pop().replace('.js', '');
        const isAlreadyLoaded = (
            (modulePath === 'config-manager' && typeof window.ConfigManager !== 'undefined') ||
            (modulePath === 'storage-manager' && typeof window.VideoStorageManager !== 'undefined') ||
            (modulePath === 'position-manager' && typeof window.PositionManager !== 'undefined')
        );
        if (isAlreadyLoaded) return resolve();

        const script = document.createElement('script');
        script.src = src;

        script.onload = () => {
            const ok = (
                (modulePath === 'config-manager' && typeof window.ConfigManager === 'function') ||
                (modulePath === 'storage-manager' && typeof window.VideoStorageManager === 'function') ||
                (modulePath === 'position-manager' && typeof window.PositionManager === 'function')
            );
            ok ? resolve() : reject(new Error(`Module ${modulePath} failed to export`));
        };
        script.onerror = () => reject(new Error(`Failed to load module: ${src}`));
        document.head.appendChild(script);
    });
}

/**
 * Load all required modules before initializing player
 */
async function initializePlayerWithModules() {
    try {
        // Determine base path from VIDEO_CONFIG, falling back to default folder
        const configPath = (typeof VIDEO_CONFIG.path === 'string' && VIDEO_CONFIG.path.trim() !== '')
            ? VIDEO_CONFIG.path
            : 'talkingheads';
        const configPathIsAbsolute = /^https?:\/\//i.test(configPath);
        let basePath = configPath;

        if (!configPathIsAbsolute) {
            // Try to get path from script that loaded this file
            const scripts = document.getElementsByTagName('script');
            for (let i = scripts.length - 1; i >= 0; i--) {
                const script = scripts[i];
                if (script.src && script.src.includes('player.js')) {
                    const match = script.src.match(/(.*\/)player\.js/);
                    if (match) {
                        // Extract directory path (relative or absolute)
                        const fullPath = match[1];
                        // Convert absolute URL to relative path if needed
                        if (fullPath.startsWith('http://') || fullPath.startsWith('https://')) {
                            const url = new URL(fullPath);
                            basePath = (url.origin + url.pathname).replace(/\/$/, '');
                        } else {
                            basePath = fullPath.replace(/\/$/, '');
                        }
                        break;
                    }
                }
            }
        }

        // Load modules in order
        if (THP_DEBUG) console.log('Loading modules from:', basePath);
        await loadModule(basePath + '/modules/config-manager.js');
        await loadModule(basePath + '/modules/storage-manager.js');
        await loadModule(basePath + '/modules/position-manager.js');
        if (THP_DEBUG) console.log('Modules loaded');

        // Verify all modules are available (minimal log)
        if (THP_DEBUG) console.log('Verifying modules');
        
        if (typeof window.ConfigManager === 'undefined') {
            throw new Error('ConfigManager module failed to load');
        }
        if (typeof window.VideoStorageManager === 'undefined') {
            throw new Error('VideoStorageManager module failed to load');
        }
        if (typeof window.PositionManager === 'undefined') {
            throw new Error('PositionManager module failed to load');
        }
        
        // Verify they are actually constructible (classes)
        if (typeof window.ConfigManager !== 'function') {
            throw new Error('ConfigManager is not a constructor');
        }
        if (typeof window.VideoStorageManager !== 'function') {
            throw new Error('VideoStorageManager is not a constructor');
        }
        if (typeof window.PositionManager !== 'function') {
            throw new Error('PositionManager is not a constructor');
        }

        // Initialize player
        window.VIDEO_CONFIG = VIDEO_CONFIG;
        if (THP_DEBUG) console.log('⚙️ VIDEO_CONFIG loaded:', VIDEO_CONFIG);
        window.talkingHeadPlayer = new TalkingHeadPlayer();

        // Debug helper removed; VIDEO_CONFIG is authoritative for behavior\n

    } catch (error) {
        console.error('❌ Failed to initialize player:', error);
        throw error;
    }
}

// Initialize player when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initializePlayerWithModules();
});

