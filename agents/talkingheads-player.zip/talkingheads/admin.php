<?php
// Handle AJAX requests directly in admin.php
require_once __DIR__ . '/admin-functions.php';

// Handle AJAX POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];
    $playerFile = isset($_POST['playerFile']) ? $_POST['playerFile'] : 'player.js';
    
    if (!isValidPlayerFilename($playerFile)) {
        echo json_encode(['success' => false, 'error' => 'Invalid player file']);
        exit;
    }
    
    if ($action === 'getConfig') {
        $config = getVideoConfig($playerFile);
        echo json_encode(['success' => true, 'config' => $config]);
    } elseif ($action === 'saveConfig') {
        // Parse config from POST data (FormData sends as config[key]=value)
        // PHP automatically parses config[videoName]=value into $_POST['config']['videoName']
        $config = isset($_POST['config']) && is_array($_POST['config']) ? $_POST['config'] : array();
        
        // Ensure videoName is present (it should come from the form)
        if (empty($config['videoName']) && isset($_POST['videoName'])) {
            $config['videoName'] = $_POST['videoName'];
        }
        
        // Debug output for troubleshooting
        $debug = array(
            'received_config' => $config,
            'videoName_set' => isset($config['videoName']),
            'videoName_value' => isset($config['videoName']) ? $config['videoName'] : 'NOT SET',
            'all_post_keys' => array_keys($_POST)
        );
        
        // Log to PHP error log for debugging
        error_log('Admin saveConfig - Debug: ' . json_encode($debug));
        
        if (updateVideoConfig($playerFile, $config)) {
            echo json_encode(['success' => true, 'message' => 'Settings saved successfully', 'debug' => $debug]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to save settings', 'debug' => $debug]);
        }
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Talking Head Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/admin.css">
    <!-- Equal-height stat cards across rows/cols -->
    <style>
        /* Ensure equal height only for designated stat rows */
        .th-stat-row > [class^="col-"], .th-stat-row > [class*=" col-"] { display: flex; }
        .th-stat-row > [class^="col-"] > .stat-card, .th-stat-row > [class*=" col-"] > .stat-card { flex: 1 1 auto; height: 100%; }
    </style>
    <!-- JSONEditor CSS -->
    <link href="https://cdn.jsdelivr.net/npm/jsoneditor@10.0.0/dist/jsoneditor.min.css" rel="stylesheet">
</head>
<body class="bg-gradient">
    <div class="container-fluid py-3">
        <div class="row g-3 h-100">
            <!-- Settings Panel -->
            <div class="col-lg-6">
                <div class="panel">
            <h2>
                <div class="icon">⚙️</div>
                Video Settings</h2>
            
            
            <?php
            // Read setupType from VIDEO_CONFIG and validate
            $videoFiles = glob("*.webm");
            $videoCount = count($videoFiles);
            $config = getVideoConfig('player.js');
            
            // Auto-detect setupType if missing (backward compatibility)
            $setupType = isset($config['setupType']) ? $config['setupType'] : ($videoCount > 1 ? 'multiple' : 'single');
            
            // Validate: multiple setup requires 2+ videos
            $setupValidation = '';
            if ($setupType === 'multiple' && $videoCount < 2) {
                $setupValidation = 'error';
            }
            ?>
            
                <!-- VIDEO INFORMATION SECTION -->
                <div class="setting-group" style="margin-bottom: 10px; padding: 10px; background: #e8f5e8; border-radius: 8px; border: 1px solid #c3e6c3;">
                    <h3 style="margin-bottom: 4px; color: #2d5a2d;">📹 Video Information</h3>
                    
                    <div class="row g-1">
                        <div class="col-4">
                            <div class="form-group">
                                <label for="videoSelect" data-bs-toggle="tooltip" title="Choose which video file to use for this player">Select Video:</label>
                                <select id="videoSelect">
                                    <?php
                                    // Auto-populate video dropdown
                                    $videoFiles = glob("*.webm");
                foreach ($videoFiles as $videoFile) {
                    $videoName = pathinfo($videoFile, PATHINFO_FILENAME);
                    echo "<option value=\"$videoName\">$videoName</option>\n";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label for="posterSelect" data-bs-toggle="tooltip" title="Image shown before video starts playing">Poster Image:</label>
                                <select id="posterSelect">
                                    <?php
                                    // Auto-populate poster dropdown
                                    $posterFiles = glob("*.png");
                                    foreach ($posterFiles as $posterFile) {
                                        $posterName = pathinfo($posterFile, PATHINFO_FILENAME);
                                        echo "<option value=\"$posterName\">$posterName</option>\n";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label for="setupType" data-bs-toggle="tooltip" title="Single: one player with swappable videos | Multiple: separate player per video">Setup Type:</label>
                                <select id="setupType">
                                    <option value="single" <?php echo ($setupType === 'single') ? 'selected' : ''; ?>>Single</option>
                                    <option value="multiple" <?php echo ($setupType === 'multiple') ? 'selected' : ''; ?>>Multiple</option>
                                </select>
                            </div>
                        </div>
                    </div>
            </div> 

            <!-- PLAYBACK SETTINGS SECTION -->
            <div class="setting-group">
                <h3>Playback Settings</h3>
                
                <!-- Top Row: Autostart, Exit on Complete, Control Bar -->
                <div class="row g-1 mb-2">
                    <div class="col-4">
                        <div class="form-group">
                            <label for="autostart" data-bs-toggle="tooltip" title="Decide what happens when the player loads - show poster, autoplay, or other behaviors">Autostart Mode:</label>
                            <select id="autostart">
                                <optgroup label="Basic Modes">
                                    <option value="poster">Poster - Show Poster Only</option>
                                    <option value="yes" selected>Yes - Autoplay with Sound</option>
                                    <option value="mute">Mute - Autoplay Muted Once, Then Poster</option>
                                    <option value="loop">Loop - Autoplay Muted Loop Until Click</option>
                                </optgroup>
                                <optgroup label="Session-Based (Resets on Browser Close)">
                                    <option value="once">Once - Play Once, Then Hide</option>
                                    <option value="picSession">Pic Session - Play Once, Then Poster</option>
                                    <option value="muteSession">Mute Session - Play Once, Then Muted</option>
                                </optgroup>
                                <optgroup label="Permanent (localStorage)">
                                    <option value="onceLocal">Once Local - Play Once Forever</option>
                                    <option value="picLocal">Pic Local - Once, Then Poster Forever</option>
                                    <option value="muteLocal">Mute Local - Once, Then Muted Forever</option>
                                </optgroup>
                                <optgroup label="Interactive Modes">
                                    <option value="hover">Hover - Play on Mouse Over</option>
                                    <option value="scroll">Scroll - Play When Scrolled Into View</option>
                                </optgroup>
                                <optgroup label="Advanced Modes">
                                    <option value="slide">Slide - Slide In Animation</option>
                                    <option value="gostopgo">Go-Stop-Go - Pause at Time</option>
                                    <option value="delay">Delay - Delayed Autoplay</option>
                                </optgroup>
                            </select>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="exitOnComplete" data-bs-toggle="tooltip" title="What happens when the video finishes playing?">Exit on Complete:</label>
                            <select id="exitOnComplete">
                                <option value="poster" selected>Poster - Show Poster Image</option>
                                <option value="close">Close - Hide Player</option>
                                <option value="contact">Contact - Show Contact Form</option>
                                <option value="email">Email - Email Capture</option>
                                <option value="redirect">Redirect - Send to URL</option>
                                <option value="no">No - Do Nothing</option>
                            </select>
                            <small id="exitHelpText" style="display: block; margin-top: 1px; color: #666; font-size: 11px;"></small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="controlsMode" data-bs-toggle="tooltip" title="When should the video control bar be visible?">Control Bar:</label>
                            <select id="controlsMode">
                                <option value="always">Always Show</option>
                                <option value="hover" selected>Show on Hover</option>
                                <option value="hide">Never Show</option>
                            </select>
                            <small style="display: block; margin-top: 1px; color: #666; font-size: 11px;">
                                When to display video controls
                            </small>
                        </div>
                    </div>
                </div>

                <!-- Second Row: Player Color, Z-Index, Scroll Threshold -->
                <div class="row g-1 mb-2">
                    <div class="col-4">
                        <div class="form-group">
                            <label for="playerColor" style="margin-bottom: 4px; font-size: 12px;" data-bs-toggle="tooltip" title="Primary color for the video player interface">Player Color:</label>
                            <div style="display: flex; align-items: center; gap: 6px;">
                                <input type="color" id="playerColor" value="#549bff" style="width: 35px; height: 28px; border: none; border-radius: 3px; cursor: pointer;">
                                <input type="text" id="playerColorText" value="#549bff" style="flex: 1; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-family: monospace; font-size: 11px;">
                                <button type="button" onclick="resetPlayerColor()" style="padding: 4px 8px; background: #6c757d; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 11px;">Reset</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="playerZIndex" style="margin-bottom: 4px; font-size: 12px;" data-bs-toggle="tooltip" title="Layer order - higher numbers appear above other elements">Z-Index:</label>
                            <input type="number" id="playerZIndex" value="9999" min="1" max="99999" step="1" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                            <small style="font-size: 10px; color: #666; margin-top: 1px; display: block;">💡 Controls layer order - higher numbers appear above other page elements</small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="scrollThreshold" style="margin-bottom: 4px; font-size: 12px;" data-bs-toggle="tooltip" title="How far down the page before video appears (0.1 = 10%, 1.0 = 100%)">Scroll Threshold:</label>
                            <div style="display: flex; align-items: center; gap: 6px;">
                                <input type="range" id="scrollThreshold" min="0.1" max="1.0" step="0.1" value="0.5" style="flex: 1;">
                                <span id="scrollThresholdValue" style="min-width: 30px; text-align: center; font-weight: bold; font-size: 11px;">0.5</span>
                            </div>
                            <small style="font-size: 10px; color: #666; margin-top: 1px; display: block;">💡 Determines how far the user must scroll (as percentage) before player activates</small>
                        </div>
                    </div>
                </div>

                <div class="row g-1 mb-2">
                    <div class="col-12">
                        <div class="form-group">
                            <label for="playerPath" style="margin-bottom: 4px; font-size: 12px;" data-bs-toggle="tooltip" title="Folder or full URL where player assets (videos, scripts, forms) live">Player Path:</label>
                            <input type="text" id="playerPath" value="talkingheads" placeholder="talkingheads or https://www.whiteboard.video/player" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-family: monospace; font-size: 11px;">
                            <small style="font-size: 10px; color: #666; margin-top: 1px; display: block;">💡 Accepts relative folders (e.g., talkingheads) or full URLs like https://www.whiteboard.video/player</small>
                        </div>
                    </div>
                </div>

                <!-- Conditional Fields -->
                <div class="form-group" id="timeStopGroup" style="display: none;">
                    <label for="timeStop" data-bs-toggle="tooltip" title="For Go-Stop-Go: Video pauses at this time. For Delay: Video starts after this delay">Time Stop (seconds):</label>
                    <input type="number" id="timeStop" min="0" step="0.1" value="1" placeholder="1.0">
                    <small>For Go-Stop-Go: Video pauses at this time. For Delay: Video starts after this delay.</small>
                </div>

                <!-- Conditional Redirect URL Field -->
                <div class="form-group" id="redirectGroup" style="display: none;">
                    <label for="redirectURL" data-bs-toggle="tooltip" title="URL to redirect users to when video completes (if Exit on Complete is set to Redirect)">Redirect URL:</label>
                    <input type="url" id="redirectURL" placeholder="https://example.com/page" value="">
                    <small style="display: block; margin-top: 1px; color: #666; font-size: 11px;">
                        URL where users will be sent when video completes
                    </small>
                </div>

                <!-- Conditional Redirect Delay Field -->
                <div class="form-group" id="redirectDelayGroup" style="display: none;">
                    <label for="redirectDelay" data-bs-toggle="tooltip" title="How long to wait before redirecting (0 = immediate redirect)">Redirect Delay (seconds):</label>
                    <input type="number" id="redirectDelay" min="0" step="0.5" value="0" placeholder="0">
                    <small style="display: block; margin-top: 1px; color: #666; font-size: 11px;">
                        Wait this many seconds before redirecting (0 = immediate)
                    </small>
                </div>

                <!-- Conditional Email Capture Settings -->
                <div class="form-group" id="emailCaptureGroup" style="display: none;">
                    <label for="emailSubject" data-bs-toggle="tooltip" title="Subject line for email notifications when users provide their email">Email Subject:</label>
                    <input type="text" id="emailSubject" placeholder="New lead from video" value="auto">
                    <small style="display: block; margin-top: 1px; color: #666; font-size: 11px;">
                        Subject line for email capture notifications
                    </small>
                </div>

            </div>

            <!-- Quick Save Button for Long Settings -->
            <div style="text-align: center; margin: 10px 0; padding: 8px; background: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef;">
                <button class="save-btn" onclick="saveSettings()" style="padding: 10px 20px; font-size: 14px; font-weight: 600;">💾 Save All Settings</button>
                <p style="margin: 8px 0 0 0; font-size: 12px; color: #666;">Save all current settings to the video player</p>
            </div>

            <!-- POSITION SETTINGS SECTION -->
            <div class="setting-group">
                <h3 style="text-align: center;">Position Settings</h3>
                
                <div class="row g-1 mb-2">
                    <!-- Position Grid - Compact -->
                    <div class="col-3">
                        <div class="position-grid-compact">
                            <div class="row g-1">
                                <div class="col-4">
                                    <button class="btn btn-outline-secondary btn-sm position-btn" data-position="top-left" data-bs-toggle="tooltip" title="Top Left - Video appears in the top-left corner of the screen" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">TL</button>
                                </div>
                                <div class="col-4">
                                    <button class="btn btn-outline-secondary btn-sm position-btn" data-position="top-center" data-bs-toggle="tooltip" title="Top Center - Video appears centered at the top of the screen" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">TC</button>
                                </div>
                                <div class="col-4">
                                    <button class="btn btn-outline-secondary btn-sm position-btn" data-position="top-right" data-bs-toggle="tooltip" title="Top Right - Video appears in the top-right corner of the screen" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">TR</button>
                                </div>
                                <div class="col-4">
                                    <button class="btn btn-outline-secondary btn-sm position-btn" data-position="middle-left" data-bs-toggle="tooltip" title="Middle Left - Video appears centered vertically on the left side of the screen" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">ML</button>
                                </div>
                                <div class="col-4">
                                    <button class="btn btn-outline-secondary btn-sm position-btn" data-position="center" data-bs-toggle="tooltip" title="Center - Video appears in the center of the screen (both horizontally and vertically)" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">C</button>
                                </div>
                                <div class="col-4">
                                    <button class="btn btn-outline-secondary btn-sm position-btn" data-position="middle-right" data-bs-toggle="tooltip" title="Middle Right - Video appears centered vertically on the right side of the screen" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">MR</button>
                                </div>
                                <div class="col-4">
                                    <button class="btn btn-outline-secondary btn-sm position-btn" data-position="bottom-left" data-bs-toggle="tooltip" title="Bottom Left - Video appears in the bottom-left corner of the screen" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">BL</button>
                                </div>
                                <div class="col-4">
                                    <button class="btn btn-outline-secondary btn-sm position-btn" data-position="bottom-center" data-bs-toggle="tooltip" title="Bottom Center - Video appears centered at the bottom of the screen" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">BC</button>
                                </div>
                                <div class="col-4">
                                    <button class="btn btn-primary btn-sm position-btn active" data-position="bottom-right" data-bs-toggle="tooltip" title="Bottom Right - Video appears in the bottom-right corner of the screen (default)" style="width: 100%; padding: 6px; font-size: 11px; min-height: 28px;">BR</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Live Video Player Preview -->
                    <div class="col-9">
                        <div class="preview-section">
                            <div class="preview-container" style="position: relative; width: 100%; aspect-ratio: 16/9; border: 2px dashed #ccc; border-radius: 8px; background: #f8f9fa; overflow: hidden;">
                                <div id="previewPlayer" style="position: absolute; width: 80px; height: 80px; background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 4px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 12px; box-shadow: 0 2px 6px rgba(0,0,0,0.3); line-height: 1.2; text-align: center;">
                                    Video<br>Player
                                </div>
                            </div>
                            <small class="text-muted" style="font-size: 11px; text-align: center; display: block;">Real-time preview</small>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="customPositionSelect" data-bs-toggle="tooltip" title="Enable custom positioning to manually set exact coordinates">Custom Position:</label>
                    <select id="customPositionSelect">
                        <option value="no">No Custom Position</option>
                        <option value="yes">Use Custom Position</option>
                    </select>
                </div>

                <div class="custom-position" id="customPosition">
                    <div class="row g-1">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="leftPos" class="form-label" data-bs-toggle="tooltip" title="Distance from left edge of screen (auto, 0px, 50%, etc.)">Left:</label>
                                <input type="text" class="form-control" id="leftPos" value="auto" placeholder="auto, 0px, 50%">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="rightPos" class="form-label" data-bs-toggle="tooltip" title="Distance from right edge of screen (auto, 0px, 50%, etc.)">Right:</label>
                                <input type="text" class="form-control" id="rightPos" value="0" placeholder="0px, auto">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="topPos" class="form-label" data-bs-toggle="tooltip" title="Distance from top edge of screen (auto, 0px, 50%, etc.)">Top:</label>
                                <input type="text" class="form-control" id="topPos" value="auto" placeholder="auto, 0px, 50%">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="bottomPos" class="form-label" data-bs-toggle="tooltip" title="Distance from bottom edge of screen (auto, 0px, 50%, etc.)">Bottom:</label>
                                <input type="text" class="form-control" id="bottomPos" value="0" placeholder="0px, auto">
                            </div>
                        </div>
                        <!-- Offsets are calculated automatically based on position and video dimensions -->
                        <div class="col-12">
                            <div class="form-group">
                                <label for="positionType" class="form-label" data-bs-toggle="tooltip" title="Fixed: stays in place when scrolling. Absolute: moves with page content">Position Type:</label>
                                <select id="positionType" class="form-select">
                                    <option value="fixed">Fixed</option>
                                    <option value="absolute">Absolute</option>
                                </select>
                                <small class="form-text text-muted">💡 <strong>Tip:</strong> Use "absolute" for scroll mode so video scrolls with page content</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- CONTACT FORM CUSTOMIZATION SECTION (affects both contact form AND email capture) -->
            <div class="setting-group" style="margin-bottom: 10px; padding: 10px; background: #f0f8ff; border-radius: 8px; border: 1px solid #b3d9ff;">
                <h3 style="margin-bottom: 4px; color: #0066cc;">📝 Contact Form & Email Capture Customization</h3>
                
                <!-- Global Contact Email -->
                <div style="margin-bottom: 8px; padding: 10px; background: #e3f2fd; border-radius: 6px; border: 1px solid #bbdefb;">
                    <h4 style="margin-bottom: 4px; font-size: 14px; color: #1976d2;">📧 Global Contact Email</h4>
                    <div class="form-group" style="margin-bottom: 4px;">
                        <label for="contactEmail" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="Email address where contact form submissions and email captures are sent">Contact Email:</label>
                        <input type="email" id="contactEmail" required placeholder="contact@example.com" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                        <small style="display: block; margin-top: 1px; color: #666; font-size: 10px;">
                            💡 Used for: Contact form submissions, email captures, and lead notifications
                        </small>
                    </div>
                </div>
                
                <!-- Form Fields Management -->
                <div style="margin-bottom: 8px;">
                    <h4 style="margin-bottom: 4px; font-size: 14px; color: #495057;">Form Fields</h4>
                    <div id="formFieldsList" style="margin-bottom: 10px;">
                        <!-- Form fields will be dynamically loaded here -->
                    </div>
                    <button type="button" onclick="addFormField()" style="padding: 4px 8px; background: #28a745; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 11px;">+ Add Field</button>
                </div>
                
                <!-- SMTP Settings -->
                <div style="margin-bottom: 8px;">
                    <h4 style="margin-bottom: 4px; font-size: 14px; color: #495057;">SMTP Email Settings</h4>
                    <div class="row g-1">
                        <div class="col-6">
                            <div class="form-group" style="margin-bottom: 4px;">
                                <label for="smtpHost" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="SMTP server address for sending emails (e.g., mail.websitetalkingheads.com)">SMTP Host:</label>
                                <input type="text" id="smtpHost" placeholder="mail.websitetalkingheads.com" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group" style="margin-bottom: 4px;">
                                <label for="smtpPort" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="SMTP server port (587 for STARTTLS, 465 for SSL, 25 for plain)">Port:</label>
                                <input type="number" id="smtpPort" placeholder="587" value="587" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                            </div>
                        </div>
                    </div>
                    <div class="row g-1">
                        <div class="col-6">
                            <div class="form-group" style="margin-bottom: 4px;">
                                <label for="smtpUsername" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="Username used to authenticate with SMTP server">Username:</label>
                                <input type="text" id="smtpUsername" placeholder="andy" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group" style="margin-bottom: 4px;">
                                <label for="smtpPassword" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="Password or app-specific password for SMTP authentication">Password:</label>
                                <input type="password" id="smtpPassword" placeholder="App password" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                            </div>
                        </div>
                    </div>
                    <div class="form-group" style="margin-bottom: 4px;">
                        <label for="smtpFromEmail" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="Email address that appears as the sender in outgoing emails">From Email:</label>
                        <input type="email" id="smtpFromEmail" placeholder="noreply@yourdomain.com" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                    </div>
                </div>
                
                <!-- Message Customization -->
                <div style="margin-bottom: 8px;">
                    <h4 style="margin-bottom: 4px; font-size: 14px; color: #495057;">Messages</h4>
                    <div class="form-group" style="margin-bottom: 4px;">
                        <label for="successMessage" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="Message shown to users when form submission is successful">Success Message:</label>
                        <input type="text" id="successMessage" value="Thank you! Your message has been sent successfully." style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                    </div>
                    <div class="form-group" style="margin-bottom: 4px;">
                        <label for="errorMessage" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="Message shown to users when form submission fails">Error Message:</label>
                        <input type="text" id="errorMessage" value="Sorry, there was an error sending your message. Please try again." style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                    </div>
                </div>
                
                <!-- Form Styling -->
                <div style="margin-bottom: 8px;">
                    <h4 style="margin-bottom: 4px; font-size: 14px; color: #495057;">Form Styling</h4>
                    <div class="row g-1">
                        <div class="col-6">
                            <div class="form-group" style="margin-bottom: 4px;">
                                <label for="formTitle" style="margin-bottom: 1px; font-size: 11px;" data-bs-toggle="tooltip" title="Title displayed at the top of the contact form">Form Title:</label>
                                <input type="text" id="formTitle" value="Get in Touch" style="width: 100%; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-size: 11px;">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group" style="margin-bottom: 4px;">
                                <label for="formBackgroundColor" style="margin-bottom: 4px; font-size: 11px;" data-bs-toggle="tooltip" title="Background color for the contact form">Background Color:</label>
                                <div style="display: flex; align-items: center; gap: 6px;">
                                    <input type="color" id="formBackgroundColor" value="#549bff" style="width: 35px; height: 28px; border: none; border-radius: 3px; cursor: pointer;">
                                    <input type="text" id="formBackgroundColorText" value="#549bff" style="flex: 1; padding: 4px; border: 1px solid #ddd; border-radius: 3px; font-family: monospace; font-size: 11px;">
                                    <button type="button" onclick="resetFormBackgroundColor()" style="padding: 4px 8px; background: #6c757d; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 11px;">Reset</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>

            <!-- URL CONFIGURATION SECTION -->
            <div class="setting-group" style="margin-bottom: 10px; padding: 10px; background: #fff8e1; border-radius: 8px; border: 1px solid #ffcc02;">
                <h3 style="margin-bottom: 4px; color: #f57c00;" data-bs-toggle="tooltip" title="Control which pages your video appears on. Leave empty to show everywhere, or specify exact URLs.">📍 URL Configuration</h3>
                <p style="font-size: 12px; color: #666; margin-bottom: 8px;">
                    Leave empty to show on all pages, or add specific URLs.
                </p>
                
                <div class="form-group">
                    <div style="display: flex; gap: 8px; margin-bottom: 8px;">
                        <input type="text" id="urlInput" placeholder="Enter URL (e.g., /contact, /about, /products)" style="flex: 1; padding: 6px; border: 1px solid #ddd; border-radius: 4px;">
                        <button type="button" onclick="addUrl()" style="padding: 6px 12px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">Add URL</button>
                    </div>
                    <div id="urlList" style="max-height: 120px; overflow-y: auto; border: 1px solid #ddd; border-radius: 4px; padding: 8px; background: #f8f9fa;">
                        <!-- URLs will be displayed here -->
                    </div>
                </div>
            </div>

            <button class="save-btn" onclick="saveSettings()">Save Settings</button>
                </div>
            </div>

            <!-- Analytics Panel -->
            <div class="col-lg-6">
                <div class="panel">
            <h2>
                <div class="icon">📊</div>
                Analytics Dashboard
            </h2>
            
            <button class="refresh-btn" onclick="refreshAnalytics()">🔄 Refresh Data</button>
            <button class="refresh-btn" onclick="createJsonForNewVideos()" style="background: #28a745; margin-left: 10px;">📁 Create JSON for New Videos</button>
            <button class="refresh-btn" onclick="clearStats()" style="background: #dc3545; margin-left: 10px;">🗑️ Clear Stats</button>

            <div class="row g-1 mb-2 th-stat-row">
                <div class="col-6">
                    <div class="stat-card">
                        <h4>Total Unique Visits</h4>
                        <div class="value" id="uniqueVisits">0</div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-card">
                        <h4>Total Views</h4>
                        <div class="value" id="totalViews">0</div>
                        <small class="text-muted">Reached 25% threshold</small>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-card">
                        <h4>Started Views</h4>
                        <div class="value" id="startedViews">0</div>
                        <small class="text-muted">All videos that started</small>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-card">
                        <h4>Abandoned Views</h4>
                        <div class="value" id="abandonedViews">0</div>
                        <small class="text-muted">Started but didn't reach 25%</small>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-card">
                        <h4>Engagement Rate</h4>
                        <div class="value" id="engagementRate">0%</div>
                        <small class="text-muted">% who reached 25%</small>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-card">
                        <h4>Completion Rate</h4>
                        <div class="value" id="completionRate">0%</div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="stat-card">
                        <h4>Avg. Watch Time</h4>
                        <div class="value" id="avgWatchTime">0s</div>
                    </div>
                </div>
            </div>

            <!-- Enhanced Analytics Cards -->
            <div class="row g-1 mb-2 th-stat-row">
                <div class="col-4">
                    <div class="stat-card">
                        <h4>📱 Session Views</h4>
                        <div class="value" id="sessionViews">0</div>
                        <small class="text-muted">Current session</small>
                    </div>
                </div>
                <div class="col-4">
                    <div class="stat-card">
                        <h4>💻 Device Stats</h4>
                        <div class="value" id="deviceBreakdown">-</div>
                        <small class="text-muted">Desktop/Mobile/Tablet</small>
                    </div>
                </div>
                <div class="col-4">
                    <div class="stat-card">
                        <h4>🚪 Exit Behavior</h4>
                        <div class="value" id="exitBreakdown">-</div>
                        <small class="text-muted">Most common action</small>
                    </div>
                </div>
            </div>

            <div class="setting-group">
                <h3>Player Status</h3>
                <p>
                    <span class="status-indicator status-offline" id="statusIndicator"></span>
                    <span id="playerStatus">Offline</span>
                </p>
            </div>
            
            <div class="setting-group">
                <h3>📊 Data Storage Status</h3>
                <div style="margin-bottom: 10px;">
                    <strong>Storage Method:</strong> <span id="storageMethod">Checking...</span>
                </div>
                <div style="margin-bottom: 10px;">
                    <strong>JSON File:</strong> <span id="jsonFileStatus">Checking...</span>
                </div>
                <div style="margin-bottom: 10px;">
                    <strong>Last Updated:</strong> <span id="lastUpdated">-</span>
                </div>
                <button class="refresh-btn" onclick="loadAnalytics()">🔄 Refresh Data</button>
            </div>

            <div class="setting-group">
                <h3>Video Information</h3>
                <p><strong>Current Video:</strong> <span id="currentVideo">19_v8</span></p>
                <p><strong>Path:</strong> <span id="videoPath">talkingheads</span></p>
                <p><strong>Poster:</strong> <span id="videoPoster">Thumb</span></p>
            </div>
            
            <div class="setting-group">
                <h3>📨 Contact Form Submissions</h3>
                <button class="refresh-btn" onclick="loadContactSubmissions()">🔄 Load Submissions</button>
                <div id="contactSubmissions" style="margin-top: 15px;">
                    <p style="color: #666;">Click "Load Submissions" to view saved contact form messages.</p>
                </div>
            </div>
            
            <div class="setting-group">
                <h3>✉️ Email Captures</h3>
                <button class="refresh-btn" onclick="loadEmailCaptures()">🔄 Load Email Captures</button>
                <div id="emailCaptures" style="margin-top: 15px;">
                    <p style="color: #666;">Click "Load Email Captures" to view captured email addresses.</p>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Video Management Panel -->
    <div class="row">
        <div class="col-12">
            <div class="panel">
                <h2>
                    <div class="icon">🎬</div>
                    Video Management
                </h2>
                
                <!-- Video Count Setting -->
                <div style="margin-bottom: 10px; padding: 8px; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 8px;">
                    <h3 style="margin: 0 0 8px 0; font-size: 14px; color: #856404;">⚙️ Video Count Setting</h3>
                    <p style="font-size: 11px; color: #856404; margin-bottom: 4px;">
                        Videos detected in folder: <strong><?php echo $videoCount; ?></strong>
                    </p>
                    <p style="font-size: 11px; color: #856404; margin-bottom: 8px;">
                        Setting in player.js: <strong id="currentVideoCount">Loading...</strong>
                    </p>
                    <button onclick="updateVideoCount()" style="padding: 6px 12px; background: #ffc107; color: #000; border: none; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                        🔧 Update Video Count to <?php echo $videoCount; ?>
                    </button>
                    <p style="font-size: 11px; color: #856404; margin-top: 6px;">
                        💡 Click to sync player.js with detected videos
                    </p>
                </div>
                
                <!-- Upload New Video Section -->
                <div class="setting-group">
                    <h3>📤 Upload New Video</h3>
                    <form id="videoUploadForm" enctype="multipart/form-data">
                        <div class="row g-1 mb-2">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="videoFile" class="form-label" data-bs-toggle="tooltip" title="Upload a .webm video file to add to your video library">Video File:</label>
                                    <input type="file" class="form-control" id="videoFile" accept=".webm,.mp4,.avi,.mov,.mkv" required>
                                    <small class="form-text text-muted">Supported formats: .webm, .mp4, .avi, .mov, .mkv</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="thumbnailFile" class="form-label" data-bs-toggle="tooltip" title="Optional thumbnail image for the video (will be used as poster)">Thumbnail Image:</label>
                                    <input type="file" class="form-control" id="thumbnailFile" accept=".png,.jpg,.jpeg,.gif">
                                    <small class="form-text text-muted">Optional: .png, .jpg, .jpeg, .gif</small>
                                </div>
                            </div>
                        </div>
                        <div class="row g-1 mb-2">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="videoDescription" class="form-label" data-bs-toggle="tooltip" title="Optional description for the video (for organization purposes)">Description:</label>
                                    <input type="text" class="form-control" id="videoDescription" placeholder="Optional description">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">📤 Upload Video</button>
                        <div id="uploadStatus" style="margin-top: 10px;"></div>
                    </form>
                </div>

                <div class="setting-group" style="margin-top: 10px;">
                    <h3>Poster Image Library</h3>
                    <p style="margin-bottom: 8px; font-size: 12px; color: #4d4d4d;">
                        Upload PNG poster images that are available in the poster selector above.
                    </p>
                    <form id="posterUploadForm" enctype="multipart/form-data">
                        <div class="row g-1 mb-2">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="posterImageFile" class="form-label" data-bs-toggle="tooltip" title="Upload a PNG poster image (saved next to the player files)">Poster Image File:</label>
                                    <input type="file" class="form-control" id="posterImageFile" accept=".png" required>
                                    <small class="form-text text-muted">PNG only. Will appear in the poster dropdown once uploaded.</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="posterName" class="form-label" data-bs-toggle="tooltip" title="Optional friendly name for the poster (letters, numbers, hyphen, underscore)">Poster Name (optional):</label>
                                    <input type="text" class="form-control" id="posterName" placeholder="Leave blank to use filename">
                                    <small class="form-text text-muted">Letters, numbers, underscores, and hyphens</small>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-outline-success">Upload Poster Image</button>
                        <div id="posterUploadStatus" style="margin-top: 10px;"></div>
                    </form>
                </div>

                <!-- Current Videos Section -->
                <div class="setting-group">
                    <h3>📁 Current Videos</h3>
                    <button class="refresh-btn" onclick="loadVideoList()">🔄 Refresh List</button>
                    <div id="videoList" style="margin-top: 15px;">
                        <p style="color: #666;">Click "Refresh List" to view current videos.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Config.json Visual Editor Panel -->
    <div class="row">
        <div class="col-12">
            <div class="panel" style="background: #fff9e6; border: 2px solid #ffc107;">
                <h2>
                    <div class="icon">⚙️</div>
                    Advanced Configuration Editor
                </h2>
                
                <div style="margin-bottom: 8px; padding: 12px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px;">
                    <p style="font-size: 12px; color: #856404; margin: 0;">
                        <strong>⚠️ Warning:</strong> This editor allows advanced users to modify raw JSON configuration files. Changes affect core player settings and may impact functionality. Use with caution.
                    </p>
                </div>
                
                <div class="setting-group">
                    <h3>📝 JSON Configuration Editor</h3>
                    <p style="font-size: 12px; color: #666; margin-bottom: 8px;">
                        Advanced users can edit the raw JSON configuration. Changes are saved directly to the config files.
                    </p>
                    
                    <div class="row g-1 mb-2">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="configFileSelect" data-bs-toggle="tooltip" title="Select which configuration file to edit">Configuration File:</label>
                                <select id="configFileSelect" class="form-select">
                                    <option value="talkinghead_config.json">talkinghead_config.json (Talking Head Config)</option>
                                    <option value="sync_config.jsonc">sync_config.jsonc (Deployment Config)</option>
                                    <option value="config.json">config.json (Legacy)</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="editorMode" data-bs-toggle="tooltip" title="Choose how to view and edit the configuration (Tree: visual, Code: raw JSON, Form: fields)">Editor Mode:</label>
                                <select id="editorMode" class="form-select">
                                    <option value="tree">Tree View (Recommended)</option>
                                    <option value="code">Code View</option>
                                    <option value="form">Form View</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-2">
                        <button class="btn btn-primary me-2" onclick="loadConfig()">📁 Load Config</button>
                        <button class="btn btn-success me-2" onclick="saveConfig()">💾 Save Config</button>
                        <button class="btn btn-warning me-2" onclick="validateConfig()">✅ Validate</button>
                        <button class="btn btn-info me-2" onclick="resetConfig()">🔄 Reset</button>
                        <button class="btn btn-secondary" onclick="downloadConfig()">📥 Download</button>
                    </div>
                    
                    <div id="editorStatus" class="alert alert-info" style="display: none; margin-bottom: 8px;">
                        <strong>Status:</strong> <span id="statusMessage">Ready</span>
                    </div>
                    
                    <div id="jsonEditor" style="height: 500px; border: 1px solid #ddd; border-radius: 8px;"></div>
                    
                    <div class="mt-3">
                        <small class="text-muted">
                            💡 <strong>Tips:</strong> Use Tree view for easy editing, Code view for raw JSON, Form view for structured editing. 
                            Always validate before saving. Changes are applied immediately to the system.
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- External JavaScript Files -->
    <script src="js/admin-common.js"></script>
    <script src="js/admin-config.js"></script>
    <script src="js/admin-videos.js"></script>
    <script src="js/admin-analytics.js"></script>
    <script src="js/admin-forms.js"></script>
    <script src="js/admin-player-behavior.js"></script>

    <script>
        // Consolidated status message utility function
        function showAdminStatus(message, type, containerId) {
            const defaultContainerIds = {
                'uploadStatus': {
                    position: 'inline',
                    elementSelector: '#uploadStatus'
                },
                'posterUploadStatus': {
                    position: 'inline',
                    elementSelector: '#posterUploadStatus'
                },
                'editorStatus': {
                    position: 'inline',
                    elementSelector: '#editorStatus',
                    messageSelector: '#statusMessage'
                },
                'playerBehaviorStatus': {
                    position: 'fixed',
                    elementSelector: '#playerBehaviorStatus',
                    top: '20px',
                    right: '20px'
                },
                'contactFormStatus': {
                    position: 'fixed',
                    elementSelector: '#contactFormStatus',
                    top: '60px',
                    right: '20px'
                }
            };
            
            const config = defaultContainerIds[containerId] || {
                position: 'inline',
                elementSelector: '#' + containerId
            };
            
            let statusDiv = document.querySelector(config.elementSelector);
            
            // For fixed position, create element if it doesn't exist
            if (!statusDiv && config.position === 'fixed') {
                statusDiv = document.createElement('div');
                statusDiv.id = containerId;
                statusDiv.style.cssText = `
                    position: fixed;
                    top: ${config.top || '20px'};
                    right: ${config.right || '20px'};
                    padding: 12px 20px;
                    border-radius: 6px;
                    color: white;
                    font-weight: 500;
                    z-index: 10000;
                    transition: all 0.3s ease;
                `;
                document.body.appendChild(statusDiv);
            }
            
            if (!statusDiv) {
                console.error('Status container not found:', containerId);
                return;
            }
            
            // Set message content
            if (config.messageSelector) {
                // For editorStatus with nested message span
                const messageSpan = statusDiv.querySelector(config.messageSelector) || statusDiv;
                messageSpan.textContent = message;
                statusDiv.className = 'alert alert-' + type;
                statusDiv.style.display = 'block';
            } else if (config.position === 'fixed') {
                // For fixed position elements
                statusDiv.textContent = message;
                statusDiv.style.backgroundColor = type === 'success' ? '#28a745' : type === 'warning' ? '#ffc107' : '#dc3545';
                statusDiv.style.display = 'block';
            } else {
                // For inline elements (uploadStatus)
                statusDiv.innerHTML = message;
                statusDiv.className = type === 'error' ? 'text-danger' : type === 'success' ? 'text-success' : 'text-info';
            }
            
            // Auto-hide after 3 seconds for success messages and fixed position elements
            if ((type === 'success' || config.position === 'fixed') && config.position !== 'inline') {
                setTimeout(() => {
                    statusDiv.style.display = 'none';
                }, 3000);
            } else if (type === 'success' && config.position === 'inline' && config.messageSelector) {
                // Special handling for editorStatus
                setTimeout(() => {
                    statusDiv.style.display = 'none';
                }, 3000);
            }
        }
        
        // Inline initialization and wrapper functions
        // Load settings - delegates to AdminConfig module
        function loadSettings() {
            AdminConfig.loadSettings();
        }

        // Save settings - delegates to AdminConfig module
        function saveSettings() {
            AdminConfig.saveSettings();
        }
        
        // URL Management Functions
        let currentUrls = [];

        function resolvePlayerPath() {
            const normalize = (value) => {
                if (window.AdminConfig && typeof window.AdminConfig.normalizePath === 'function') {
                    return window.AdminConfig.normalizePath(value);
                }
                if (typeof value !== 'string') {
                    return 'talkingheads';
                }
                const trimmed = value.trim();
                if (!trimmed) {
                    return 'talkingheads';
                }
                const normalized = trimmed.replace(/\\/g, '/').replace(/\/+$/, '');
                return normalized || 'talkingheads';
            };
            if (typeof window.currentPlayerPath === 'string' && window.currentPlayerPath.trim() !== '') {
                const normalizedCurrent = normalize(window.currentPlayerPath);
                window.currentPlayerPath = normalizedCurrent;
                return normalizedCurrent;
            }
            const pathInput = document.getElementById('playerPath');
            if (pathInput && pathInput.value.trim() !== '') {
                const normalizedInput = normalize(pathInput.value);
                window.currentPlayerPath = normalizedInput;
                return normalizedInput;
            }
            window.currentPlayerPath = 'talkingheads';
            return 'talkingheads';
        }
        
        function loadUrls() {
            const videoName = document.getElementById('videoSelect').value;
            const savedUrls = localStorage.getItem(videoName + '_showOnPages');
            
            if (savedUrls) {
                try {
                    currentUrls = JSON.parse(savedUrls);
                } catch (e) {
                    currentUrls = [];
                }
            } else {
                currentUrls = [];
            }
            
            renderUrlList();
        }
        
        function addUrl() {
            const input = document.getElementById('urlInput');
            const url = input.value.trim();
            
            if (!url) {
                alert('Please enter a URL');
                return;
            }
            
            // Validate URL format
            try {
                new URL(url);
            } catch (e) {
                alert('Please enter a valid URL (e.g., https://example.com/page)');
                return;
            }
            
            // Check for duplicates
            if (currentUrls.includes(url)) {
                alert('This URL is already in the list');
                return;
            }
            
            // Add to list
            currentUrls.push(url);
            input.value = '';
            
            // Save and render
            saveUrls();
            renderUrlList();
        }
        
        function removeUrl(url) {
            const index = currentUrls.indexOf(url);
            if (index > -1) {
                currentUrls.splice(index, 1);
            }
            
            saveUrls();
            renderUrlList();
        }
        
        function saveUrls() {
            const videoName = document.getElementById('videoSelect').value;
            localStorage.setItem(videoName + '_showOnPages', JSON.stringify(currentUrls));
        }
        
        function renderUrlList() {
            const container = document.getElementById('urlList');
            
            if (currentUrls.length === 0) {
                container.innerHTML = '<em style="color: #999; font-size: 12px;">No URLs - video shows on all pages</em>';
                return;
            }
            
            container.innerHTML = currentUrls.map(url => `
                <div style="display: flex; align-items: center; gap: 8px; padding: 6px; background: #f0f4ff; border: 1px solid #cbd5e0; border-radius: 4px; margin-bottom: 4px;">
                    <span style="flex: 1; font-family: monospace; font-size: 12px; word-break: break-all;">${url}</span>
                    <button onclick="removeUrl('${url.replace(/'/g, "\\'")}'); event.stopPropagation();" 
                            style="padding: 4px 8px; background: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 11px; white-space: nowrap;">Remove</button>
                </div>
            `).join('');
        }

        // Update position UI
        function updatePositionUI(position) {
            // Remove active class from all buttons and reset to outline-secondary
            document.querySelectorAll('.position-btn').forEach(btn => {
                btn.classList.remove('active', 'btn-primary');
                btn.classList.add('btn-outline-secondary');
            });
            
            if (position === 'custom') {
                document.getElementById('customPositionSelect').value = 'yes';
                document.getElementById('customPosition').classList.add('show');
            } else {
                const activeBtn = document.querySelector(`[data-position="${position}"]`);
                activeBtn.classList.add('active', 'btn-primary');
                activeBtn.classList.remove('btn-outline-secondary');
                document.getElementById('customPositionSelect').value = 'no';
                document.getElementById('customPosition').classList.remove('show');
                
                // Set form fields based on position preset
                const positions = {
                    'top-left': { left: '0', right: 'auto', top: '0', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                    'top-center': { left: '50%', right: 'auto', top: '0', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                    'top-right': { left: 'auto', right: '0', top: '0', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                    'middle-left': { left: '0', right: 'auto', top: '50%', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                    'center': { left: '50%', right: 'auto', top: '50%', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                    'middle-right': { left: 'auto', right: '0', top: '50%', bottom: 'auto', horizontalOffset: 'auto', verticalOffset: 'auto' },
                    'bottom-left': { left: '0', right: 'auto', top: 'auto', bottom: '0', horizontalOffset: 'auto', verticalOffset: 'auto' },
                    'bottom-center': { left: '50%', right: 'auto', top: 'auto', bottom: '0', horizontalOffset: 'auto', verticalOffset: 'auto' },
                    'bottom-right': { left: 'auto', right: '0', top: 'auto', bottom: '0', horizontalOffset: 'auto', verticalOffset: 'auto' }
                };
                
                if (positions[position]) {
                    const pos = positions[position];
                    document.getElementById('leftPos').value = pos.left;
                    document.getElementById('rightPos').value = pos.right;
                    document.getElementById('topPos').value = pos.top;
                    document.getElementById('bottomPos').value = pos.bottom;
                    // Calculate and set proper offset values
                    let horizontalOffset = pos.horizontalOffset;
                    let verticalOffset = pos.verticalOffset;
                    
                    // Calculate horizontal offset for centered positions
                    if (horizontalOffset === 'auto' && pos.left === '50%') {
                        horizontalOffset = -160; // Default 320px width / 2
                    }
                    
                    // Calculate vertical offset for centered positions  
                    if (verticalOffset === 'auto' && pos.top === '50%') {
                        verticalOffset = -160; // Default 320px height / 2
                    }
                    
                    // Offsets are calculated automatically, no need to set form fields
                }
            }
        }

        // Position button click handler
        document.querySelectorAll('.position-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const position = this.dataset.position;
                updatePositionUI(position);
                updatePreview(); // Update preview when position changes
            });
        });

        // Custom position selector handler
        document.getElementById('customPositionSelect').addEventListener('change', function() {
            if (this.value === 'yes') {
                updatePositionUI('custom');
            } else {
                updatePositionUI('bottom-right'); // Default to BR
            }
            updatePreview(); // Update preview when custom position changes
        });

        // Add event listeners to custom position fields for real-time preview
        ['leftPos', 'rightPos', 'topPos', 'bottomPos', 'horizontalOffset', 'verticalOffset'].forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.addEventListener('input', updatePreview);
                field.addEventListener('change', updatePreview);
            }
        });

        // Update live preview of video player position
        function updatePreview() {
            const previewPlayer = document.getElementById('previewPlayer');
            if (!previewPlayer) return;

            // Get current position values
            const left = document.getElementById('leftPos').value || 'auto';
            const right = document.getElementById('rightPos').value || 'auto';
            const top = document.getElementById('topPos').value || 'auto';
            const bottom = document.getElementById('bottomPos').value || 'auto';
            // Calculate offsets directly from position and dimensions
            let horizontalOffset = 'auto';
            let verticalOffset = 'auto';
            
            if (left === '50%') {
                horizontalOffset = -(320 / 2); // Use default width of 320px
            }
            if (top === '50%') {
                verticalOffset = -(320 / 2); // Use default height of 320px
            }
            const width = 320; // Default width (auto-detected from video)
            const height = 320; // Default height (auto-detected from video)

            // Scale preview player to fit in small container (max 80px, scale proportionally)
            const maxSize = 80;
            const scale = Math.min(maxSize / width, maxSize / height, 1);
            const previewWidth = Math.round(width * scale);
            const previewHeight = Math.round(height * scale);

            // Update preview player size (scaled)
            previewPlayer.style.width = previewWidth + 'px';
            previewPlayer.style.height = previewHeight + 'px';

            // Apply position styles (scaled for preview)
            previewPlayer.style.position = 'absolute';
            previewPlayer.style.left = left !== 'auto' ? left : 'auto';
            previewPlayer.style.right = right !== 'auto' ? right : 'auto';
            previewPlayer.style.top = top !== 'auto' ? top : 'auto';
            previewPlayer.style.bottom = bottom !== 'auto' ? bottom : 'auto';

            // Apply offset margins (scaled for preview)
            if (horizontalOffset !== 'auto' && horizontalOffset !== undefined) {
                const scaledOffset = Math.round(parseFloat(horizontalOffset) * scale);
                previewPlayer.style.marginLeft = scaledOffset + 'px';
            } else {
                previewPlayer.style.marginLeft = '0px';
            }
            if (verticalOffset !== 'auto' && verticalOffset !== undefined) {
                const scaledOffset = Math.round(parseFloat(verticalOffset) * scale);
                previewPlayer.style.marginTop = scaledOffset + 'px';
            } else {
                previewPlayer.style.marginTop = '0px';
            }

            // Update preview text to show current position
            const positionText = `${width}×${height}\n${left}, ${top}`;
            previewPlayer.textContent = positionText;
        }

        // Note: validatePositionValue() is now provided by admin-common.js module
        
        // Load analytics data (updated for new modular system)
        async function loadAnalytics() {
            const videoName = document.getElementById('videoSelect').value;
            console.log('📊 Loading analytics for video:', videoName);
            
            // Try to load from JSON file first (primary storage)
            let stats = await loadStatsFromJson(videoName);
            let dataSource = 'JSON File';
            
            if (!stats) {
                console.log('📁 JSON file not available');
                stats = {
                    totalViews: 0,
                    startedViews: 0,
                    abandonedViews: 0,
                    uniqueVisitors: 0,
                    completions: 0,
                    totalWatchTime: 0,
                    engagementRate: 0
                };
                dataSource = 'No Data Available';
            }
            
            // Get new metrics (with fallbacks for older stats files)
            const startedViews = stats.startedViews || stats.totalViews || 0;
            const abandonedViews = stats.abandonedViews !== undefined ? stats.abandonedViews : (startedViews - stats.totalViews);
            const engagementRate = stats.engagementRate !== undefined ? stats.engagementRate : (startedViews > 0 ? Math.round((stats.totalViews / startedViews) * 100) : 0);
            
            // Calculate completion rate
            const completionRate = stats.totalViews > 0 ? Math.round((stats.completions / stats.totalViews) * 100) : 0;
            
            // Calculate average watch time
            const avgWatchTime = stats.totalViews > 0 ? Math.round(stats.totalWatchTime / stats.totalViews) : 0;
            
            // Check player status (from sessionStorage - autoplay feature)
            const playerOnPage = sessionStorage.getItem(videoName + '_onPage') === 'true';
            
            // Update UI
            document.getElementById('uniqueVisits').textContent = stats.uniqueVisitors;
            document.getElementById('totalViews').textContent = stats.totalViews;
            document.getElementById('startedViews').textContent = startedViews;
            document.getElementById('abandonedViews').textContent = Math.max(0, abandonedViews);
            document.getElementById('engagementRate').textContent = engagementRate + '%';
            document.getElementById('completionRate').textContent = completionRate + '%';
            document.getElementById('avgWatchTime').textContent = formatTime(avgWatchTime);
            document.getElementById('playerStatus').textContent = playerOnPage ? 'Online' : 'Offline';
            document.getElementById('statusIndicator').className = playerOnPage ? 'status-indicator status-online' : 'status-indicator status-offline';
            
            // Enhanced Analytics - Session Views
            const sessionViews = sessionStorage.getItem(videoName + '_session') || '0';
            document.getElementById('sessionViews').textContent = sessionViews;
            
            // Enhanced Analytics - Device Stats (simulated for demo)
            const deviceStats = getDeviceStats();
            document.getElementById('deviceBreakdown').textContent = deviceStats;
            
            // Enhanced Analytics - Exit Behavior (simulated for demo)
            const exitStats = getExitBehaviorStats();
            document.getElementById('exitBreakdown').textContent = exitStats;
            
            // Update video info
            document.getElementById('currentVideo').textContent = videoName;
            document.getElementById('videoPath').textContent = resolvePlayerPath();
            const currentPoster = sessionStorage.getItem(videoName + '_poster') || 'Thumb';
            document.getElementById('videoPoster').textContent = currentPoster;
            
            // Update storage method indicator
            document.getElementById('storageMethod').textContent = dataSource;
            
            console.log('✅ Analytics loaded successfully from:', dataSource, stats);
        }
        
        // Load stats from JSON file (primary storage method)
        async function loadStatsFromJson(videoName) {
            try {
                const response = await fetch(`stats/${videoName}-stats.json`);
                
                if (response.ok) {
                    const data = await response.json();
                    
                    // Validate JSON structure
                    if (!data.stats) {
                        console.warn('⚠️ Invalid JSON file structure - missing stats object');
                        return null;
                    }
                    
                    console.log('✅ Analytics loaded from JSON file:', {
                        videoName: data.videoName,
                        lastUpdated: data.lastUpdated,
                        stats: data.stats
                    });
                    return data.stats;
                } else if (response.status === 404) {
                    console.log('📁 No JSON file found for', videoName);
                    return null;
                } else {
                    console.warn('⚠️ JSON file load failed - HTTP error:', response.status);
                    return null;
                }
            } catch (error) {
                console.warn('⚠️ JSON file load failed - network/server error:', error);
                return null;
            }
        }
        
        
        
        // Format time in seconds to readable format
        function formatTime(seconds) {
            if (seconds < 60) {
                return seconds + 's';
            } else if (seconds < 3600) {
                const minutes = Math.floor(seconds / 60);
                const remainingSeconds = seconds % 60;
                return minutes + 'm ' + remainingSeconds + 's';
            } else {
                const hours = Math.floor(seconds / 3600);
                const minutes = Math.floor((seconds % 3600) / 60);
                return hours + 'h ' + minutes + 'm';
            }
        }

        // Refresh analytics
        function refreshAnalytics() {
            loadAnalytics();
        }

        async function clearStats() {
            const videoName = document.getElementById('videoSelect').value;
            
            if (!confirm(`Clear all analytics data for ${videoName}? This cannot be undone.`)) {
                return;
            }
            
            try {
                const response = await fetch('clear-stats.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ videoName: videoName })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('Stats cleared successfully!');
                    loadAnalytics(); // Refresh display
                } else {
                    alert('Error: ' + result.error);
                }
            } catch (error) {
                alert('Failed to clear stats: ' + error.message);
            }
        }

        // Enhanced Analytics Helper Functions
        function getDeviceStats() {
            // Simulate device detection for demo purposes
            // In a real implementation, this would come from the JSON stats
            const userAgent = navigator.userAgent.toLowerCase();
            if (/tablet|ipad|playbook|silk/.test(userAgent)) {
                return 'Tablet: 1';
            } else if (/mobile|iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/.test(userAgent)) {
                return 'Mobile: 1';
            } else {
                return 'Desktop: 1';
            }
        }

        function getExitBehaviorStats() {
            // Simulate exit behavior for demo purposes
            // In a real implementation, this would come from the JSON stats
            const exitBehaviors = ['No Action', 'Close', 'Contact', 'Email'];
            const randomBehavior = exitBehaviors[Math.floor(Math.random() * exitBehaviors.length)];
            return randomBehavior;
        }

        // Video Management Functions
        document.getElementById('videoUploadForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData();
            const videoFile = document.getElementById('videoFile').files[0];
            const thumbnailFile = document.getElementById('thumbnailFile').files[0];
            const description = document.getElementById('videoDescription').value;
            
            if (!videoFile) {
                showAdminStatus('Please select a video file.', 'error', 'uploadStatus');
                return;
            }
            
            // Extract video name from filename (remove .webm extension)
            const videoName = videoFile.name.replace('.webm', '');
            
            formData.append('videoFile', videoFile);
            if (thumbnailFile) formData.append('thumbnailFile', thumbnailFile);
            formData.append('videoName', videoName);
            formData.append('description', description);
            
            showAdminStatus('Uploading...', 'info', 'uploadStatus');
            
            try {
                const response = await fetch('upload-video.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showAdminStatus('✅ Video uploaded successfully!', 'success', 'uploadStatus');
                    
                    // Dimensions are auto-detected from video file
                    if (result.dimensions) {
                        showAdminStatus('✅ Video uploaded successfully! Dimensions detected: ' + result.dimensions.width + '×' + result.dimensions.height, 'success', 'uploadStatus');
                    }
                    
                    document.getElementById('videoUploadForm').reset();
                    loadVideoList(); // Refresh the video list
                } else {
                    showAdminStatus('❌ Upload failed: ' + result.message, 'error', 'uploadStatus');
                }
            } catch (error) {
                showAdminStatus('❌ Upload error: ' + error.message, 'error', 'uploadStatus');
            }
        });

        const posterUploadForm = document.getElementById('posterUploadForm');
        if (posterUploadForm) {
            posterUploadForm.addEventListener('submit', async function(e) {
                e.preventDefault();

                const posterFile = document.getElementById('posterImageFile').files[0];
                const posterNameInput = document.getElementById('posterName');
                const posterName = posterNameInput ? posterNameInput.value.trim() : '';

                if (!posterFile) {
                    showAdminStatus('Please select a poster image file.', 'error', 'posterUploadStatus');
                    return;
                }

                const posterData = new FormData();
                posterData.append('posterFile', posterFile);
                if (posterName) {
                    posterData.append('posterName', posterName);
                }

                showAdminStatus('Uploading poster image...', 'info', 'posterUploadStatus');

                try {
                    const response = await fetch('upload-poster.php', {
                        method: 'POST',
                        body: posterData
                    });

                    const result = await response.json();

                    if (result.success) {
                        showAdminStatus('? Poster uploaded successfully! Choose it above to make it active.', 'success', 'posterUploadStatus');
                        posterUploadForm.reset();

                        const posterSelect = document.getElementById('posterSelect');
                        if (posterSelect && result.posterName) {
                            if (![...posterSelect.options].some(opt => opt.value === result.posterName)) {
                                const option = document.createElement('option');
                                option.value = result.posterName;
                                option.textContent = result.posterName;
                                posterSelect.appendChild(option);
                            }
                            posterSelect.value = result.posterName;
                        }
                    } else {
                        showAdminStatus('? Poster upload failed: ' + result.message, 'error', 'posterUploadStatus');
                    }
                } catch (error) {
                    showAdminStatus('? Poster upload error: ' + error.message, 'error', 'posterUploadStatus');
                }
            });
        }

        async function loadVideoList() {
            try {
                const response = await fetch('get-video-list.php');
                const result = await response.json();
                
                if (result.success) {
                    displayVideoList(result.videos);
                } else {
                    document.getElementById('videoList').innerHTML = '<p class="text-danger">Error loading video list: ' + result.message + '</p>';
                }
            } catch (error) {
                document.getElementById('videoList').innerHTML = '<p class="text-danger">Error loading video list: ' + error.message + '</p>';
            }
        }

        function displayVideoList(videos) {
            const videoListDiv = document.getElementById('videoList');
            
            if (videos.length === 0) {
                videoListDiv.innerHTML = '<p class="text-muted">No videos found.</p>';
                return;
            }
            
            let html = '<div class="row g-1">';
            
            videos.forEach(video => {
                html += `
                    <div class="col-md-6 col-lg-4">
                        <div class="card" style="margin-bottom: 8px;">
                            <div class="card-body">
                                <h6 class="card-title">${video.name}</h6>
                                <p class="card-text">
                                    <small class="text-muted">
                                        Size: ${formatFileSize(video.size)}<br>
                                        ${video.dimensions ? `Dimensions: ${video.dimensions.width}×${video.dimensions.height}<br>` : ''}
                                        Modified: ${new Date(video.modified).toLocaleDateString()}
                                    </small>
                                </p>
                                <div class="btn-group" role="group">
                                    <button class="btn btn-sm btn-outline-primary" onclick="viewVideoDetails('${video.name}')">👁️ View</button>
                                    <button class="btn btn-sm btn-outline-danger" onclick="deleteVideo('${video.name}')">🗑️ Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            html += '</div>';
            videoListDiv.innerHTML = html;
        }

        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        function viewVideoDetails(videoName) {
            alert(`Video Details:\nName: ${videoName}\n\nThis would show detailed metadata in a modal or expanded view.`);
        }

        // Load video dimensions when video is selected
        async function loadVideoDimensions(videoName) {
            try {
                const response = await fetch('get-video-list.php');
                const result = await response.json();
                
                if (result.success) {
                    const video = result.videos.find(v => v.name === videoName);
                    if (video && video.dimensions) {
                        console.log('📐 Auto-detected dimensions for', videoName, ':', video.dimensions.width + '×' + video.dimensions.height);
                    }
                }
            } catch (error) {
                console.log('Could not load dimensions for', videoName, ':', error.message);
            }
        }

        async function deleteVideo(videoName) {
            if (!confirm(`Are you sure you want to delete "${videoName}"?\n\nThis action cannot be undone.`)) {
                return;
            }
            
            try {
                const response = await fetch('delete-video.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ videoName: videoName })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('✅ Video deleted successfully!');
                    loadVideoList(); // Refresh the video list
                } else {
                    alert('❌ Delete failed: ' + result.message);
                }
            } catch (error) {
                alert('❌ Delete error: ' + error.message);
            }
        }

        // Create JSON files for new videos
        function createJsonForNewVideos() {
            if (!confirm('This will create JSON stats files for any videos that don\'t have them yet. Continue?')) {
                return;
            }

            // Show loading state
            const button = event.target;
            const originalText = button.textContent;
            button.textContent = '⏳ Creating...';
            button.disabled = true;

            fetch('create-json-files.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ action: 'create_missing_json' })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(`✅ Success! Created JSON files for ${data.created_count} videos:\n${data.created_files.join('\n')}`);
                    refreshAnalytics(); // Refresh to show new data
                } else {
                    alert(`❌ Error: ${data.message}`);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('❌ Error creating JSON files: ' + error.message);
            })
            .finally(() => {
                // Reset button
                button.textContent = originalText;
                button.disabled = false;
            });
        }
        
        
        // Check storage status and update UI
        async function checkStorageStatus() {
            const videoName = document.getElementById('videoSelect').value;
            console.log('🔍 Checking storage status for video:', videoName);
            
            try {
                // Check if JSON file exists
                const response = await fetch(`stats/${videoName}-stats.json`);
                if (response.ok) {
                    const data = await response.json();
                    
                    // Validate JSON structure
                    if (data.stats && data.lastUpdated) {
                        document.getElementById('jsonFileStatus').textContent = '✅ Exists & Valid';
                        document.getElementById('lastUpdated').textContent = new Date(data.lastUpdated).toLocaleString();
                        document.getElementById('storageMethod').textContent = 'JSON File (Primary)';
                        
                        console.log('✅ JSON file status: Valid and up to date');
                    } else {
                        document.getElementById('jsonFileStatus').textContent = '⚠️ Invalid Structure';
                        document.getElementById('lastUpdated').textContent = '-';
                        document.getElementById('storageMethod').textContent = 'No Data Available';
                        
                        console.warn('⚠️ JSON file has invalid structure');
                    }
                } else if (response.status === 404) {
                    document.getElementById('jsonFileStatus').textContent = '❌ Not Found';
                    document.getElementById('lastUpdated').textContent = '-';
                    document.getElementById('storageMethod').textContent = 'No Data Available';
                    
                    console.log('📁 JSON file not found');
                } else {
                    document.getElementById('jsonFileStatus').textContent = '❌ Error (' + response.status + ')';
                    document.getElementById('lastUpdated').textContent = '-';
                    document.getElementById('storageMethod').textContent = 'No Data Available';
                    
                    console.warn('⚠️ JSON file check failed with status:', response.status);
                }
                
                
            } catch (error) {
                document.getElementById('jsonFileStatus').textContent = '❌ Network Error';
                document.getElementById('lastUpdated').textContent = '-';
                document.getElementById('storageMethod').textContent = 'No Data Available';
                
                console.error('❌ Storage status check failed:', error);
                
            }
        }


        // switchVideo removed - use dropdown change event instead
        
        // Video selector change handler (for dropdown mode)
        // DO NOT auto-load settings when dropdown changes - let user explicitly load if needed
        // This prevents overwriting the user's video selection
        const videoSelectElement = document.getElementById('videoSelect');
        if (videoSelectElement && videoSelectElement.tagName === 'SELECT') {
            videoSelectElement.addEventListener('change', function() {
                // Only load analytics/stats, NOT settings (settings would overwrite current selection)
                loadAnalytics();
                checkStorageStatus();
                loadVideoDimensions(this.value);
            });
        }

        // Autostart change handler
        document.getElementById('autostart').addEventListener('change', function() {
            const timeStopGroup = document.getElementById('timeStopGroup');
            if (this.value === 'gostopgo' || this.value === 'delay') {
                timeStopGroup.style.display = 'block';
            } else {
                timeStopGroup.style.display = 'none';
            }
        });

        // Exit on Complete change handler - moved to DOMContentLoaded

        // TimeStop change handler
        document.getElementById('timeStop').addEventListener('change', function() {
            if (window.talkingHeadPlayer) {
                window.talkingHeadPlayer.timeStop = parseFloat(this.value);
                console.log('TimeStop updated to:', window.talkingHeadPlayer.timeStop);
            }
        });

        // Load contact form submissions
        function loadContactSubmissions() {
            const container = document.getElementById('contactSubmissions');
            container.innerHTML = '<p>Loading submissions...</p>';
            
            fetch('contact_submissions.json')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('No submissions file found');
                    }
                    return response.json();
                })
                .then(submissions => {
                    if (!submissions || submissions.length === 0) {
                        container.innerHTML = '<p style="color: #666;">No contact form submissions yet.</p>';
                        return;
                    }
                    
                    // Sort by timestamp (newest first)
                    submissions.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
                    
                    let html = '<div style="max-height: 400px; overflow-y: auto;">';
                    submissions.forEach(sub => {
                        html += `
                            <div style="background: #f9f9f9; padding: 15px; margin-bottom: 10px; border-radius: 4px; border-left: 4px solid #549bff;">
                                <div style="margin-bottom: 8px;">
                                    <strong style="color: #549bff;">${sub.name}</strong>
                                    <span style="color: #666; font-size: 12px; float: right;">${sub.timestamp}</span>
                                </div>
                                <div style="margin-bottom: 8px; font-size: 14px;">
                                    📧 <a href="mailto:${sub.email}">${sub.email}</a>
                                </div>
                                <div style="margin-bottom: 8px; color: #666; font-size: 12px;">
                                    Video: ${sub.video_name} | To: ${sub.to_email}
                                </div>
                                <div style="padding: 10px; background: white; border-radius: 4px; font-size: 14px;">
                                    ${sub.message.replace(/\n/g, '<br>')}
                                </div>
                            </div>
                        `;
                    });
                    html += '</div>';
                    
                    container.innerHTML = html;
                })
                .catch(error => {
                    console.error('Error loading submissions:', error);
                    container.innerHTML = '<p style="color: #999;">No submissions file found. Submissions will be saved here when email delivery fails.</p>';
                });
        }

        // Load email captures
        function loadEmailCaptures() {
            const container = document.getElementById('emailCaptures');
            container.innerHTML = '<p>Loading email captures...</p>';
            
            fetch('email_captures.json')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('No email captures file found');
                    }
                    return response.json();
                })
                .then(captures => {
                    if (!captures || captures.length === 0) {
                        container.innerHTML = '<p style="color: #666;">No email captures yet.</p>';
                        return;
                    }
                    
                    // Sort by timestamp (newest first)
                    captures.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
                    
                    let html = '<div style="max-height: 400px; overflow-y: auto;">';
                    captures.forEach(capture => {
                        html += `
                            <div style="background: #f0f8ff; padding: 15px; margin-bottom: 10px; border-radius: 4px; border-left: 4px solid #28a745;">
                                <div style="margin-bottom: 8px;">
                                    <strong style="color: #28a745;">📧 Email Capture</strong>
                                    <span style="color: #666; font-size: 12px; float: right;">${capture.timestamp}</span>
                                </div>
                                <div style="margin-bottom: 8px; font-size: 14px;">
                                    📧 <a href="mailto:${capture.email}">${capture.email}</a>
                                </div>
                                <div style="margin-bottom: 8px; color: #666; font-size: 12px;">
                                    Video: ${capture.video_name} | To: ${capture.to_email}
                                </div>
                                <div style="padding: 8px; background: white; border-radius: 4px; font-size: 12px; color: #666;">
                                    Email captured from video exit behavior
                                </div>
                            </div>
                        `;
                    });
                    html += '</div>';
                    
                    container.innerHTML = html;
                })
                .catch(error => {
                    console.error('Error loading email captures:', error);
                    container.innerHTML = '<p style="color: #999;">No email captures file found. Email captures will be saved here when users submit their email.</p>';
                });
        }

        // Read current video count from player.js
        function readVideoCount() {
            fetch('player.js')
                .then(response => response.text())
                .then(content => {
                    const match = content.match(/const\s+SITE_VIDEO_COUNT\s*=\s*(\d+)/);
                    if (match) {
                        document.getElementById('currentVideoCount').textContent = match[1];
                    } else {
                        document.getElementById('currentVideoCount').textContent = 'Not set';
                    }
                })
                .catch(error => {
                    console.error('Error reading video count:', error);
                    document.getElementById('currentVideoCount').textContent = 'Error';
                });
        }
        
        // Update video count in player.js
        function updateVideoCount() {
            const detectedCount = <?php echo $videoCount; ?>;
            const currentCount = document.getElementById('currentVideoCount').textContent;
            
            if (!confirm(`Update SITE_VIDEO_COUNT in player.js?\n\nDetected videos: ${detectedCount}\nCurrent setting: ${currentCount}\n\nThis will update player.js to match the detected video count.`)) {
                return;
            }
            
            // Send to PHP to update player.js
            fetch('update_video_count.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ videoCount: detectedCount })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(`✅ Video count updated to ${detectedCount}!\n\nThe player.js file has been updated.`);
                    readVideoCount();
                    // Reload page to update tabs if needed
                    location.reload();
                } else {
                    alert('❌ Error: ' + data.error);
                }
            })
            .catch(error => {
                alert('❌ Error updating video count: ' + error.message);
            });
        }

        // Determine which grid position matches the given position values
        function getGridPositionFromValues(left, right, top, bottom) {
            const positions = {
                'top-left': { left: '0', right: 'auto', top: '0', bottom: 'auto', horizontalOffset: false, verticalOffset: false },
                'top-center': { left: '50%', right: 'auto', top: '0', bottom: 'auto', horizontalOffset: true, verticalOffset: false },
                'top-right': { left: 'auto', right: '0', top: '0', bottom: 'auto', horizontalOffset: false, verticalOffset: false },
                'middle-left': { left: '0', right: 'auto', top: '50%', bottom: 'auto', horizontalOffset: false, verticalOffset: true },
                'center': { left: '50%', right: 'auto', top: '50%', bottom: 'auto', horizontalOffset: true, verticalOffset: true },
                'middle-right': { left: 'auto', right: '0', top: '50%', bottom: 'auto', horizontalOffset: false, verticalOffset: true },
                'bottom-left': { left: '0', right: 'auto', top: 'auto', bottom: '0', horizontalOffset: false, verticalOffset: false },
                'bottom-center': { left: '50%', right: 'auto', top: 'auto', bottom: '0', horizontalOffset: true, verticalOffset: false },
                'bottom-right': { left: 'auto', right: '0', top: 'auto', bottom: '0', horizontalOffset: false, verticalOffset: false }
            };
            
            for (const [posName, posValues] of Object.entries(positions)) {
                if (left === posValues.left && right === posValues.right && 
                    top === posValues.top && bottom === posValues.bottom) {
                    return posName;
                }
            }
            return null; // No matching grid position
        }
        
        // Update grid button UI to show which position is active
        function highlightGridPosition(positionName) {
            document.querySelectorAll('.position-btn').forEach(btn => {
                btn.classList.remove('active', 'btn-primary');
                btn.classList.add('btn-outline-secondary');
            });
            if (positionName) {
                const activeBtn = document.querySelector(`[data-position="${positionName}"]`);
                if (activeBtn) {
                    activeBtn.classList.add('active', 'btn-primary');
                    activeBtn.classList.remove('btn-outline-secondary');
                }
            }
        }

        // Initialize - load saved settings from player.js
        document.addEventListener('DOMContentLoaded', function() {
            // Validate setupType configuration
            <?php if ($setupValidation === 'error'): ?>
            alert('❌ Error: Multiple video setup requires 2+ videos.\n\nCurrent: <?php echo $videoCount; ?> video(s) found.\n\nPlease change setupType to "single" or add more videos.');
            <?php endif; ?>
            
            // Load saved settings from player.js first
            loadSettings();
            
            // Load analytics and stats
            loadAnalytics();
            checkStorageStatus();
            readVideoCount();
            
            // Initialize preview after a short delay to ensure all elements are loaded
            setTimeout(updatePreview, 100);
            
            // Initialize Bootstrap tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Exit on Complete change handler
            document.getElementById('exitOnComplete').addEventListener('change', function() {
                const redirectGroup = document.getElementById('redirectGroup');
                const redirectDelayGroup = document.getElementById('redirectDelayGroup');
                const emailCaptureGroup = document.getElementById('emailCaptureGroup');

                if (this.value === 'redirect') {
                    redirectGroup.style.display = 'block';
                    redirectDelayGroup.style.display = 'block';
                    emailCaptureGroup.style.display = 'none';
                } else if (this.value === 'email') {
                    redirectGroup.style.display = 'none';
                    redirectDelayGroup.style.display = 'none';
                    emailCaptureGroup.style.display = 'block';
                } else {
                    redirectGroup.style.display = 'none';
                    redirectDelayGroup.style.display = 'none';
                    emailCaptureGroup.style.display = 'none';
                }
            });
        });
    </script>
    
    <!-- JSONEditor JS -->
    <script src="https://cdn.jsdelivr.net/npm/jsoneditor@10.0.0/dist/jsoneditor.min.js"></script>
    
    <!-- JSONEditor Configuration -->
    <script>
        let editor = null;
        let currentConfig = null;
        
        // Initialize JSONEditor
        function initializeEditor() {
            const container = document.getElementById('jsonEditor');
            
            // Define schema for validation
            const schema = {
                "type": "object",
                "properties": {
                    "version": {
                        "type": "string",
                        "description": "Configuration version"
                    },
                    "description": {
                        "type": "string",
                        "description": "Configuration description"
                    },
                    "settings": {
                        "type": "object",
                        "properties": {
                            "autostart": {
                                "type": "string",
                                "enum": ["yes", "mute", "loop", "once", "picSession", "muteSession", "onceLocal", "picLocal", "muteLocal", "hover", "scroll", "slide", "gostopgo", "delay", "poster"],
                                "description": "Autostart behavior"
                            },
                            "position": {
                                "type": "string",
                                "enum": ["top-left", "top-center", "top-right", "middle-left", "center", "middle-right", "bottom-left", "bottom-center", "bottom-right"],
                                "description": "Video position"
                            },
                            "width": {
                                "type": "number",
                                "minimum": 100,
                                "maximum": 800,
                                "description": "Video width in pixels"
                            },
                            "height": {
                                "type": "number",
                                "minimum": 100,
                                "maximum": 800,
                                "description": "Video height in pixels"
                            },
                            "exitOnComplete": {
                                "type": "string",
                                "enum": ["no", "close", "poster", "contact", "email", "redirect"],
                                "description": "Action when video completes"
                            },
                            "controlsMode": {
                                "type": "string",
                                "enum": ["always", "hover", "hide"],
                                "description": "When to show video controls"
                            },
                            "contactEmail": {
                                "type": "string",
                                "format": "email",
                                "description": "Contact email address"
                            },
                            "redirectURL": {
                                "type": "string",
                                "format": "uri",
                                "description": "Redirect URL for exit behavior"
                            },
                            "redirectDelay": {
                                "type": "number",
                                "minimum": 0,
                                "description": "Redirect delay in seconds"
                            },
                            "emailSubject": {
                                "type": "string",
                                "description": "Email subject for email capture"
                            },
                            "scrollThreshold": {
                                "type": "number",
                                "minimum": 0,
                                "maximum": 1,
                                "description": "Scroll threshold for video activation"
                            },
                            "zIndex": {
                                "type": "number",
                                "minimum": 1,
                                "description": "Z-index for video layer"
                            },
                            "color": {
                                "type": "string",
                                "pattern": "^#[0-9A-Fa-f]{6}$",
                                "description": "Brand color (hex format)"
                            }
                        },
                        "required": ["autostart", "position", "width", "height"]
                    },
                    "urls": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "format": "uri"
                        },
                        "description": "URLs where video should appear"
                    },
                    "lastUpdated": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Last update timestamp"
                    }
                },
                "required": ["version", "settings"]
            };
            
            const options = {
                mode: 'tree',
                modes: ['tree', 'code', 'form'],
                search: true,
                history: true,
                navigationBar: true,
                statusBar: true,
                mainMenuBar: true,
                schema: schema,
                schemaRefs: {},
                onError: function(err) {
                    showAdminStatus('Error: ' + err.message, 'danger', 'editorStatus');
                },
                onModeChange: function(newMode) {
                    console.log('Editor mode changed to:', newMode);
                },
                onValidate: function(errors) {
                    if (errors.length > 0) {
                        showAdminStatus('Validation errors found: ' + errors.length, 'warning', 'editorStatus');
                    } else {
                        showAdminStatus('Configuration is valid', 'success', 'editorStatus');
                    }
                }
            };
            
            editor = new JSONEditor(container, options);
            
            // Set initial empty config
            editor.set({
                "version": "1.0.0",
                "description": "Talking Head Configuration",
                "settings": {
                    "autostart": "yes",
                    "position": "bottom-right",
                    "width": 320,
                    "height": 320
                }
            });
            
            showAdminStatus('JSONEditor initialized. Click "Load Config" to load your configuration.', 'info', 'editorStatus');
        }
        
        // Load configuration from server
        async function loadConfig() {
            const configFile = document.getElementById('configFileSelect').value;
            showAdminStatus('Loading configuration...', 'info', 'editorStatus');
            
            try {
                const response = await fetch('load-config.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ configFile: configFile })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    currentConfig = result.config;
                    editor.set(currentConfig);
                    showAdminStatus(`Configuration loaded from ${configFile}`, 'success', 'editorStatus');
                } else {
                    showAdminStatus('Error loading config: ' + result.error, 'danger', 'editorStatus');
                }
            } catch (error) {
                showAdminStatus('Error loading config: ' + error.message, 'danger', 'editorStatus');
            }
        }
        
        // Save configuration to server
        async function saveConfig() {
            const configFile = document.getElementById('configFileSelect').value;
            
            try {
                const config = editor.get();
                showAdminStatus('Saving configuration...', 'info', 'editorStatus');
                
                const response = await fetch('save-config.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ 
                        configFile: configFile,
                        config: config 
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    currentConfig = config;
                    showAdminStatus(`Configuration saved to ${configFile}`, 'success', 'editorStatus');
                } else {
                    showAdminStatus('Error saving config: ' + result.error, 'danger', 'editorStatus');
                }
            } catch (error) {
                showAdminStatus('Error saving config: ' + error.message, 'danger', 'editorStatus');
            }
        }
        
        // Validate configuration
        function validateConfig() {
            try {
                const config = editor.get();
                const errors = editor.validate();
                
                if (errors.length === 0) {
                    showAdminStatus('✅ Configuration is valid! All required fields are present and values are within acceptable ranges.', 'success', 'editorStatus');
                } else {
                    let errorMsg = '⚠️ Validation errors found (' + errors.length + '):\n';
                    errors.forEach((error, index) => {
                        errorMsg += `${index + 1}. ${error.message}`;
                        if (error.path) {
                            errorMsg += ` (at ${error.path.join('.')})`;
                        }
                        errorMsg += '\n';
                    });
                    showAdminStatus(errorMsg, 'warning', 'editorStatus');
                }
            } catch (error) {
                showAdminStatus('❌ Validation error: ' + error.message, 'danger', 'editorStatus');
            }
        }
        
        // Reset configuration to original
        function resetConfig() {
            if (currentConfig) {
                editor.set(currentConfig);
                showAdminStatus('Configuration reset to last saved version', 'info', 'editorStatus');
            } else {
                showAdminStatus('No saved configuration to reset to', 'warning', 'editorStatus');
            }
        }
        
        // Download configuration as file
        function downloadConfig() {
            try {
                const config = editor.get();
                const configFile = document.getElementById('configFileSelect').value;
                const dataStr = JSON.stringify(config, null, 2);
                const dataBlob = new Blob([dataStr], {type: 'application/json'});
                
                const link = document.createElement('a');
                link.href = URL.createObjectURL(dataBlob);
                link.download = configFile;
                link.click();
                
                showAdminStatus('Configuration downloaded', 'success', 'editorStatus');
            } catch (error) {
                showAdminStatus('Error downloading config: ' + error.message, 'danger', 'editorStatus');
            }
        }
        
        
        // Handle editor mode change
        document.getElementById('editorMode').addEventListener('change', function() {
            if (editor) {
                editor.setMode(this.value);
            }
        });
        
        // Initialize editor when page loads
        document.addEventListener('DOMContentLoaded', function() {
            initializeEditor();
            initializePlayerBehaviorSettings();
            initializeContactFormSettings();
        });
        
        // ========== PLAYER BEHAVIOR SETTINGS FUNCTIONS ==========
        
        function initializePlayerBehaviorSettings() {
            AdminPlayerBehavior.initializeSettings();
        }
        
        function loadPlayerBehaviorSettings() {
            // Player behavior settings are now loaded as part of the main loadSettings() function
            // This function is kept for compatibility but the actual loading happens in loadSettings()
            console.log('✅ Player behavior settings loaded via main config');
        }
        
        function setupPlayerBehaviorEventListeners() {
            // Color picker synchronization
            document.getElementById('playerColor').addEventListener('input', function() {
                document.getElementById('playerColorText').value = this.value;
            });
            
            document.getElementById('playerColorText').addEventListener('input', function() {
                if (isValidHexColor(this.value)) {
                    document.getElementById('playerColor').value = this.value;
                }
            });
            
            const playerPathInput = document.getElementById('playerPath');
            if (playerPathInput) {
                playerPathInput.addEventListener('input', () => {
                    window.currentPlayerPath = resolvePlayerPath();
                });
                playerPathInput.addEventListener('change', () => {
                    window.currentPlayerPath = resolvePlayerPath();
                });
            }
            
            // Form background color synchronization
            document.getElementById('formBackgroundColor').addEventListener('input', function() {
                document.getElementById('formBackgroundColorText').value = this.value;
            });
            
            document.getElementById('formBackgroundColorText').addEventListener('input', function() {
                if (isValidHexColor(this.value)) {
                    document.getElementById('formBackgroundColor').value = this.value;
                }
            });
            
            // Dimensions are auto-detected from video file
            
            // Scroll threshold
            document.getElementById('scrollThreshold').addEventListener('input', function() {
                document.getElementById('scrollThresholdValue').textContent = this.value;
            });
        }
        
        function resetPlayerColor() {
            document.getElementById('playerColor').value = '#549bff';
            document.getElementById('playerColorText').value = '#549bff';
        }
        
        function resetFormBackgroundColor() {
            document.getElementById('formBackgroundColor').value = '#549bff';
            document.getElementById('formBackgroundColorText').value = '#549bff';
        }
        
        function isValidHexColor(hex) {
            return /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(hex);
        }
        
        async function savePlayerBehaviorSettings() {
            const videoSelect = document.getElementById('videoSelect');
            const playerFile = videoSelect.value + '.js';
            
            // Collect all settings
            const settings = {
                color: document.getElementById('playerColor').value,
                scrollThreshold: parseFloat(document.getElementById('scrollThreshold').value),
                zIndex: parseInt(document.getElementById('playerZIndex').value)
            };
            
            try {
                // Load current player.js content
                const response = await fetch(playerFile);
                let content = await response.text();
                
                // Update each setting in the content
                content = content.replace(/color:\s*["'][^"']*["']/, `color: "${settings.color}"`);
                content = content.replace(/scrollThreshold:\s*[\d.]+/, `scrollThreshold: ${settings.scrollThreshold}`);
                content = content.replace(/zIndex:\s*\d+/, `zIndex: ${settings.zIndex}`);
                
                // Save updated content
                const saveResponse = await fetch('save-config.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `filename=${playerFile}&content=${encodeURIComponent(content)}`
                });
                
                if (saveResponse.ok) {
                    showAdminStatus('Player settings saved successfully!', 'success', 'playerBehaviorStatus');
                } else {
                    showAdminStatus('Error saving player settings', 'danger', 'playerBehaviorStatus');
                }
            } catch (error) {
                console.error('Error saving player settings:', error);
                showAdminStatus('Error saving player settings: ' + error.message, 'danger', 'playerBehaviorStatus');
            }
        }
        
        
        // ========== CONTACT FORM CUSTOMIZATION FUNCTIONS ==========
        
        let contactFormFields = [
            { id: 'name', label: 'Name', type: 'text', required: true, placeholder: 'Your name' },
            { id: 'email', label: 'Email', type: 'email', required: true, placeholder: 'your@email.com' },
            { id: 'message', label: 'Message', type: 'textarea', required: true, placeholder: 'Your message...' }
        ];
        
        function initializeContactFormSettings() {
            loadContactFormSettings();
            renderFormFields();
        }
        
        function loadContactFormSettings() {
            AdminContactForm.initializeSettings();
        }
        
        function renderFormFields() {
            const container = document.getElementById('formFieldsList');
            container.innerHTML = '';
            
            contactFormFields.forEach((field, index) => {
                const fieldDiv = document.createElement('div');
                fieldDiv.className = 'form-field-item';
                fieldDiv.style.cssText = `
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    padding: 6px;
                    background: white;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    margin-bottom: 4px;
                `;
                
                fieldDiv.innerHTML = `
                    <input type="text" value="${field.label}" placeholder="Field Label" style="flex: 1; padding: 3px; border: 1px solid #ccc; border-radius: 3px; font-size: 11px;" onchange="updateFieldLabel(${index}, this.value)">
                    <select style="padding: 3px; border: 1px solid #ccc; border-radius: 3px; font-size: 11px;" onchange="updateFieldType(${index}, this.value)">
                        <option value="text" ${field.type === 'text' ? 'selected' : ''}>Text</option>
                        <option value="email" ${field.type === 'email' ? 'selected' : ''}>Email</option>
                        <option value="textarea" ${field.type === 'textarea' ? 'selected' : ''}>Textarea</option>
                        <option value="tel" ${field.type === 'tel' ? 'selected' : ''}>Phone</option>
                    </select>
                    <input type="text" value="${field.placeholder || ''}" placeholder="Placeholder" style="flex: 1; padding: 3px; border: 1px solid #ccc; border-radius: 3px; font-size: 11px;" onchange="updateFieldPlaceholder(${index}, this.value)">
                    <label style="font-size: 10px; margin: 0;">
                        <input type="checkbox" ${field.required ? 'checked' : ''} onchange="updateFieldRequired(${index}, this.checked)"> Required
                    </label>
                    <button type="button" onclick="removeFormField(${index})" style="padding: 2px 6px; background: #dc3545; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 10px;">×</button>
                `;
                
                container.appendChild(fieldDiv);
            });
        }
        
        function addFormField() {
            const newField = {
                id: 'field_' + Date.now(),
                label: 'New Field',
                type: 'text',
                required: false,
                placeholder: ''
            };
            
            contactFormFields.push(newField);
            renderFormFields();
        }
        
        function removeFormField(index) {
            if (contactFormFields.length > 1) {
                contactFormFields.splice(index, 1);
                renderFormFields();
            }
        }
        
        function updateFieldLabel(index, value) {
            contactFormFields[index].label = value;
        }
        
        function updateFieldType(index, value) {
            contactFormFields[index].type = value;
        }
        
        function updateFieldPlaceholder(index, value) {
            contactFormFields[index].placeholder = value;
        }
        
        function updateFieldRequired(index, value) {
            contactFormFields[index].required = value;
        }
        
        async function saveContactFormSettings() {
            const settings = {
                fields: contactFormFields,
                smtp: {
                    host: document.getElementById('smtpHost').value,
                    port: document.getElementById('smtpPort').value,
                    username: document.getElementById('smtpUsername').value,
                    password: document.getElementById('smtpPassword').value,
                    fromEmail: document.getElementById('smtpFromEmail').value
                },
                messages: {
                    success: document.getElementById('successMessage').value,
                    error: document.getElementById('errorMessage').value
                },
                styling: {
                    title: document.getElementById('formTitle').value,
                    backgroundColor: document.getElementById('formBackgroundColor').value
                }
            };
            
            try {
                // Save to localStorage
                localStorage.setItem('contactFormSettings', JSON.stringify(settings));
                
                // Also save to server (create a new PHP file for this)
                const response = await fetch('save-contact-form-settings.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(settings)
                });
                
                if (response.ok) {
                    showAdminStatus('Contact form settings saved successfully!', 'success', 'contactFormStatus');
                } else {
                    showAdminStatus('Settings saved locally, but server save failed', 'warning', 'contactFormStatus');
                }
            } catch (error) {
                console.error('Error saving contact form settings:', error);
                showAdminStatus('Settings saved locally only', 'warning', 'contactFormStatus');
            }
        }
        
    </script>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Documentation Section -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="panel">
                <h2>
                    <div class="icon">📚</div>
                    Documentation & Installation Guides
                </h2>
                <div class="setting-group">
                    <p>Download comprehensive installation and setup guides:</p>
                    <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                        <?php
                        $standardPdf = __DIR__ . '/docs/STANDARD_INSTALLATION.pdf';
                        $wpPdf = __DIR__ . '/docs/INSTALLATION.pdf';
                        
                        // Check if PDFs exist in docs folder, otherwise check root
                        if (!file_exists($standardPdf)) {
                            $standardPdf = __DIR__ . '/STANDARD_INSTALLATION.pdf';
                        }
                        if (!file_exists($wpPdf)) {
                            $wpPdf = __DIR__ . '/INSTALLATION.pdf';
                        }
                        
                        $baseUrl = dirname($_SERVER['PHP_SELF']);
                        if ($baseUrl === '/') $baseUrl = '';
                        ?>
                        <?php if (file_exists($standardPdf)): ?>
                            <a href="<?php echo htmlspecialchars($baseUrl . '/docs/STANDARD_INSTALLATION.pdf'); ?>" 
                               class="download-btn" 
                               target="_blank" 
                               style="display: inline-block; padding: 12px 24px; background: #0073FF; color: white; text-decoration: none; border-radius: 5px; font-weight: bold;">
                                📄 Standard Installation Guide (PDF)
                            </a>
                        <?php endif; ?>
                        <?php if (file_exists($wpPdf)): ?>
                            <a href="<?php echo htmlspecialchars($baseUrl . '/docs/INSTALLATION.pdf'); ?>" 
                               class="download-btn" 
                               target="_blank" 
                               style="display: inline-block; padding: 12px 24px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; font-weight: bold;">
                                📄 WordPress Installation Guide (PDF)
                            </a>
                        <?php endif; ?>
                    </div>
                    <p style="margin-top: 15px; font-size: 14px; color: #666;">
                        <small>💡 <strong>Tip:</strong> The Standard Installation Guide covers setup for regular websites. The WordPress Guide is for WordPress plugin installation.</small>
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer style="margin-top: 40px; padding: 20px; background: #f8f9fa; border-top: 1px solid #e9ecef; text-align: center;">
        <div style="color: #666; font-size: 12px;">
            <p style="margin: 0;">
                © Talking Head Video Player | Admin Panel v1.0
            </p>
        </div>
    </footer>
</body>
</html>
