<?php
/**
 * Admin Panel Helper Functions
 * Server-side PHP functions for admin panel operations
 */

/**
 * Get video configuration from player.js file
 * @param string $filename - Name of the player.js file
 * @return array - Parsed configuration array
 */
function normalizePositionKeys($config) {
    if (is_object($config)) {
        $config = (array)$config;
    }
    if (!is_array($config)) {
        $config = (array)$config;
    }
    // Legacy `centerOffset` should map to `horizontalOffset`
    if (array_key_exists('centerOffset', $config) && !array_key_exists('horizontalOffset', $config)) {
        $config['horizontalOffset'] = $config['centerOffset'];
    }

    // Legacy vertical variants fall back to `verticalOffset`
    if (!array_key_exists('verticalOffset', $config)) {
        if (array_key_exists('centerOffsetY', $config)) {
            $config['verticalOffset'] = $config['centerOffsetY'];
        } elseif (array_key_exists('centerOffsetVertical', $config)) {
            $config['verticalOffset'] = $config['centerOffsetVertical'];
        }
    }

    // Normalize numeric strings to native numbers where possible
    foreach (['horizontalOffset', 'verticalOffset'] as $offsetKey) {
        if (isset($config[$offsetKey]) && is_string($config[$offsetKey]) && is_numeric($config[$offsetKey])) {
            $config[$offsetKey] = $config[$offsetKey] + 0;
        }
    }

    unset($config['centerOffset'], $config['centerOffsetY'], $config['centerOffsetVertical']);

    return $config;
}

function getVideoConfig($filename) {
    $filepath = __DIR__ . '/' . $filename;
    if (!file_exists($filepath)) {
        return array();
    }
    $content = file_get_contents($filepath);
    $config = array();
    
    // Find the start of VIDEO_CONFIG
    if (preg_match('/const\s+VIDEO_CONFIG\s*=\s*\{/', $content, $startMatch, PREG_OFFSET_CAPTURE)) {
        $startPos = $startMatch[0][1] + strlen($startMatch[0][0]);
        
        // Find the end of VIDEO_CONFIG
        if (preg_match('/\};/', substr($content, $startPos), $endMatch, PREG_OFFSET_CAPTURE)) {
            $configContent = substr($content, $startPos, $endMatch[0][1]);
            
            // Parse line by line without regex - just extract key: value
            $lines = explode("\n", $configContent);
            foreach ($lines as $line) {
                $line = trim($line);
                if (empty($line)) {
                    continue; // Skip empty lines
                }
                // Skip comment-only lines
                if (strpos($line, '//') === 0 || strpos($line, '/*') === 0 || strpos($line, '*') === 0) {
                    continue;
                }
                
                // Remove trailing comma if present
                if (substr($line, -1) === ',') {
                    $line = substr($line, 0, -1);
                }
                
                // Split on first colon to get key and value
                $colonPos = strpos($line, ':');
                if ($colonPos !== false) {
                    $key = trim(substr($line, 0, $colonPos));
                    $value = trim(substr($line, $colonPos + 1));
                    
                    // Remove any inline comments
                    $commentPos = strpos($value, '//');
                    if ($commentPos !== false) {
                        $value = trim(substr($value, 0, $commentPos));
                    }
                    
                    if (!empty($key)) {
                        // Parse the value based on its format
                        if ($value === 'true') {
                            $value = true;
                        } elseif ($value === 'false') {
                            $value = false;
                        } elseif ($value === 'auto') {
                            $value = 'auto';
                        } elseif (is_numeric($value)) {
                            $value = strpos($value, '.') !== false ? (float)$value : (int)$value;
                        } elseif (strlen($value) > 0 && $value[0] === '"' && $value[strlen($value)-1] === '"') {
                            $value = substr($value, 1, -1);
                        } elseif (strlen($value) > 0 && $value[0] === "'" && $value[strlen($value)-1] === "'") {
                            $value = substr($value, 1, -1);
                        }
                        
                        $config[$key] = $value;
                    }
                }
            }
        }
    }
    
    return normalizePositionKeys($config);
}

/**
 * Build video configuration string for saving to player.js
 * @param array $config - Configuration array
 * @return string - Formatted configuration string
 */
function buildVideoConfigString($config) {
    $lines = array();
    $lines[] = '// ========== VIDEO CONFIGURATION (EDITABLE BY ADMIN PANEL) ==========';
    $lines[] = '// This object contains all settings that can be configured via admin.php';
    $lines[] = '// When admin.php saves changes, it updates this object and saves the file';
    $lines[] = 'const VIDEO_CONFIG = {';
    $keys = array_keys($config);
    $numericFields = array('timeStop', 'redirectDelay', 'zIndex', 'scrollThreshold', 'horizontalOffset', 'verticalOffset');
    
    foreach ($keys as $index => $key) {
        $value = $config[$key];
        $line = '    ' . $key . ': ';
        
        // Check if this field should be numeric
        if (in_array($key, $numericFields) && is_numeric($value)) {
            $line .= $value;
        } elseif (is_bool($value)) {
            $line .= $value ? 'true' : 'false';
        } elseif (is_numeric($value) && !is_string($value)) {
            $line .= $value;
        } else {
            // Everything else gets quoted: strings, "auto", etc.
            $line .= '"' . addslashes($value) . '"';
        }
        
        if ($index < count($keys) - 1) {
            $line .= ',';
        }
        $lines[] = $line;
    }
    $lines[] = '};';
    $lines[] = '// ==================================================================';
    $lines[] = '';
    return implode("\n", $lines) . "\n";
}

/**
 * Update video configuration in player.js file
 * @param string $filename - Name of the player.js file
 * @param array $config - New configuration array
 * @return bool - Success status
 */
function updateVideoConfig($filename, $config) {
    $config = normalizePositionKeys($config);
    $filepath = __DIR__ . '/' . $filename;
    if (!file_exists($filepath)) {
        return false;
    }
    $content = file_get_contents($filepath);
    $newConfigStr = buildVideoConfigString($config);
    $startMarker = '// ========== VIDEO CONFIGURATION';
    $endMarker = '// ==================================================================';
    $startPos = strpos($content, $startMarker);
    $endPos = strpos($content, $endMarker, $startPos);
    if ($startPos === false || $endPos === false) {
        return false;
    }
    $endPos += strlen($endMarker);
    $newContent = substr($content, 0, $startPos) . $newConfigStr . substr($content, $endPos);
    if ($newContent === $content) {
        return false;
    }
    // Write in-place without creating any extra files; lock during write
    $bytesWritten = file_put_contents($filepath, $newContent, LOCK_EX);
    return $bytesWritten !== false;
}

/**
 * Validate player filename
 * @param string $filename - Filename to validate
 * @return bool - True if valid
 */
function isValidPlayerFilename($filename) { 
    return preg_match('/^player\d*\.js$/', $filename) === 1;
}

